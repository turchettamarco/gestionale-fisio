"use client";

import Link from "next/link";
import { Suspense, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/src/lib/supabaseClient";
import { SOAPNotesEditor } from "./components/SOAPNotes";

import { useSearchParams } from "next/navigation";


type Status = "booked" | "confirmed" | "done" | "cancelled" | "not_paid";

type BookingRequest = {
  id: string;
  service_name: string;
  service_duration: number;
  requested_date: string;
  requested_time: string;
  patient_name: string;
  patient_phone: string;
  patient_email: string | null;
  notes: string | null;
  status: "pending" | "confirmed" | "cancelled";
  created_at: string;
};

type LocationType = "studio" | "domicile";

type AppointmentRow = {
  id: string;
  patient_id: string;
  start_at: string;
  end_at: string;
  status: Status;
  calendar_note: string | null;
  location: LocationType;
  clinic_site: string | null;
  domicile_address: string | null;
  patients: { first_name: string; last_name: string } | null;
};

type PatientLite = { 
  id: string; 
  first_name: string; 
  last_name: string; 
  phone?: string | null;
  treatment?: string | null;
  diagnosis?: string | null;
};

type PracticeSettings = {
  standard_invoice: number | null;
  standard_cash: number | null;
  machine_invoice: number | null;
  machine_cash: number | null;
  auto_apply_prices: boolean | null;
  google_review_link: string | null;
  default_appointment_status: "confirmed" | "booked" | null;
};

type CalendarEvent = {
  id: string;
  patient_id: string;
  title: string;
  start: Date;
  end: Date;
  status: Status;
  calendar_note: string | null;
  location: LocationType | null;
  clinic_site: string | null;
  domicile_address: string | null;
  treatment_type: string | null;
  price_type: string | null;
  amount: number | null;
  expected_price: number | null;
  is_paid: boolean;
  reminder_sent_at: Date | null;
  reminder_status: string | null;
  whatsapp_sent_at: Date | null;
  patient_name: string;
  patient_first_name: string | null;
  patient_last_name: string | null;
  patient_phone: string | null;
  treatment: string | null;
  diagnosis: string | null;
};

const THEME = {
  appBg: "#f1f5f9",
  panelBg: "#ffffff",
  panelSoft: "#f7f9fd",
  cardBg: "#ffffff",

  text: "#0f172a",
  textSoft: "#1e293b",
  muted: "#334155",

  border: "#cbd5e1",
  borderSoft: "#94a3b8",

  blue: "#2563eb",
  blueDark: "#1e40af",
  green: "#16a34a",
  greenDark: "#15803d",
  teal: "#0d9488",
  tealDark: "#0f766e",
  patientsAccent: "#0d9488",
  purple: "#7c3aed",

  red: "#dc2626",
  amber: "#f97316",
  gray: "#94a3b8",
};

const DEFAULT_CLINIC_SITE = "Studio Pontecorvo";

// ── Google Review ──────────────────────────────────────────
// Sostituire con il link reale della pagina Google Business
const GOOGLE_REVIEW_LINK_FALLBACK = "https://www.google.com/maps/place//data=!4m3!3m2!1s0x133ab7000a9c53d3:0xf706ba51f69901bf!12e1?source=g.page.m.ia._&laa=nmx-review-solicitation-ia2";

function statusColor(status: Status) {
  switch (status) {
    case "done":
      return THEME.green;
    case "confirmed":
      return THEME.blue;
    case "not_paid":
      return THEME.amber;
    case "cancelled":
      return THEME.gray;
    case "booked":
    default:
      return THEME.red;
  }
}

function statusBg(status: Status) {
  switch (status) {
    case "done":      return "#16a34a";
    case "confirmed": return "#2563eb";
    case "not_paid":  return "#f97316";
    case "cancelled": return "#94a3b8";
    case "booked":
    default:          return "#dc2626";
  }
}


function statusLabel(status: Status) {
  switch (status) {
    case "confirmed":
      return "Confermato";
    case "done":
      return "Eseguito";
    case "not_paid":
      return "Non pagata";
    case "cancelled":
      return "Annullato";
    default:
      return "Prenotato";
  }
}

// Auto-fit font size for patient full name inside event blocks without breaking layout
function autoNameFontSize(fullName?: string | null) {
  const n = ((fullName ?? "") as string).trim().length;
  if (n <= 14) return 13;
  if (n <= 20) return 12;
  if (n <= 28) return 11;
  if (n <= 36) return 10;
  return 9;
}

type TreatmentType = "seduta" | "macchinario" | "laser" | "tecar" | "onde_urto" | "tens";
const ALL_TREATMENTS: { value: TreatmentType; label: string; color: string }[] = [
  { value: "seduta",     label: "Seduta",       color: "#0d9488" },
  { value: "macchinario",label: "Macchinario",  color: "#2563eb" },
  { value: "laser",      label: "Laser",        color: "#d97706" },
  { value: "tecar",      label: "Tecar",        color: "#ea580c" },
  { value: "onde_urto",  label: "Onde d'urto",  color: "#7c3aed" },
  { value: "tens",       label: "TENS",         color: "#059669" },
];
function getTreatmentColor(tt: string | null | undefined): string {
  const found = ALL_TREATMENTS.find(t => t.value === tt);
  return found ? found.color : "#2563eb";
}
function getTreatmentLabel(tt: string | null | undefined): string {
  const found = ALL_TREATMENTS.find(t => t.value === tt);
  return found ? found.label : "Seduta";
}
function asTreatmentType(v: string | null | undefined): TreatmentType {
  const found = ALL_TREATMENTS.find(t => t.value === v);
  return found ? found.value : "seduta";
}

function asPriceType(v: string | null | undefined): "invoiced" | "cash" {
  return v === "cash" ? "cash" : "invoiced";
}


function fmtTime(iso: string) {
  const d = new Date(iso);
  return d.toLocaleTimeString("it-IT", { hour: "2-digit", minute: "2-digit" });
}

function pad2(n: number) {
  return String(n).padStart(2, "0");
}

function startOfISOWeekMonday(d: Date) {
  const date = new Date(d);
  const day = date.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  date.setDate(date.getDate() + diff);
  date.setHours(0, 0, 0, 0);
  return date;
}

function addDays(d: Date, days: number) {
  const x = new Date(d);
  x.setDate(x.getDate() + days);
  return x;
}

function formatDMY(d: Date) {
  return `${pad2(d.getDate())}/${pad2(d.getMonth() + 1)}/${d.getFullYear()}`;
}

function addWeeks(d: Date, w: number) {
  return addDays(d, w * 7);
}

function toDateInputValue(d: Date) {
  const year = d.getFullYear();
  const month = pad2(d.getMonth() + 1);
  const day = pad2(d.getDate());
  return `${year}-${month}-${day}`;
}

function parseDateInput(value: string) {
  const [y, m, d] = value.split("-").map(Number);
  const out = new Date();
  out.setFullYear(y, m - 1, d);
  out.setHours(0, 0, 0, 0);
  return out;
}

function generateRecurringStarts(params: {
  firstStart: Date;
  untilDate: Date;
  weekDays: number[];
  frequency?: number; // every N weeks (default 1)
}) {
  const { firstStart, untilDate, weekDays, frequency = 1 } = params;
  const hh = firstStart.getHours();
  const mm = firstStart.getMinutes();
  const ss = firstStart.getSeconds();
  const ms = firstStart.getMilliseconds();

  const startDay = new Date(firstStart);
  const endDay = new Date(untilDate);
  endDay.setHours(23, 59, 59, 999);

  const results: Date[] = [];
  
  // Calculate which week we're in relative to the start
  const weekStart = startOfISOWeekMonday(startDay);

  for (let d = new Date(startDay); d <= endDay; d = addDays(d, 1)) {
    const dow = d.getDay();
    if (dow === 0) continue;
    if (!weekDays.includes(dow)) continue;

    // Check if this day is in a valid week based on frequency
    if (frequency > 1) {
      const thisWeekStart = startOfISOWeekMonday(d);
      const weeksDiff = Math.round((thisWeekStart.getTime() - weekStart.getTime()) / (7 * 24 * 60 * 60 * 1000));
      if (weeksDiff % frequency !== 0) continue;
    }

    const occ = new Date(d);
    occ.setHours(hh, mm, ss, ms);
    if (occ < firstStart) continue;

    results.push(occ);
  }

  return results;
}

function formatDateRelative(date: Date): string {
  const oggi = new Date();
  oggi.setHours(0, 0, 0, 0);
  
  const domani = new Date(oggi);
  domani.setDate(oggi.getDate() + 1);
  
  const dataAppuntamento = new Date(date);
  dataAppuntamento.setHours(0, 0, 0, 0);
  
  if (dataAppuntamento.getTime() === oggi.getTime()) {
    return "Oggi";
  } else if (dataAppuntamento.getTime() === domani.getTime()) {
    return "Domani";
  } else {
    const giorni = ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato"];
    const mesi = ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", 
                  "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"];
    
    const giornoSettimana = giorni[dataAppuntamento.getDay()];
    const giorno = dataAppuntamento.getDate();
    const mese = mesi[dataAppuntamento.getMonth()];
    
    return `${giornoSettimana} ${giorno} ${mese}`;
  }
}

const CLINIC_ADDRESSES: Record<string, string> = {
  "Studio Pontecorvo": "Pontecorvo, Via Galileo Galilei 5, dietro il Bar Principe",
};

export default function CalendarPage() {
  return (
    <Suspense fallback={<div style={{ padding: 40, textAlign: "center", color: "#7b8fa3", fontFamily: "Inter, -apple-system, sans-serif", fontSize: 15 }}>Caricamento calendario…</div>}>
      <CalendarPageInner />
    </Suspense>
  );
}


function CalendarPageInner() {

  const params = useSearchParams();
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

// User menu (Logout + Settings)
const [userEmail, setUserEmail] = useState<string | null>(null);
const [userId, setUserId] = useState<string | null>(null);

  // Prezzi standard letti dai Settings (practice_settings)
  const [practiceSettings, setPracticeSettings] = useState<PracticeSettings | null>(null);
  const [practiceSettingsLoaded, setPracticeSettingsLoaded] = useState(false);
const [userMenuOpen, setUserMenuOpen] = useState(false);
const userMenuRef = useRef<HTMLDivElement | null>(null);


useEffect(() => {
  let mounted = true;
  (async () => {
    try {
      const { data } = await supabase.auth.getUser();
      if (!mounted) return;
      setUserEmail(data?.user?.email ?? null);
      setUserId(data?.user?.id ?? null);
    } catch {
      // ignore
    }
  })();
  return () => {
    mounted = false;
  };
}, []);

useEffect(() => {
  const onDown = (e: MouseEvent) => {
    if (!userMenuOpen) return;
    const el = userMenuRef.current;
    if (el && !el.contains(e.target as Node)) setUserMenuOpen(false);
  };
  document.addEventListener("mousedown", onDown);
  return () => document.removeEventListener("mousedown", onDown);
}, [userMenuOpen]);


  // Chiudi sidebar con ESC
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setSidebarOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

const handleLogout = useCallback(async () => {
  try {
    await supabase.auth.signOut();
  } finally {
    setUserMenuOpen(false);
    window.location.href = "/login";
  }
}, []);


  const loadPracticeSettings = useCallback(async () => {
    if (!userId) return;
    try {
      setPracticeSettingsLoaded(false);
      const { data, error } = await supabase
        .from("practice_settings")
        .select("standard_invoice, standard_cash, machine_invoice, machine_cash, auto_apply_prices, google_review_link, default_appointment_status")
        .eq("owner_id", userId)
        .maybeSingle();

      if (error) throw error;

      setPracticeSettings({
        standard_invoice: data?.standard_invoice ?? null,
        standard_cash: data?.standard_cash ?? null,
        machine_invoice: data?.machine_invoice ?? null,
        machine_cash: data?.machine_cash ?? null,
        auto_apply_prices: data?.auto_apply_prices ?? null,
        google_review_link: data?.google_review_link ?? null,
        default_appointment_status: (data?.default_appointment_status ?? "confirmed") as "confirmed"|"booked",
      });
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : String(e);
      console.warn("Impossibile caricare practice_settings:", msg);
      setPracticeSettings(null);
    } finally {
      setPracticeSettingsLoaded(true);
    }
  }, [userId]);

  useEffect(() => {
    if (!userId) return;
    loadPracticeSettings();
  }, [userId, loadPracticeSettings]);

  const getDefaultAmount = useCallback((tType: TreatmentType, pType: "invoiced" | "cash") => {
    // fallback sicuri (i tuoi vecchi default)
    const fallback = tType === "seduta"
      ? (pType === "invoiced" ? 40 : 35)
      : (pType === "invoiced" ? 25 : 20);

    if (!practiceSettings) return fallback;

    if (tType === "seduta") {
      const v = pType === "invoiced" ? practiceSettings.standard_invoice : practiceSettings.standard_cash;
      return (typeof v === "number" && !Number.isNaN(v)) ? v : fallback;
    } else {
      const v = pType === "invoiced" ? practiceSettings.machine_invoice : practiceSettings.machine_cash;
      return (typeof v === "number" && !Number.isNaN(v)) ? v : fallback;
    }
  }, [practiceSettings]);

const userLabel = useMemo(() => {
  if (!userEmail) return "Account";
  const left = userEmail.split("@")[0] || userEmail;
  return left.length > 18 ? left.slice(0, 18) + "…" : left;
}, [userEmail]);

const userInitials = useMemo(() => {
  if (!userEmail) return "U";
  const left = userEmail.split("@")[0] || "U";
  const parts = left.replace(/[^a-zA-Z0-9]/g, " ").split(" ").filter(Boolean);
  const a = (parts[0]?.[0] || "U").toUpperCase();
  const b = (parts[1]?.[0] || "").toUpperCase();
  return (a + b).slice(0, 2);
}, [userEmail]);



  const [selectedEvent, setSelectedEvent] = useState<{
    id: string;
    title: string;
    patient_id?: string;
    location?: LocationType | null;
    clinic_site?: string | null;
    domicile_address?: string | null;
    treatment?: string | null;
    diagnosis?: string | null;
    amount?: number | null;
    treatment_type?: string | null;
    price_type?: string | null;
    start?: Date;
    end?: Date;
  } | null>(null);

  const [editStatus, setEditStatus] = useState<Status>("booked");
  const [editNote, setEditNote] = useState("");
  const [editAmount, setEditAmount] = useState<string>("");
  const [editTreatmentType, setEditTreatmentType] = useState<TreatmentType>("seduta");
  const [editPriceType, setEditPriceType] = useState<"invoiced" | "cash">("invoiced");
  
  // Stati per modifica orario e giorno
  const [editDate, setEditDate] = useState<string>("");
  const [editStartTime, setEditStartTime] = useState<string>("09:00");
  const [editDuration, setEditDuration] = useState<"1" | "1.5" | "2">("1");

  const [createOpen, setCreateOpen] = useState(false);
  const [createStartISO, setCreateStartISO] = useState<string>("");
  const [createEndISO, setCreateEndISO] = useState<string>("");

  const [q, setQ] = useState("");
  const [searching, setSearching] = useState(false);
  const [patientResults, setPatientResults] = useState<PatientLite[]>([]);
  const [selectedPatient, setSelectedPatient] = useState<PatientLite | null>(null);
  const [creating, setCreating] = useState(false);
  const searchTimer = useRef<any>(null);

  const [createLocation, setCreateLocation] = useState<LocationType>("studio");
  const [createClinicSite, setCreateClinicSite] = useState(DEFAULT_CLINIC_SITE);
  const [createDomicileAddress, setCreateDomicileAddress] = useState("");

  const [treatmentType, setTreatmentType] = useState<TreatmentType>("seduta");
  const [priceType, setPriceType] = useState<"invoiced" | "cash">("cash"); // default: non fatturato
  const [customAmount, setCustomAmount] = useState<string>("");
  const [useCustomPrice, setUseCustomPrice] = useState(false);

  const computedDefaultAmount = useMemo(() => {
    return getDefaultAmount(treatmentType, priceType);
  }, [getDefaultAmount, treatmentType, priceType]);

  const [selectedStartTime, setSelectedStartTime] = useState<string>("09:00");
  const [selectedDuration, setSelectedDuration] = useState<"1" | "1.5" | "2">("1");

  const [isRecurring, setIsRecurring] = useState(false);
  const [recurringDays, setRecurringDays] = useState<number[]>([1, 2, 3, 4, 5, 6]);
  const [recurringUntil, setRecurringUntil] = useState<string>("");

  const [quickPatientOpen, setQuickPatientOpen] = useState(false);
  const [quickPatientFirstName, setQuickPatientFirstName] = useState("");
  const [quickPatientLastName, setQuickPatientLastName] = useState("");
  const [quickPatientPhone, setQuickPatientPhone] = useState("");
  const [creatingQuickPatient, setCreatingQuickPatient] = useState(false);

  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [clientReady, setClientReady] = useState(false);

  // Hydration-safe: mark client ready
  useEffect(() => {
    setCurrentDate(new Date());
    setClientReady(true);
  }, []);

  // ── Gestione parametri URL da GlobalSearch (?date=YYYY-MM-DD&view=day) ─────
  useEffect(() => {
    if (!clientReady) return;
    const dateStr = params.get("date");
    const view    = params.get("view");
    if (!dateStr && !view) return;

    if (view && view !== "week") {
      setViewType(view === "month" ? "month" : "day");
    }
    if (dateStr && /^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
      const [y, m, d] = dateStr.split("-").map(Number);
      setCurrentDate(new Date(y, m - 1, d));
    }
    // Pulisci URL senza ricaricare la pagina
    const url = new URL(window.location.href);
    if (!params.get("new")) {
      url.searchParams.delete("date");
      url.searchParams.delete("view");
      window.history.replaceState({}, "", url.toString());
    }
  }, [clientReady]);

  const [weeklyExpectedRevenue, setWeeklyExpectedRevenue] = useState<number>(0);

  const [viewType, setViewType] = useState<"day" | "week" | "month">("week");

  useEffect(() => {
    if (!clientReady) return;
    let cancelled = false;

    const loadPeriodStats = async () => {
      try {
        let periodStart: Date;
        let periodEnd: Date;

        if (viewType === "month") {
          // Intero mese
          periodStart = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
          periodStart.setHours(0, 0, 0, 0);
          periodEnd = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1);
          periodEnd.setHours(0, 0, 0, 0);
        } else {
          // Settimana corrente
          const today = new Date(currentDate);
          const day = today.getDay();
          const diffToMonday = (day === 0 ? -6 : 1) - day;
          periodStart = new Date(today);
          periodStart.setDate(today.getDate() + diffToMonday);
          periodStart.setHours(0, 0, 0, 0);
          periodEnd = new Date(periodStart);
          periodEnd.setDate(periodStart.getDate() + 7);
          periodEnd.setHours(0, 0, 0, 0);
        }

const { data, error } = await supabase
          .from("appointments")
          .select("amount, expected_price, status, start_at")
          .gte("start_at", periodStart.toISOString())
          .lt("start_at", periodEnd.toISOString());

        if (error) throw error;

        const rows = data ?? [];
        const validRows = rows.filter((r) => r.status !== "cancelled");

        const revenue = validRows.reduce((sum: number, r) => {
          const v = r.amount ?? r.expected_price ?? 0;
          return sum + Number(v);
        }, 0);

        if (!cancelled) setWeeklyExpectedRevenue(revenue);
      } catch {
        if (!cancelled) setWeeklyExpectedRevenue(0);
      }
    };

    loadPeriodStats();
    return () => {
      cancelled = true;
    };
  }, [currentDate, viewType, clientReady]);

  const [draggingEvent, setDraggingEvent] = useState<{
    id: string;
    originalStart: Date;
    originalEnd: Date;
  } | null>(null);
  const [draggingOver, setDraggingOver] = useState<{dayIndex: number, hour: number, minute: number} | null>(null);
  const [dragGhostPos, setDragGhostPos] = useState<{x: number, y: number} | null>(null);

  // Overlap warning
  const [overlapWarning, setOverlapWarning] = useState<string | null>(null);

  // Recurring frequency (every N weeks)
  const [recurringFrequency, setRecurringFrequency] = useState<1 | 2 | 3 | 4>(1);

  // Treatment type colors
  const TREATMENT_COLORS: Record<string, string> = {
    seduta: "#2563eb",       // blu ardesia smorzato
    macchinario: "#7c3aed",  // viola smorzato
  };

  const [printMenuOpen, setPrintMenuOpen] = useState(false);
  const [actionsMenuOpen, setActionsMenuOpen] = useState(false);
  const [filtersExpanded, setFiltersExpanded] = useState(false);
  const [filtersPopoverOpen, setFiltersPopoverOpen] = useState(false);
  const printMenuRef = useRef<HTMLDivElement>(null);

  // Feature: Ricerca rapida nel calendario
  const [calendarSearch, setCalendarSearch] = useState("");
  const [calendarSearchOpen, setCalendarSearchOpen] = useState(false);

  // Ricerca attiva quando >= 2 caratteri
  const isSearchActive = useMemo(() => calendarSearch.trim().length >= 2, [calendarSearch]);

  // IDs degli eventi che matchano la ricerca
  const searchMatchIds = useMemo(() => {
    const s = new Set<string>();
    if (!isSearchActive) return s;
    const q = calendarSearch.trim().toLowerCase();
    events.forEach(ev => {
      if (ev.patient_name.toLowerCase().includes(q)) s.add(ev.id);
    });
    return s;
  }, [isSearchActive, calendarSearch, events]);

  // Riepilogo giornaliero per il modal "Riepilogo di oggi"
  const dailySummary = useMemo(() => {
    const today = new Date();
    const todayEvts = events.filter(ev =>
      ev.start.getDate() === today.getDate() &&
      ev.start.getMonth() === today.getMonth() &&
      ev.start.getFullYear() === today.getFullYear() &&
      ev.status !== "cancelled"
    );
    const done = todayEvts.filter(ev => ev.status === "done").length;
    const notDone = todayEvts.filter(ev => ev.status !== "done").length;
    const unpaid = todayEvts.filter(ev => !ev.is_paid).length;
    const invoicedTotal = todayEvts.filter(ev => ev.price_type === "invoiced" && ev.is_paid).reduce((s, ev) => s + (ev.amount ?? 0), 0);
    const cashTotal = todayEvts.filter(ev => ev.price_type === "cash" && ev.is_paid).reduce((s, ev) => s + (ev.amount ?? 0), 0);
    const grandTotal = todayEvts.filter(ev => ev.is_paid).reduce((s, ev) => s + (ev.amount ?? 0), 0);
    return { total: todayEvts.length, done, notDone, unpaid, invoicedTotal, cashTotal, grandTotal, events: todayEvts };
  }, [events]);

  // Feature: Hover tooltip per mini-scheda paziente
  const [hoverTooltip, setHoverTooltip] = useState<{
    event: CalendarEvent;
    x: number;
    y: number;
  } | null>(null);
  const hoverTimer = useRef<any>(null);

  // Feature: Riepilogo giornaliero
  const [dailySummaryOpen, setDailySummaryOpen] = useState(false);

  // Feature: Segna pagato in blocco
  const [bulkMode, setBulkMode] = useState(false);
  const [bulkSelected, setBulkSelected] = useState<Set<string>>(new Set());

  // Feature: Popover vista mese
  const [monthPopover, setMonthPopover] = useState<{
    day: Date;
    events: CalendarEvent[];
    x: number;
    y: number;
  } | null>(null);

  const [currentTime, setCurrentTime] = useState(new Date());
  const [statusFilter, setStatusFilter] = useState<Status | "all">("all");
  const [showAvailableOnly, setShowAvailableOnly] = useState(false);

  const [showWhatsAppConfirm, setShowWhatsAppConfirm] = useState(false);
  const [lastCreatedAppointment, setLastCreatedAppointment] = useState<{
    id: string;
    patientPhone?: string | null;
    patientName?: string;
    startTime?: Date;
  } | null>(null);

  const [duplicateMode, setDuplicateMode] = useState(false);
  const [eventToDuplicate, setEventToDuplicate] = useState<CalendarEvent | null>(null);
  const [duplicateDate, setDuplicateDate] = useState<string>("");
  const [duplicateTime, setDuplicateTime] = useState<string>("09:00");

  // Stati per le nuove funzionalità
  const [filters, setFilters] = useState({
    location: "all" as "all" | "studio" | "domicile",
    treatmentType: "all" as "all" | TreatmentType,
    priceType: "all" as "all" | "invoiced" | "cash",
    minAmount: "",
    maxAmount: "",
  });

  const [eventColors, setEventColors] = useState<Record<string, string>>({});
  const [quickActionsMenu, setQuickActionsMenu] = useState<{
    x: number;
    y: number;
    eventId?: string;
  } | null>(null);

  const [todaysAppointments, setTodaysAppointments] = useState<CalendarEvent[]>([]);
  const [showAllUpcoming, setShowAllUpcoming] = useState(false);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const monthClickTimer = useRef<any>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [bookingRequests, setBookingRequests] = useState<BookingRequest[]>([]);
  const [bookingPanel, setBookingPanel] = useState(false);
  const [bookingLoading, setBookingLoading] = useState(false);
  const [bookingActionId, setBookingActionId] = useState<string | null>(null);

  
  // Sidebar behavior: overlay on mobile, "push content" on desktop
  const SIDEBAR_W = 300;
  const [isDesktop, setIsDesktop] = useState(false);
  const [isTablet, setIsTablet] = useState(false);

  // Responsive time column width
  const TIME_COL = isTablet && !isDesktop ? 50 : 80;

  useEffect(() => {
    if (typeof window === "undefined") return;
    const mqlDesktop = window.matchMedia("(min-width: 1024px)");
    const mqlTablet = window.matchMedia("(min-width: 768px) and (max-width: 1199px)");
    const update = () => {
      const desk = mqlDesktop.matches;
      const tab = mqlTablet.matches;
      setIsDesktop(desk);
      setIsTablet(tab);
      // Su tablet: default vista giorno (più comoda touch)
      if (tab && !desk) {
        setViewType(prev => prev === "week" ? "day" : prev);
      }
    };
    update();
    if (mqlDesktop.addEventListener) {
      mqlDesktop.addEventListener("change", update);
      mqlTablet.addEventListener("change", update);
    }
    return () => {
      if (mqlDesktop.removeEventListener) {
        mqlDesktop.removeEventListener("change", update);
        mqlTablet.removeEventListener("change", update);
      }
    };
  }, []);
// Timer per linea del tempo corrente
  useEffect(() => {
    setCurrentTime(new Date());
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);
    return () => clearInterval(timer);
  }, []);

  // Carica appuntamenti della giornata corrente per il menu laterale
  useEffect(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);

    const todaysEvents = events.filter(event => {
      const eventDate = new Date(event.start);
      eventDate.setHours(0, 0, 0, 0);
      return eventDate.getTime() === today.getTime() && event.status !== "cancelled";
    });

    // Ordina per orario
    const sortedEvents = [...todaysEvents].sort((a, b) => 
      a.start.getTime() - b.start.getTime()
    );

    setTodaysAppointments(sortedEvents);

    // reset espansione lista imminenti quando cambia il contenuto
    setShowAllUpcoming(false);
  }, [events]);

  // Dichiarazioni delle costanti useMemo devono essere PRIMA delle funzioni che le usano
  const timeSelectSlots = useMemo(() => {
    const slots = [];
    for (let hour = 7; hour < 22; hour++) {
      for (let minute of [0, 30]) {
        slots.push(`${pad2(hour)}:${pad2(minute)}`);
      }
    }
    return slots;
  }, []);

  // Funzioni di navigazione spostate PRIMA degli useEffect che le usano
  const goToPreviousWeek = useCallback(() => {
    setCurrentDate(prev => addWeeks(prev, -1));
  }, []);

  const goToNextWeek = useCallback(() => {
    setCurrentDate(prev => addWeeks(prev, 1));
  }, []);

  const goToToday = useCallback(() => {
    setCurrentDate(new Date());
  }, []);

  const gotoWeekStart = useCallback((iso: string) => {
    setCurrentDate(new Date(iso));
  }, []);

  // Opzioni settimane per il select nella navbar (±8 settimane dalla corrente)
  const weekOptions = useMemo(() => {
    const options: { value: string; label: string }[] = [];
    const now = startOfISOWeekMonday(new Date());
    for (let i = -8; i <= 8; i++) {
      const weekStart = addWeeks(now, i);
      const weekEnd = addDays(weekStart, 6);
      const mesi = ["Gen","Feb","Mar","Apr","Mag","Giu","Lug","Ago","Set","Ott","Nov","Dic"];
      const label = `${formatDMY(weekStart)} – ${weekEnd.getDate()} ${mesi[weekEnd.getMonth()]}`;
      options.push({ value: weekStart.toISOString(), label });
    }
    return options;
  }, []);

  // Ritorna statistiche occupazione per un giorno (usato nell'header settimana)
  const getAvailabilityForecast = useCallback((day: Date) => {
    const d0 = new Date(day); d0.setHours(0,0,0,0);
    const d1 = new Date(day); d1.setHours(23,59,59,999);
    const dayEvts = events.filter(ev =>
      ev.status !== "cancelled" && ev.start >= d0 && ev.start <= d1
    );
    const totalMinutes = 8 * 60; // 8-20 = 12h = 720min, ma usiamo 8h lavorative
    const usedMinutes = dayEvts.reduce((s, ev) => {
      return s + Math.max(0, (ev.end.getTime() - ev.start.getTime()) / 60000);
    }, 0);
    const occupancyRate = Math.round(Math.min((usedMinutes / totalMinutes) * 100, 100));
    return { totalEvents: dayEvts.length, occupancyRate };
  }, [events]);

  // Ritorna le finestre libere di un giorno (usato con showAvailableOnly)
  const getFreeWindows = useCallback((day: Date) => {
    const WORK_START = 8, WORK_END = 20;
    const d0 = new Date(day); d0.setHours(0,0,0,0);
    const d1 = new Date(day); d1.setHours(23,59,59,999);
    const dayEvts = events
      .filter(ev => ev.status !== "cancelled" && ev.start >= d0 && ev.start <= d1)
      .sort((a, b) => a.start.getTime() - b.start.getTime());

    const windows: { start: Date; end: Date; minutes: number }[] = [];
    let cursor = new Date(day); cursor.setHours(WORK_START, 0, 0, 0);
    const workEnd = new Date(day); workEnd.setHours(WORK_END, 0, 0, 0);

    for (const ev of dayEvts) {
      if (ev.start > cursor) {
        const mins = Math.round((ev.start.getTime() - cursor.getTime()) / 60000);
        if (mins >= 30) windows.push({ start: new Date(cursor), end: new Date(ev.start), minutes: mins });
      }
      if (ev.end > cursor) cursor = new Date(ev.end);
    }
    if (cursor < workEnd) {
      const mins = Math.round((workEnd.getTime() - cursor.getTime()) / 60000);
      if (mins >= 30) windows.push({ start: new Date(cursor), end: new Date(workEnd), minutes: mins });
    }
    return windows;
  }, [events]);

  const openCreateModal = useCallback((date: Date, hour: number = 9, minute: number = 0, duplicateEvent?: CalendarEvent) => {
    const timeStr = `${pad2(hour)}:${pad2(minute)}`;
    
    const defaultTime = duplicateEvent ? 
      `${pad2(duplicateEvent.start.getHours())}:${pad2(duplicateEvent.start.getMinutes())}` : 
      timeSelectSlots.includes(timeStr) ? timeStr : "09:00";
    
    setSelectedStartTime(defaultTime);
    setDuplicateTime(defaultTime);
    
    const startTime = new Date(date);
    const [hours, minutes] = defaultTime.split(':').map(Number);
    startTime.setHours(hours, minutes, 0, 0);
    
    const durationHours = parseFloat(selectedDuration);
    const endTime = new Date(startTime.getTime() + durationHours * 60 * 60000);

    setCreateStartISO(startTime.toISOString());
    setCreateEndISO(endTime.toISOString());
    
    setDuplicateDate(toDateInputValue(date));

    setQ("");
    setPatientResults([]);
    setSelectedPatient(null);

    if (duplicateEvent) {
      setDuplicateMode(true);
      setEventToDuplicate(duplicateEvent);
      setCreateLocation(duplicateEvent.location ?? "studio");
      setCreateClinicSite(duplicateEvent.clinic_site || DEFAULT_CLINIC_SITE);
      setCreateDomicileAddress(duplicateEvent.domicile_address || "");
      setTreatmentType((duplicateEvent.treatment_type as "seduta" | "macchinario") || "seduta");
      setPriceType((duplicateEvent.price_type as "invoiced" | "cash") || "invoiced");
      setCustomAmount(duplicateEvent.amount ? duplicateEvent.amount.toString() : "");
      setUseCustomPrice(!!duplicateEvent.amount);
      
      const eventDurationHours = (duplicateEvent.end.getTime() - duplicateEvent.start.getTime()) / (60 * 60000);
      if (eventDurationHours === 1) setSelectedDuration("1");
      else if (eventDurationHours === 1.5) setSelectedDuration("1.5");
      else if (eventDurationHours === 2) setSelectedDuration("2");
      
      // Pre-seleziona il paziente direttamente — nessuna ricerca manuale
      const patientFromEvent = {
        id: duplicateEvent.patient_id,
        first_name: duplicateEvent.patient_first_name || '',
        last_name: duplicateEvent.patient_last_name || '',
        phone: duplicateEvent.patient_phone || null,
      };
      setSelectedPatient(patientFromEvent);
    } else {
      setDuplicateMode(false);
      setEventToDuplicate(null);
      setCreateLocation("studio");
      setCreateClinicSite(DEFAULT_CLINIC_SITE);
      setCreateDomicileAddress("");
      setTreatmentType("seduta");
      setPriceType("invoiced");
      setCustomAmount("");
      setUseCustomPrice(false);
    }

    setIsRecurring(false);
    const dow = date.getDay();
    const defaultDays = dow === 0 ? [1] : [dow];
    setRecurringDays(defaultDays);
    setRecurringUntil(toDateInputValue(addWeeks(date, 4)));

    setQuickPatientFirstName("");
    setQuickPatientLastName("");
    setQuickPatientPhone("");

    setShowWhatsAppConfirm(false);
    setLastCreatedAppointment(null);

    setError("");
    setCreateOpen(true);
  }, [selectedStartTime, selectedDuration, timeSelectSlots, patientResults]);

  // Shortcut da tastiera - ORA le funzioni sono disponibili
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl/Cmd + N: Nuovo appuntamento
      if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
        e.preventDefault();
        openCreateModal(new Date());
      }
      
      // Esc: Chiudi modal
      if (e.key === 'Escape') {
        if (createOpen) setCreateOpen(false);
        if (selectedEvent) setSelectedEvent(null);
        if (showWhatsAppConfirm) setShowWhatsAppConfirm(false);
        if (quickActionsMenu) setQuickActionsMenu(null);
      }
      
      // Freccia sinistra/destra: Naviga tra settimane/giorni/mesi
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        if (viewType === 'week') goToPreviousWeek();
        else if (viewType === 'month') goToPreviousMonth();
        else setCurrentDate(prev => addDays(prev, -1));
      }
      
      if (e.key === 'ArrowRight') {
        e.preventDefault();
        if (viewType === 'week') goToNextWeek();
        else if (viewType === 'month') goToNextMonth();
        else setCurrentDate(prev => addDays(prev, 1));
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [createOpen, selectedEvent, showWhatsAppConfirm, quickActionsMenu, viewType, goToPreviousWeek, goToNextWeek, goToToday, openCreateModal]);

  // Chiudi menu quick actions al click fuori
  useEffect(() => {
    const handleClick = () => setQuickActionsMenu(null);
    document.addEventListener('click', handleClick);
    return () => document.removeEventListener('click', handleClick);
  }, []);

  const weekDays = useMemo(() => {
    const days = [];
    const startOfWeek = startOfISOWeekMonday(currentDate);
    
    for (let i = 0; i < 6; i++) {
      const day = addDays(startOfWeek, i);
      days.push(day);
    }
    return days;
  }, [currentDate]);

  const timeSlots = useMemo(() => {
    const slots = [];
    for (let hour = 7; hour < 22; hour++) {
      slots.push(`${pad2(hour)}:00`);
    }
    return slots;
  }, []);

  const getEventPosition = useCallback((start: Date, end: Date) => {
    const startHour = start.getHours();
    const startMinute = start.getMinutes();
    const endHour = end.getHours();
    const endMinute = end.getMinutes();
    
    const top = ((startHour - 7) * 60 + startMinute);
    const height = ((endHour - startHour) * 60 + (endMinute - startMinute));
    
    return { top, height };
  }, []);

  // Vista giorno: 2px per minuto → 1 ora = 120px, molto più leggibile
  const DAY_PX_PER_MIN = 1;
  const getDayEventPosition = useCallback((start: Date, end: Date) => {
    const startHour = start.getHours();
    const startMinute = start.getMinutes();
    const endHour = end.getHours();
    const endMinute = end.getMinutes();
    const top    = ((startHour - 7) * 60 + startMinute) * DAY_PX_PER_MIN;
    const height = ((endHour - startHour) * 60 + (endMinute - startMinute)) * DAY_PX_PER_MIN;
    return { top, height };
  }, []);

  const getEventColor = useCallback((event: CalendarEvent | { status: Status; patient_id?: string; treatment_type?: string | null }) => {
    if (event.patient_id && eventColors[event.patient_id]) {
      return eventColors[event.patient_id];
    }
    if ("treatment_type" in event && event.treatment_type) {
      return getTreatmentColor(event.treatment_type);
    }
    return statusColor(event.status);
  }, [eventColors]);

  const handleEventHover = useCallback((e: React.MouseEvent, event: CalendarEvent) => {
    if (hoverTimer.current) clearTimeout(hoverTimer.current);
    hoverTimer.current = setTimeout(() => {
      setHoverTooltip({ event, x: e.clientX, y: e.clientY });
    }, 600);
  }, []);

  const handleEventHoverEnd = useCallback(() => {
    if (hoverTimer.current) clearTimeout(hoverTimer.current);
    setHoverTooltip(null);
  }, []);

  // Restituisce slot liberi per un giorno (usato nel modal creazione per suggerire orario)
  const getAvailableSlots = useCallback((day: Date) => {
    const WORK_START = 8, WORK_END = 20;
    const d0 = new Date(day); d0.setHours(0,0,0,0);
    const d1 = new Date(day); d1.setHours(23,59,59,999);
    const dayEvts = events
      .filter(ev => ev.status !== "cancelled" && ev.start >= d0 && ev.start <= d1)
      .sort((a, b) => a.start.getTime() - b.start.getTime());
    const slots: { start: Date; end: Date }[] = [];
    let cursor = new Date(day); cursor.setHours(WORK_START, 0, 0, 0);
    const workEnd = new Date(day); workEnd.setHours(WORK_END, 0, 0, 0);
    for (const ev of dayEvts) {
      if (ev.start > cursor) slots.push({ start: new Date(cursor), end: new Date(ev.start) });
      if (ev.end > cursor) cursor = new Date(ev.end);
    }
    if (cursor < workEnd) slots.push({ start: new Date(cursor), end: new Date(workEnd) });
    return slots;
  }, [events]);

  const loadRequestId = useRef(0);

  const loadAppointments = useCallback(async (startDate: Date, endDate: Date, retryCount = 0) => {
    const thisRequest = ++loadRequestId.current;
    setLoading(true);
    setError("");

    const startISO = startDate.toISOString();
    const endISO = endDate.toISOString();

    try {
      const { data, error } = await supabase
        .from("appointments")
          .select(`
          id, patient_id, start_at, end_at, status, calendar_note, location, clinic_site, domicile_address, treatment_type, price_type, amount,
          expected_price, is_paid,
          reminder_sent_at, reminder_status,
          whatsapp_sent_at,
          patients:patient_id ( first_name, last_name, treatment, diagnosis, phone )
        `)
        .gte("start_at", startISO)
        .lt("start_at", endISO)
        .order("start_at", { ascending: true });

      // Ignore stale responses
      if (thisRequest !== loadRequestId.current) return;

      if (error) {
        if (retryCount < 2) {
          // Retry after short delay
          setTimeout(() => loadAppointments(startDate, endDate, retryCount + 1), 1000);
          return;
        }
        setError(error.message);
        setLoading(false);
        return;
      }

const mapped = (data ?? []).map(
  (
    a: {
      id: string;
      patient_id: string;
      start_at: string;
      end_at: string;
      status: string;
      calendar_note?: string | null;
      location?: string | null;
      clinic_site?: string | null;
      domicile_address?: string | null;
      treatment_type?: string | null;
      price_type?: string | null;
      amount?: number | null;
      expected_price?: number | null;
      is_paid?: boolean | null;
      reminder_sent_at?: string | null;
      reminder_status?: string | null;
      whatsapp_sent_at?: string | null;
      patients?: Array<{
        first_name?: string;
        last_name?: string;
        treatment?: string;
        diagnosis?: string;
        phone?: string;
      }>;
    }
  ) => {
    const patient = Array.isArray(a.patients) ? a.patients[0] : a.patients;

    // Se non c'è paziente (prenotazione web), estrai nome dal calendar_note
    // Formato: "[WEB|Nome Cognome|Telefono] Servizio..."
    let name = patient
      ? `${patient.last_name ?? ""} ${patient.first_name ?? ""}`.trim()
      : "Paziente";

    if (!patient && a.calendar_note) {
      const match = (a.calendar_note as string).match(/^\[WEB\|([^|]+)\|/);
      if (match && match[1]) name = match[1].trim();
    }


    return {
      id: a.id,
      patient_id: a.patient_id,
      title: name,
      start: new Date(a.start_at),
      end: new Date(a.end_at),
      status: a.status as Status,
      calendar_note: a.calendar_note ?? null,
      location: (a.location as LocationType) ?? null,
      clinic_site: a.clinic_site ?? null,
      domicile_address: a.domicile_address ?? null,
      treatment_type: a.treatment_type ?? null,
      price_type: a.price_type ?? null,
      amount: a.amount ?? null,
      expected_price: a.expected_price ?? null,
      is_paid: a.is_paid ?? false,
      reminder_sent_at: a.reminder_sent_at ? new Date(a.reminder_sent_at) : null,
      reminder_status: a.reminder_status ?? null,
      whatsapp_sent_at: a.whatsapp_sent_at ? new Date(a.whatsapp_sent_at) : null,

      // dati paziente (prima riga della relazione)
      patient_name: name,
      patient_first_name: patient?.first_name ?? null,
      patient_last_name: patient?.last_name ?? null,
      patient_phone: patient?.phone ?? null,
treatment: patient?.treatment ?? null,
diagnosis: patient?.diagnosis ?? null,

    };
  }
);

    setEvents(mapped);
    setLoading(false);
    } catch (err) {
      if (thisRequest !== loadRequestId.current) return;
      if (retryCount < 2) {
        setTimeout(() => loadAppointments(startDate, endDate, retryCount + 1), 1000);
      } else {
        setError(`Errore caricamento: ${err instanceof Error ? err.message : "connessione fallita"}`);
        setLoading(false);
      }
    }
  }, []);

  useEffect(() => {
    if (!clientReady) return;
    
    if (viewType === "week") {
      const startOfWeek = startOfISOWeekMonday(currentDate);
      const endOfWeek = addDays(startOfWeek, 7);
      loadAppointments(startOfWeek, endOfWeek);
    } else if (viewType === "month") {
      const year = currentDate.getFullYear();
      const month = currentDate.getMonth();
      const firstDay = new Date(year, month, 1);
      const startOffset = (firstDay.getDay() === 0 ? 6 : firstDay.getDay() - 1);
      const calStart = addDays(firstDay, -startOffset);
      const calEnd = addDays(calStart, 42);
      loadAppointments(calStart, calEnd);
    } else {
      const startOfDay = new Date(currentDate);
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date(currentDate);
      endOfDay.setHours(23, 59, 59, 999);
      loadAppointments(startOfDay, endOfDay);
    }
  }, [currentDate, viewType, loadAppointments, clientReady]);

  // filteredEvents: visibili nella vista corrente — disponibile a tutto il componente
  const filteredEvents = useMemo(() => {
    if (viewType === "week" || viewType === "month") return events;
    return events.filter(e =>
      e.start.getDate() === currentDate.getDate() &&
      e.start.getMonth() === currentDate.getMonth() &&
      e.start.getFullYear() === currentDate.getFullYear()
    );
  }, [events, viewType, currentDate]);

  const stats = useMemo(() => {
    return {
      total: filteredEvents.length,
      done: filteredEvents.filter(e => e.status === "done").length,
      confirmed: filteredEvents.filter(e => e.status === "confirmed").length,
      booked: filteredEvents.filter(e => e.status === "booked").length,
      revenue: filteredEvents.reduce((sum, e) => {
        if (e.status !== "done") return sum;
        if (e.amount !== undefined && e.amount !== null) {
          return sum + e.amount;
        }
        const tType = (e.treatment_type === "macchinario" ? "macchinario" : "seduta") as "seduta" | "macchinario";
        const pType = (e.price_type === "cash" ? "cash" : "invoiced") as "invoiced" | "cash";
        return sum + getDefaultAmount(tType, pType);
      }, 0),
    };
  }, [filteredEvents, getDefaultAmount]);

  const exportAppointments = useCallback(() => {
    const csvContent = [
      ["Data", "Ora Inizio", "Ora Fine", "Paziente", "Stato", "Trattamento", "Prezzo", "Sede", "Fatturato"],
      ...events.map(e => [
        formatDMY(e.start),
        fmtTime(e.start.toISOString()),
        fmtTime(e.end.toISOString()),
        e.patient_name,
        statusLabel(e.status),
        e.treatment_type === "seduta" ? "Seduta" : "Macchinario",
        e.amount !== undefined && e.amount !== null ? `€${e.amount}` : `€${getDefaultAmount(asTreatmentType(e.treatment_type), asPriceType(e.price_type))}`,
        e.location === "domicile" ? "DOMICILIO" : e.clinic_site,
        e.price_type === "invoiced" ? "Sì" : "No"
      ])
    ].map(row => row.join(",")).join("\n");
    
    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `appuntamenti_${formatDMY(new Date())}.csv`;
    a.click();
    
    window.URL.revokeObjectURL(url);
  }, [events]);

  const exportToPDF = useCallback(() => {
    // Raccoglie eventi della settimana corrente (Lun-Sab)
    const weekStart = startOfISOWeekMonday(currentDate);
    const days = Array.from({ length: 6 }, (_, i) => {
      const d = new Date(weekStart); d.setDate(d.getDate() + i); return d;
    });
    const GG = ["Lunedì","Martedì","Mercoledì","Giovedì","Venerdì","Sabato"];
    const MESI = ["Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"];

    const statusColors: Record<string, string> = {
      done: "#16a34a", confirmed: "#2563eb", not_paid: "#f97316",
      cancelled: "#94a3b8", booked: "#dc2626",
    };
    const statusLabels: Record<string, string> = {
      done: "Eseguito", confirmed: "Confermato", not_paid: "Non pagata",
      cancelled: "Annullato", booked: "Prenotato",
    };

    const totalSedute = events.filter(e => e.status !== "cancelled" &&
      days.some(d => e.start.toDateString() === d.toDateString())).length;
    const totalIncasso = events.filter(e => e.is_paid &&
      days.some(d => e.start.toDateString() === d.toDateString()))
      .reduce((s, e) => s + (e.amount ?? 0), 0);
    const totalDaIncassare = events.filter(e => !e.is_paid && e.status !== "cancelled" &&
      days.some(d => e.start.toDateString() === d.toDateString()))
      .reduce((s, e) => s + (e.amount ?? 0), 0);

    const html = `<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Planning Settimanale — FisioHub</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', system-ui, -apple-system, sans-serif; background: #f8fafc; color: #0f172a; }
  @page { size: A4 landscape; margin: 12mm 10mm; }
  @media print { body { background: white; } .no-print { display: none; } }

  /* Header */
  .header { background: linear-gradient(135deg, #0d9488, #2563eb); color: white; padding: 16px 24px; display: flex; justify-content: space-between; align-items: center; border-radius: 12px; margin-bottom: 12px; }
  .header-logo { display: flex; align-items: center; gap: 10px; }
  .logo-box { width: 36px; height: 36px; background: rgba(255,255,255,0.2); border-radius: 8px; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 18px; border: 1.5px solid rgba(255,255,255,0.3); }
  .logo-text { font-size: 20px; font-weight: 800; letter-spacing: 1px; text-transform: uppercase; }
  .header-title { text-align: center; }
  .header-title h1 { font-size: 16px; font-weight: 700; opacity: 0.9; }
  .header-title p { font-size: 13px; opacity: 0.75; margin-top: 2px; }
  .header-kpi { display: flex; gap: 16px; }
  .kpi { text-align: right; }
  .kpi-label { font-size: 10px; opacity: 0.7; text-transform: uppercase; letter-spacing: 0.5px; }
  .kpi-value { font-size: 18px; font-weight: 800; }

  /* Griglia giorni */
  .grid { display: grid; grid-template-columns: repeat(6, 1fr); gap: 6px; }
  .day-col { background: white; border-radius: 8px; border: 1px solid #e2e8f0; overflow: hidden; }
  .day-header { padding: 8px 10px; background: #f1f5f9; border-bottom: 1px solid #e2e8f0; }
  .day-name { font-size: 11px; font-weight: 700; color: #475569; text-transform: uppercase; letter-spacing: 0.5px; }
  .day-date { font-size: 18px; font-weight: 800; color: #0f172a; line-height: 1.1; }
  .day-date.today { color: #2563eb; }
  .day-count { font-size: 10px; color: #94a3b8; margin-top: 2px; }
  .day-body { padding: 6px; display: flex; flex-direction: column; gap: 4px; min-height: 80px; }

  /* Card appuntamento */
  .appt { border-radius: 6px; padding: 6px 8px; border: 0.5px solid; page-break-inside: avoid; }
  .appt-time { font-size: 10px; font-weight: 600; margin-bottom: 3px; display: flex; justify-content: space-between; align-items: center; }
  .appt-name { font-size: 11px; font-weight: 700; color: #0f172a; line-height: 1.25; word-break: break-word; }
  .appt-footer { display: flex; justify-content: space-between; align-items: center; margin-top: 4px; }
  .appt-type { font-size: 9px; color: #64748b; }
  .appt-badge { font-size: 9px; font-weight: 600; padding: 1px 5px; border-radius: 99px; }
  .appt-icons { display: flex; gap: 3px; align-items: center; font-size: 11px; }
  .empty-day { color: #cbd5e1; font-size: 11px; text-align: center; padding: 12px 0; }

  /* Footer */
  .footer { margin-top: 10px; display: flex; justify-content: space-between; align-items: center; padding: 8px 12px; background: white; border-radius: 8px; border: 1px solid #e2e8f0; }
  .footer-left { font-size: 10px; color: #64748b; }
  .legend { display: flex; gap: 12px; align-items: center; }
  .legend-item { display: flex; align-items: center; gap: 4px; font-size: 10px; color: #475569; }
  .legend-dot { width: 8px; height: 8px; border-radius: 99px; }
  .print-btn { display: block; margin: 12px auto; padding: 10px 28px; background: linear-gradient(135deg,#0d9488,#2563eb); color: white; border: none; border-radius: 8px; font-size: 14px; font-weight: 700; cursor: pointer; }
</style>
</head>
<body>

<div class="no-print" style="text-align:center; padding: 12px;">
  <button class="print-btn" onclick="window.print()">🖨 Stampa / Salva PDF</button>
</div>

<div class="header">
  <div class="header-logo">
    <div class="logo-box">F</div>
    <div class="logo-text">FisioHub</div>
  </div>
  <div class="header-title">
    <h1>Planning Settimanale</h1>
    <p>${GG[0]} ${days[0].getDate()} — ${GG[5]} ${days[5].getDate()} ${MESI[days[0].getMonth()]} ${days[0].getFullYear()}</p>
  </div>
  <div class="header-kpi">
    <div class="kpi">
      <div class="kpi-label">Sedute</div>
      <div class="kpi-value">${totalSedute}</div>
    </div>
    <div class="kpi">
      <div class="kpi-label">Incassato</div>
      <div class="kpi-value">€${totalIncasso}</div>
    </div>
    <div class="kpi">
      <div class="kpi-label">Da incassare</div>
      <div class="kpi-value" style="color:#fbbf24">€${totalDaIncassare}</div>
    </div>
  </div>
</div>

<div class="grid">
${days.map((day, di) => {
  const isToday = day.toDateString() === new Date().toDateString();
  const dayEvs = events
    .filter(e => e.start.toDateString() === day.toDateString() && e.status !== "cancelled")
    .sort((a, b) => a.start.getTime() - b.start.getTime());

  return `
  <div class="day-col">
    <div class="day-header">
      <div class="day-name">${GG[di]}</div>
      <div class="day-date ${isToday ? "today" : ""}">${day.getDate()}</div>
      <div class="day-count">${dayEvs.length > 0 ? `${dayEvs.length} appuntament${dayEvs.length === 1 ? "o" : "i"}` : "Giorno libero"}</div>
    </div>
    <div class="day-body">
      ${dayEvs.length === 0 ? `<div class="empty-day">—</div>` : dayEvs.map(ev => {
        const col = statusColors[ev.status] ?? "#94a3b8";
        const bg = col + "14";
        const bc = col + "40";
        const label = statusLabels[ev.status] ?? "—";
        const fmtT = (d: Date) => d.toLocaleTimeString("it-IT", { hour: "2-digit", minute: "2-digit" });
        return `
        <div class="appt" style="background:${bg}; border-color:${bc}">
          <div class="appt-time" style="color:${col}">
            <span>${fmtT(ev.start)}–${fmtT(ev.end)}</span>
            <span class="appt-icons">${ev.location === "domicile" ? "🏠" : ""}${ev.is_paid ? "🪙" : ""}</span>
          </div>
          <div class="appt-name">${ev.patient_name}${ev.status === "cancelled" ? " (annullato)" : ""}</div>
          <div class="appt-footer">
            <span class="appt-type">${ev.treatment_type === "macchinario" ? "Macchinario" : "Seduta"}${ev.amount ? ` · €${ev.amount}` : ""}</span>
            <span class="appt-badge" style="color:${col}; background:${col}18">${label}</span>
          </div>
          ${ev.calendar_note ? `<div style="font-size:9px; color:#64748b; margin-top:3px; font-style:italic">📝 ${ev.calendar_note}</div>` : ""}
        </div>`;
      }).join("")}
    </div>
  </div>`;
}).join("")}
</div>

<div class="footer">
  <div class="footer-left">
    Generato da FisioHub · ${new Date().toLocaleDateString("it-IT", { day: "numeric", month: "long", year: "numeric" })} alle ${new Date().toLocaleTimeString("it-IT", { hour: "2-digit", minute: "2-digit" })}
  </div>
  <div class="legend">
    <div class="legend-item"><div class="legend-dot" style="background:#2563eb"></div>Confermato</div>
    <div class="legend-item"><div class="legend-dot" style="background:#16a34a"></div>Eseguito</div>
    <div class="legend-item"><div class="legend-dot" style="background:#f97316"></div>Non pagata</div>
    <div class="legend-item"><div class="legend-dot" style="background:#dc2626"></div>Prenotato</div>
    <div class="legend-item">🪙 Pagato</div>
    <div class="legend-item">🏠 Domicilio</div>
  </div>
</div>

</body>
</html>`;

    const win = window.open("", "_blank", "width=1200,height=800");
    if (win) { win.document.write(html); win.document.close(); }
  }, [events, currentDate]);

  // ─── Booking requests ────────────────────────────────────────────────────
  const loadBookingRequests = useCallback(async () => {
    setBookingLoading(true);
    const { data } = await supabase
      .from("booking_requests")
      .select("*")
      .in("status", ["pending", "confirmed", "cancelled"])
      .order("created_at", { ascending: false })
      .limit(50);
    setBookingRequests(data ?? []);
    setBookingLoading(false);
  }, []);

  useEffect(() => { void loadBookingRequests(); }, [loadBookingRequests]);

  async function confirmBooking(req: BookingRequest) {
    setBookingActionId(req.id);
    try {
      // 1. Aggiorna stato in booking_requests
      const { error: updErr } = await supabase
        .from("booking_requests")
        .update({ status: "confirmed" })
        .eq("id", req.id);
      if (updErr) { alert("Errore aggiornamento: " + updErr.message); return; }

      // 2. Crea appuntamento — stesso metodo usato dal form del calendario
      const timeStr = req.requested_time.slice(0, 5); // "HH:MM"
      const [th, tm] = timeStr.split(":").map(Number);
      const [dy, dm, dd] = req.requested_date.split("-").map(Number);

      // Costruisce data locale (come fa il form normale del calendario)
      const startDt = new Date(dy, dm - 1, dd);
      startDt.setHours(th, tm, 0, 0);
      if (isNaN(startDt.getTime())) { alert("Data non valida"); return; }

      const durationMin = Number(req.service_duration);
      const endDt = new Date(startDt.getTime() + durationMin * 60 * 1000);

      // toISOString() converte in UTC — uguale a come funzionano tutti gli altri appuntamenti
      const startAt = startDt.toISOString();
      const endAt   = endDt.toISOString();

      console.log("[booking] start:", startAt, "end:", endAt, "durata:", durationMin, "min");

      const note = `[WEB|${req.patient_name}|${req.patient_phone}] ${req.service_name}${req.notes ? ` - ${req.notes}` : ""}`;

      // Determina location in base al servizio
      const isHome = req.service_name.toLowerCase().includes("domicil");
      const locationVal = isHome ? "domicile" : "studio";

      const { error: insErr } = await supabase.from("appointments").insert({
        start_at:         startAt,
        end_at:           endAt,
        status:           "booked",
        is_paid:          false,
        location:         locationVal,
        clinic_site:      isHome ? null : DEFAULT_CLINIC_SITE,
        domicile_address: isHome ? (req.notes ?? "da definire") : null,
        calendar_note:    note,
      });
      if (insErr) { alert("Errore creazione appuntamento: " + insErr.message); return; }

      await loadBookingRequests();
      // Ricarica il calendario sulla settimana corrente
      const startOfWeek = new Date(currentDate);
      startOfWeek.setDate(currentDate.getDate() - ((currentDate.getDay() + 6) % 7));
      startOfWeek.setHours(0,0,0,0);
      const endOfWeek = addDays(startOfWeek, 6);
      endOfWeek.setHours(23,59,59,999);
      await loadAppointments(startOfWeek, endOfWeek);
    } finally {
      setBookingActionId(null);
    }
  }

  async function rejectBooking(id: string) {
    setBookingActionId(id);
    await supabase.from("booking_requests").update({ status: "cancelled" }).eq("id", id);
    await loadBookingRequests();
    setBookingActionId(null);
  }

  const exportToGoogleCalendar = useCallback(async () => {
    const eventsToExport = events.filter(e => e.status !== "cancelled").map(event => ({
      summary: `${event.location === "domicile" ? `🏠 ${event.patient_name}` : event.patient_name} - ${statusLabel(event.status)}`,
      location: event.location === "studio" ? event.clinic_site : event.domicile_address,
      description: `Trattamento: ${getTreatmentLabel(event.treatment_type)}\nPrezzo: €${event.amount ?? ""}\nNote: ${event.calendar_note || "Nessuna nota"}`,
      start: { dateTime: event.start.toISOString(), timeZone: "Europe/Rome" },
      end:   { dateTime: event.end.toISOString(),   timeZone: "Europe/Rome" },
    }));
    const calendarUrl = "https://calendar.google.com/calendar/render?action=TEMPLATE";
    const firstEvent = eventsToExport[0];
    if (firstEvent) {
      const params = new URLSearchParams({
        text: firstEvent.summary,
        details: firstEvent.description,
        location: firstEvent.location || "",
        dates: `${firstEvent.start.dateTime.replace(/[-:]/g, "").split(".")[0]}Z/${firstEvent.end.dateTime.replace(/[-:]/g, "").split(".")[0]}Z`,
      });
      window.open(`${calendarUrl}&${params.toString()}`, "_blank");
    }
  }, [events]);

// ── Utility WhatsApp — unica funzione usata ovunque ──────────────────────────
// Restituisce SOLO cifre senza + (es. "393331234567")
// api.whatsapp.com/send?phone= vuole il numero senza + né spazi
function cleanPhoneForWA(phone: string): string {
  if (!phone) return "";
  // 1. Rimuovi tutto tranne cifre e +
  let c = phone.trim().replace(/[\s\(\)\-\.\/]/g, "");
  // 2. 00xx → +xx
  if (c.startsWith("00")) c = "+" + c.slice(2);
  // 3. Rimuovi il + per lavorare solo con cifre
  if (c.startsWith("+")) c = c.slice(1);
  // 4. Rimuovi qualsiasi residuo non numerico
  c = c.replace(/\D/g, "");
  if (!c) return "";
  // 5. Doppio prefisso 39 (es. 003939xxx) → togli il primo
  if (c.startsWith("3939") && c.length > 13) c = c.slice(2);
  // 6. Già con prefisso 39 e lunghezza corretta (11 fisso, 12 mobile)
  if (c.startsWith("39") && (c.length === 11 || c.length === 12)) return c;
  // 7. Mobile italiano 3xx (10 cifre) → aggiungi 39
  if (c.startsWith("3") && c.length === 10) return "39" + c;
  // 8. Fisso italiano 0xx (9-11 cifre) → sostituisci 0 iniziale con 39
  if (c.startsWith("0") && c.length >= 9 && c.length <= 11) return "39" + c.slice(1);
  // 9. Numero corto/incompleto → aggiungi 39
  if (c.length <= 10) return "39" + c;
  return c;
}

// Apre WhatsApp Web su desktop senza dipendere da window.open (bloccato dai browser)
// Usa api.whatsapp.com che funziona sia su desktop che mobile
function openWhatsApp(phone: string, message: string): boolean {
  const clean = cleanPhoneForWA(phone);
  if (!clean) return false;
  const url = `https://api.whatsapp.com/send?phone=${clean}&text=${encodeURIComponent(message)}`;
  const a = document.createElement("a");
  a.href = url;
  a.target = "_blank";
  a.rel = "noopener noreferrer";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  return true;
}
// ─────────────────────────────────────────────────────────────────────────────

  const sendReminder = useCallback(async (appointmentId: string, patientPhone?: string, patientFirstName?: string, isConfirmation?: boolean) => {
    if (!patientPhone) { alert("Nessun telefono registrato per questo paziente"); return; }
    const appointment = events.find(e => e.id === appointmentId);
    if (!appointment) return;

    const templateName = isConfirmation ? "Appuntamento" : "Promemoria";
    const { data: templateData } = await supabase.from("message_templates").select("template").eq("name", templateName).maybeSingle();

    let templateText = isConfirmation
      ? "Grazie per averci scelto.\nRicordiamo il prossimo appuntamento fissato per {data_relativa} alle {ora}.\n\nA presto,\nDr. Marco Turchetta\nFisioterapia e Osteopatia"
      : "Buongiorno {nome},\n\nLe ricordiamo il suo appuntamento di {data_relativa} alle ore {ora}.\n\n📍 {luogo}\n\nCordiali saluti,\nDr. Marco Turchetta\nFisioterapia e Osteopatia";

    if (templateData?.template) templateText = templateData.template;

    const dataRelativa = formatDateRelative(appointment.start);
    const ora = fmtTime(appointment.start.toISOString());
    const nomePaziente = (patientFirstName?.trim()) || "Cliente";
    let luogo = "";
    if (appointment.location === "studio") {
      luogo = CLINIC_ADDRESSES[appointment.clinic_site || ""] || appointment.clinic_site || "Pontecorvo, Via Galileo Galilei 5";
    } else {
      luogo = `Presso il suo domicilio (${appointment.domicile_address})`;
    }

    // Genera link di conferma
    const originBase = typeof window !== "undefined" ? window.location.origin : "";
    const confirmToken = typeof window !== "undefined" ? btoa(appointmentId).replace(/\+/g,"-").replace(/\//g,"_").replace(/=/g,"") : "";
    const linkConferma = `${originBase}/conferma/${confirmToken}`;

    let message = templateText
      .replace(/{nome}/g, nomePaziente)
      .replace(/{data_relativa}/g, dataRelativa)
      .replace(/{data}/g, dataRelativa)
      .replace(/{ora}/g, ora)
      .replace(/{luogo}/g, luogo)
      .replace(/{link_conferma}/g, linkConferma)
      .replace(/{link}/g, linkConferma);

    // Se il template non contiene già il link, aggiungilo alla fine per i promemoria
    if (!isConfirmation && !message.includes(linkConferma)) {
      message += `\n\n👉 Conferma o annulla con un click:\n${linkConferma}`;
    }

    const opened = openWhatsApp(patientPhone, message);
    if (!opened) { alert("Numero di telefono non valido."); return; }

    const nowIso = new Date().toISOString();
    await supabase.from("appointments").update({ whatsapp_sent_at: nowIso, whatsapp_sent: true }).eq("id", appointmentId);
    setEvents(prev => prev.map(ev => ev.id === appointmentId ? { ...ev, whatsapp_sent_at: new Date(nowIso), whatsapp_sent: true } : ev));
  }, [events]);

  // ── Chiedi Recensione Google via WhatsApp ──────────────────────────
  const sendGoogleReview = useCallback(async (patientPhone?: string, patientFirstName?: string) => {
    if (!patientPhone) { alert("Nessun telefono registrato per questo paziente"); return; }
    const nomePaziente = (patientFirstName?.trim()) || "Cliente";
    const googleLink = practiceSettings?.google_review_link || GOOGLE_REVIEW_LINK_FALLBACK;
    const message = `Buongiorno ${nomePaziente},

Grazie per aver scelto il nostro studio! 🙏

Se è rimasto/a soddisfatto/a del trattamento, le saremmo molto grati se potesse lasciarci una breve recensione su Google:

${googleLink}

La sua opinione ci aiuta a migliorare e a farci conoscere.

Grazie di cuore,
Dr. Marco Turchetta
Fisioterapia e Osteopatia`;
    
    openWhatsApp(patientPhone, message);
  }, [practiceSettings]);
  const toggleBulkSelect = useCallback((id: string) => {
    setBulkSelected(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const bulkMarkPaid = useCallback(async () => {
    if (bulkSelected.size === 0) return;
    setError("");
    const ids = Array.from(bulkSelected);
    
    for (const id of ids) {
      const { error } = await supabase.from("appointments").update({ is_paid: true }).eq("id", id);
      if (error) {
        setError(`Errore aggiornamento: ${error.message}`);
        return;
      }
    }

    setBulkSelected(new Set());
    setBulkMode(false);
    const startOfWeek = startOfISOWeekMonday(currentDate);
    const endOfWeek = addDays(startOfWeek, 7);
    await loadAppointments(startOfWeek, endOfWeek);
  }, [bulkSelected, currentDate, loadAppointments]);

  const updateDuplicateDateTime = useCallback((newDate: string, newTime: string) => {
    if (!newDate || !newTime) return;
    
    const date = parseDateInput(newDate);
    const [hours, minutes] = newTime.split(':').map(Number);
    date.setHours(hours, minutes, 0, 0);
    
    const durationHours = parseFloat(selectedDuration);
    const endDate = new Date(date.getTime() + durationHours * 60 * 60000);
    
    setCreateStartISO(date.toISOString());
    setCreateEndISO(endDate.toISOString());
  }, [selectedDuration]);

  const handleSlotClick = useCallback((date: Date, hour: number, minute: number = 0) => {
    openCreateModal(date, hour, minute);
  }, [openCreateModal]);

  const loadPatientFromEvent = useCallback(async (patientId: string) => {
    const { data, error } = await supabase
      .from("patients")
      .select("id, first_name, last_name, phone, treatment, diagnosis")
      .eq("id", patientId)
      .single();
      
    if (data && !error) {
      setSelectedPatient(data as PatientLite);
      setPatientResults(prev => {
        if (!prev.some(p => p.id === data.id)) {
          return [data as PatientLite, ...prev];
        }
        return prev;
      });
    }
  }, []);

  // Feature: Copia ultimo setting del paziente
  const loadLastPatientSettings = useCallback(async (patientId: string) => {
    const { data } = await supabase
      .from("appointments")
      .select("treatment_type, price_type, location, clinic_site, domicile_address, amount")
      .eq("patient_id", patientId)
      .order("start_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (data) {
      if (data.treatment_type) setTreatmentType(data.treatment_type as "seduta" | "macchinario");
      if (data.price_type) setPriceType(data.price_type as "invoiced" | "cash");
      if (data.location) setCreateLocation(data.location as LocationType);
      if (data.clinic_site) setCreateClinicSite(data.clinic_site);
      if (data.domicile_address) setCreateDomicileAddress(data.domicile_address);
      if (data.amount !== null && data.amount !== undefined) {
        setCustomAmount(data.amount.toString());
        setUseCustomPrice(true);
      }
    }
  }, []);

  // Feature: Avviso sovrapposizione orari
  const checkOverlap = useCallback((startISO: string, endISO: string, excludeId?: string): string | null => {
    const newStart = new Date(startISO);
    const newEnd = new Date(endISO);

    const overlapping = events.filter(e => {
      if (excludeId && e.id === excludeId) return false;
      if (e.status === "cancelled") return false;
      return (newStart < e.end && newEnd > e.start);
    });

    if (overlapping.length > 0) {
      const names = overlapping.map(e => `${e.patient_name} (${fmtTime(e.start.toISOString())}-${fmtTime(e.end.toISOString())})`).join(", ");
      return `⚠️ Sovrapposizione con: ${names}`;
    }
    return null;
  }, [events]);

  // Check overlap when create times change
  useEffect(() => {
    if (!createOpen || !createStartISO || !createEndISO) {
      setOverlapWarning(null);
      return;
    }
    setOverlapWarning(checkOverlap(createStartISO, createEndISO));
  }, [createStartISO, createEndISO, createOpen, checkOverlap]);

  // Feature: Month view helpers
  const monthDays = useMemo(() => {
    if (viewType !== "month") return [];
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    
    // Start from Monday before or on the 1st
    const startOffset = (firstDay.getDay() === 0 ? 6 : firstDay.getDay() - 1);
    const calStart = addDays(firstDay, -startOffset);
    
    const days: Date[] = [];
    for (let i = 0; i < 42; i++) {
      days.push(addDays(calStart, i));
    }
    return days;
  }, [viewType, currentDate]);

  const monthEvents = useMemo(() => {
    if (viewType !== "month" || monthDays.length === 0) return new Map<string, CalendarEvent[]>();
    const map = new Map<string, CalendarEvent[]>();
    filteredEvents.forEach(e => {
      const key = `${e.start.getFullYear()}-${e.start.getMonth()}-${e.start.getDate()}`;
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(e);
    });
    return map;
  }, [viewType, filteredEvents, monthDays]);

  const goToPreviousMonth = useCallback(() => {
    setCurrentDate(prev => {
      const d = new Date(prev);
      d.setMonth(d.getMonth() - 1);
      return d;
    });
  }, []);

  const goToNextMonth = useCallback(() => {
    setCurrentDate(prev => {
      const d = new Date(prev);
      d.setMonth(d.getMonth() + 1);
      return d;
    });
  }, []);

  const searchPatients = useCallback(async (query: string) => {
    const cleaned = query.trim();
    if (cleaned.length < 2) {
      setPatientResults([]);
      setSelectedPatient(null);
      return;
    }

    setSearching(true);

    const { data, error } = await supabase
      .from("patients")
      .select("id, first_name, last_name, phone, treatment, diagnosis")
      .or(`first_name.ilike.%${cleaned}%,last_name.ilike.%${cleaned}%`)
      .order("last_name", { ascending: true })
      .limit(12);

    setSearching(false);

    if (error) {
      setError(`Errore ricerca paziente: ${error.message}`);
      setPatientResults([]);
      return;
    }

    setPatientResults((data ?? []) as PatientLite[]);
  }, []);

  useEffect(() => {
    if (!createOpen) return;

    if (searchTimer.current) clearTimeout(searchTimer.current);
    searchTimer.current = setTimeout(() => {
      searchPatients(q);
    }, 250);

    return () => {
      if (searchTimer.current) clearTimeout(searchTimer.current);
    };
  }, [q, createOpen, searchPatients]);

  useEffect(() => {
    if (!createStartISO || !selectedStartTime || !selectedDuration) return;
    
    if (duplicateMode && duplicateDate && duplicateTime) {
      updateDuplicateDateTime(duplicateDate, duplicateTime);
    } else {
      const baseDate = new Date(createStartISO);
      const [hours, minutes] = selectedStartTime.split(':').map(Number);
      const dateOnly = new Date(baseDate);
      dateOnly.setHours(hours, minutes, 0, 0);
      
      const durationHours = parseFloat(selectedDuration);
      const endDate = new Date(dateOnly.getTime() + durationHours * 60 * 60000);
      
      setCreateStartISO(dateOnly.toISOString());
      setCreateEndISO(endDate.toISOString());
    }
  }, [selectedStartTime, selectedDuration, createStartISO, duplicateMode, duplicateDate, duplicateTime, updateDuplicateDateTime]);

  useEffect(() => {
    if (createOpen && duplicateMode && eventToDuplicate) {
      const date = eventToDuplicate.start;
      setDuplicateDate(toDateInputValue(date));
      setDuplicateTime(`${pad2(date.getHours())}:${pad2(date.getMinutes())}`);
    }
  }, [createOpen, duplicateMode, eventToDuplicate]);

  const toggleDoneQuick = useCallback(async (apptId: string, current: Status) => {
    setError("");
    const next: Status = current === "done" ? "confirmed" : "done";

    const { error } = await supabase.from("appointments").update({ status: next, is_paid: next === "done" }).eq("id", apptId);

    if (error) {
      setError(`Errore aggiornamento stato: ${error.message}`);
      return;
    }

    const startOfWeek = startOfISOWeekMonday(currentDate);
    const endOfWeek = addDays(startOfWeek, 7);
    await loadAppointments(startOfWeek, endOfWeek);
  }, [currentDate, loadAppointments]);

  const togglePaidQuick = useCallback(async (apptId: string, currentlyPaid: boolean) => {
    setError("");
    const { error } = await supabase.from("appointments").update({ is_paid: !currentlyPaid }).eq("id", apptId);
    if (error) {
      setError(`Errore aggiornamento pagamento: ${error.message}`);
      return;
    }
    const startOfWeek = startOfISOWeekMonday(currentDate);
    const endOfWeek = addDays(startOfWeek, 7);
    await loadAppointments(startOfWeek, endOfWeek);
  }, [currentDate, loadAppointments]);

  const createQuickPatient = useCallback(async () => {
    if (!quickPatientFirstName.trim() || !quickPatientLastName.trim()) {
      setError("Inserisci nome e cognome per il nuovo paziente.");
      return;
    }

    setCreatingQuickPatient(true);
    setError("");

    try {
      const { data, error } = await supabase
        .from("patients")
        .insert({
          first_name: quickPatientFirstName.trim(),
          last_name: quickPatientLastName.trim(),
          phone: quickPatientPhone.trim() || null,
          status: "da_completare",
          created_at: new Date().toISOString(),
        })
        .select("id, first_name, last_name, phone")
        .single();

      if (error) throw error;

      if (data) {
        const newPatient: PatientLite = {
          id: data.id,
          first_name: data.first_name,
          last_name: data.last_name,
          phone: data.phone,
        };

        setSelectedPatient(newPatient);
        setPatientResults(prev => [newPatient, ...prev]);
        setQuickPatientOpen(false);
        setQuickPatientFirstName("");
        setQuickPatientLastName("");
        setQuickPatientPhone("");
        
        setError("Paziente creato con successo! Ora puoi creare l'appuntamento.");
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setError(`Errore creazione paziente: ${msg}`);
    } finally {
      setCreatingQuickPatient(false);
    }
  }, [quickPatientFirstName, quickPatientLastName, quickPatientPhone]);

  const createAppointment = useCallback(async (sendWhatsApp: boolean = false) => {
  setError("");

  if (!selectedPatient) {
    setError("Seleziona un paziente prima di creare l'appuntamento.");
    return;
  }
  if (!createStartISO || !createEndISO) {
    setError("Orari appuntamento non validi.");
    return;
  }

  if (createLocation === "studio") {
    if (!createClinicSite.trim()) {
      setError("Inserisci il nome della sede (clinic_site).");
      return;
    }
  } else {
    if (createDomicileAddress.trim().length < 5) {
      setError("Inserisci un indirizzo domicilio valido (min 5 caratteri).");
      return;
    }
  }

  const firstStart = new Date(createStartISO);
  const firstEnd = new Date(createEndISO);
  const durationMs = firstEnd.getTime() - firstStart.getTime();
  if (durationMs <= 0) {
    setError("Durata appuntamento non valida.");
    return;
  }

  // Feature: Check overlap before creating
  if (!isRecurring) {
    const overlap = checkOverlap(createStartISO, createEndISO);
    if (overlap) {
      const proceed = window.confirm(`${overlap}\n\nVuoi procedere comunque?`);
      if (!proceed) return;
    }
  }

  if (isRecurring) {
    if (recurringDays.length === 0) {
      setError("Seleziona almeno un giorno per la ricorrenza.");
      return;
    }
    const until = parseDateInput(recurringUntil);
    if (until < firstStart) {
      setError("La data 'Ripeti fino a' non può essere precedente alla prima data.");
      return;
    }
  }

  let amount: number | null = null;
  if (useCustomPrice && customAmount !== "") {
    const parsed = parseFloat(customAmount.replace(',', '.'));
    if (!isNaN(parsed) && parsed >= 0) {
      amount = parsed;
    }
  } else {
    // Se nei Settings hai disattivato "applica automaticamente", lasciamo vuoto a meno che non sia custom
    const autoApply = practiceSettings?.auto_apply_prices ?? true;
    if (autoApply) {
      amount = getDefaultAmount(treatmentType, priceType);
    } else {
      amount = null;
    }
  }

  setCreating(true);

  const basePayload = {
    patient_id: selectedPatient.id,
    status: (practiceSettings?.default_appointment_status ?? "confirmed") as Status,
    calendar_note: null as string | null,
    location: createLocation,
    clinic_site: createLocation === "studio" ? createClinicSite.trim() : null,
    domicile_address: createLocation === "domicile" ? createDomicileAddress.trim() : null,
    treatment_type: treatmentType,
    price_type: priceType,
    amount: amount,
  };

  try {
    let createdAppointmentId: string | null = null;

    if (!isRecurring) {
      const payload = {
        ...basePayload,
        start_at: firstStart.toISOString(),
        end_at: firstEnd.toISOString(),
      };

      const { data, error: insErr } = await supabase.from("appointments").insert(payload).select().single();
      if (insErr) throw new Error(insErr.message);

      if (data) {
        createdAppointmentId = data.id;
        
        if (sendWhatsApp) {
          if (!(selectedPatient.phone || "").trim()) {
            alert("Nessun telefono registrato per questo paziente");
          } else {
            const dataRelativa = formatDateRelative(firstStart);
            const ora = fmtTime(firstStart.toISOString());
            
            let luogo = "";
            if (createLocation === 'studio') {
              luogo = CLINIC_ADDRESSES[createClinicSite] || 
                      createClinicSite || 
                      "Pontecorvo, Via Galileo Galilei 5, dietro il Bar Principe";
            } else {
              luogo = `Presso il suo domicilio (${createDomicileAddress})`;
            }
            
            const nomePaziente = selectedPatient.first_name || "Cliente";
            
            const message = `Grazie per averci scelto.
Ricordiamo il prossimo appuntamento fissato per ${dataRelativa} alle ${ora}.

📍 ${luogo}

A presto,
Dr. Marco Turchetta
Fisioterapia e Osteopatia`;
            
            openWhatsApp(selectedPatient.phone || "", message);

            // Segna WhatsApp inviato per questo appuntamento (timestamp = verità)
            if (createdAppointmentId) {
              const nowIso = new Date().toISOString();
              await supabase.from("appointments").update({ whatsapp_sent_at: nowIso, whatsapp_sent: true }).eq("id", createdAppointmentId);
            }
          }
        }
      }

    } else {
      const until = parseDateInput(recurringUntil);

      const starts = generateRecurringStarts({
        firstStart,
        untilDate: until,
        weekDays: recurringDays,
        frequency: recurringFrequency,
      });

      if (starts.length > 200) {
        throw new Error(
          `Ricorrenza troppo ampia: ${starts.length} appuntamenti. Riduci l'intervallo o i giorni selezionati.`
        );
      }

      const rows = starts.map((s) => ({
        ...basePayload,
        start_at: s.toISOString(),
        end_at: new Date(s.getTime() + durationMs).toISOString(),
      }));

      const { error: insErr } = await supabase.from("appointments").insert(rows);
      if (insErr) throw new Error(insErr.message);
      
      if (sendWhatsApp) {
        alert("Per appuntamenti ricorrenti, WhatsApp non viene inviato automaticamente per evitare troppi messaggi.");
      }
    }

    setCreateOpen(false);
    const startOfWeek = startOfISOWeekMonday(currentDate);
    const endOfWeek = addDays(startOfWeek, 7);
    await loadAppointments(startOfWeek, endOfWeek);
    
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : "Errore sconosciuto";
    setError(`Errore creazione appuntamento: ${msg}`);
  } finally {
    setCreating(false);
  }
}, [
  selectedPatient,
  createStartISO,
  createEndISO,
  createLocation,
  createClinicSite,
  createDomicileAddress,
  isRecurring,
  recurringDays,
  recurringUntil,
  recurringFrequency,
  treatmentType,
  priceType,
  useCustomPrice,
  customAmount,
  practiceSettings,
  getDefaultAmount,
  currentDate,
  loadAppointments,
  checkOverlap,
]);

  const saveAppointment = useCallback(async () => {
  if (!selectedEvent) return;

  setError("");

  let amount: number | null = null;
  if (editAmount !== "" && editAmount !== null && editAmount !== undefined) {
    const parsed = parseFloat(editAmount.replace(',', '.'));
    if (!isNaN(parsed) && parsed >= 0) {
      amount = parsed;
    }
  }

  // Calcola nuove date e orari se modificati
  let newStartDate = selectedEvent.start;
  let newEndDate = selectedEvent.end;
  
  if (editDate && editStartTime) {
    const [hours, minutes] = editStartTime.split(':').map(Number);
    newStartDate = parseDateInput(editDate);
    newStartDate.setHours(hours, minutes, 0, 0);
    
    const durationHours = parseFloat(editDuration);
    newEndDate = new Date(newStartDate.getTime() + durationHours * 60 * 60000);
  }

  if (!newStartDate || !newEndDate) {
    alert("Errore: data o ora non valida");
    return;
  }

  const ALLOWED = new Set(["booked","confirmed","done","cancelled","not_paid"]);

  const normalizedStatus =
    (editStatus as string) === "no_show" ? "not_paid" as Status : editStatus;

  if (!ALLOWED.has(normalizedStatus)) {
    setError(`STATUS ILLEGALE: ${String(normalizedStatus)}`);
    return;
  }

  // Creiamo l'oggetto di aggiornamento
  const updateData = {
    status: normalizedStatus,
    // is_paid segue lo stato: done => pagato, altrimenti non pagato
    is_paid: normalizedStatus === "done",
    calendar_note: editNote,
    amount: amount,
    treatment_type: editTreatmentType,
    price_type: editPriceType,
    start_at: newStartDate.toISOString(),
    end_at: newEndDate.toISOString(),
  };

  // Rimuoviamo le proprietà undefined/null
  const cleanedData = Object.fromEntries(
    Object.entries(updateData).filter(([_, v]) => v !== null && v !== undefined)
  );

  try {
    const { error } = await supabase
      .from("appointments")
      .update(cleanedData)
      .eq("id", selectedEvent.id);

    if (error) {
      setError(`Errore salvataggio: ${error.message}`);
      return;
    }

    setSelectedEvent(null);
    const startOfWeek = startOfISOWeekMonday(currentDate);
    const endOfWeek = addDays(startOfWeek, 7);
    await loadAppointments(startOfWeek, endOfWeek);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    setError(`Errore salvataggio: ${msg}`);
  }
}, [selectedEvent, editStatus, editNote, editAmount, editTreatmentType, editPriceType, editDate, editStartTime, editDuration, currentDate, loadAppointments]);

  const deleteAppointment = useCallback(async () => {
    if (!selectedEvent) return;

    const ok = window.confirm("Vuoi eliminare definitivamente questo appuntamento?");
    if (!ok) return;

    setError("");

    const { error } = await supabase.from("appointments").delete().eq("id", selectedEvent.id);

    if (error) {
      setError(`Errore eliminazione: ${error.message}`);
      return;
    }

    setSelectedEvent(null);
    const startOfWeek = startOfISOWeekMonday(currentDate);
    const endOfWeek = addDays(startOfWeek, 7);
    await loadAppointments(startOfWeek, endOfWeek);
  }, [selectedEvent, currentDate, loadAppointments]);

  const printCalendar = useCallback(() => {
    exportToPDF();
    setPrintMenuOpen(false);
  }, [exportToPDF]);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (printMenuRef.current && !printMenuRef.current.contains(event.target as Node)) {
        setPrintMenuOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const dayLabels = useMemo(
    () => [
      { dow: 1, label: "LUN" },
      { dow: 2, label: "MAR" },
      { dow: 3, label: "MER" },
      { dow: 4, label: "GIO" },
      { dow: 5, label: "VEN" },
      { dow: 6, label: "SAB" },
    ],
    []
  );

  const toggleRecurringDay = useCallback((dow: number) => {
    setRecurringDays((prev) => {
      if (prev.includes(dow)) return prev.filter((x) => x !== dow);
      return [...prev, dow].sort((a, b) => a - b);
    });
  }, []);

  const handleDragStart = useCallback((event: React.DragEvent, apptId: string, originalStart: Date, originalEnd: Date) => {
    setDraggingEvent({ id: apptId, originalStart, originalEnd });
    event.dataTransfer.setData("text/plain", apptId);
    event.dataTransfer.effectAllowed = "move";
    
    if (event.currentTarget instanceof HTMLElement) {
      event.currentTarget.style.opacity = "0.35";
      event.currentTarget.style.transform = "scale(0.96)";
    }
  }, []);

  const handleDragOver = useCallback((event: React.DragEvent, dayIndex?: number, hour?: number, minute: number = 0) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = "move";
    
    if (dayIndex !== undefined && hour !== undefined) {
      setDraggingOver({ dayIndex, hour, minute });
    }
    
    // Track ghost position for visual feedback
    setDragGhostPos({ x: event.clientX, y: event.clientY });
    
    if (event.currentTarget instanceof HTMLElement) {
      event.currentTarget.style.backgroundColor = "rgba(37,99,235,0.08)";
      event.currentTarget.style.transition = "background-color 0.15s ease";
    }
  }, []);

  const handleDragLeave = useCallback((event: React.DragEvent) => {
    setDraggingOver(null);
    if (event.currentTarget instanceof HTMLElement) {
      event.currentTarget.style.backgroundColor = "transparent";
    }
  }, []);

  const handleDrop = useCallback(async (event: React.DragEvent, targetDate: Date, targetHour: number, targetMinute: number = 0) => {
    event.preventDefault();
    setDraggingOver(null);
    
    if (event.currentTarget instanceof HTMLElement) {
      event.currentTarget.style.backgroundColor = "transparent";
    }
    
    if (!draggingEvent) return;

    const apptId = event.dataTransfer.getData("text/plain");
    if (apptId !== draggingEvent.id) return;

    const newStart = new Date(targetDate);
    newStart.setHours(targetHour, targetMinute, 0, 0);
    
    const duration = draggingEvent.originalEnd.getTime() - draggingEvent.originalStart.getTime();
    const newEnd = new Date(newStart.getTime() + duration);

    setError("");

    const { error } = await supabase
      .from("appointments")
      .update({
        start_at: newStart.toISOString(),
        end_at: newEnd.toISOString(),
      })
      .eq("id", apptId);

    if (error) {
      setError(`Errore spostamento: ${error.message}`);
    } else {
      const startOfWeek = startOfISOWeekMonday(currentDate);
      const endOfWeek = addDays(startOfWeek, 7);
      await loadAppointments(startOfWeek, endOfWeek);
    }

    setDraggingEvent(null);
  }, [draggingEvent, currentDate, loadAppointments]);

  const handleDragEnd = useCallback((event: React.DragEvent) => {
    if (event.currentTarget instanceof HTMLElement) {
      event.currentTarget.style.opacity = "1";
      event.currentTarget.style.transform = "scale(1)";
    }
    setDraggingEvent(null);
    setDragGhostPos(null);
    setDraggingOver(null);
  }, []);

  const handleContextMenu = useCallback((e: React.MouseEvent, event?: CalendarEvent) => {
    e.preventDefault();
    setQuickActionsMenu({
      x: e.clientX,
      y: e.clientY,
      eventId: event?.id,
    });
  }, []);

  useEffect(() => {
    if (selectedEvent) {
      const event = events.find(e => e.id === selectedEvent.id);
      if (event) {
        setEditAmount(event.amount !== undefined && event.amount !== null ? event.amount.toString() : "");
        setEditTreatmentType((event.treatment_type as "seduta" | "macchinario") || "seduta");
        setEditPriceType((event.price_type as "invoiced" | "cash") || "invoiced");
        
        // Imposta i valori per la modifica di orario e giorno
        setEditDate(toDateInputValue(event.start));
        setEditStartTime(`${pad2(event.start.getHours())}:${pad2(event.start.getMinutes())}`);
        
        const durationHours = (event.end.getTime() - event.start.getTime()) / (60 * 60000);
        if (durationHours === 1) setEditDuration("1");
        else if (durationHours === 1.5) setEditDuration("1.5");
        else if (durationHours === 2) setEditDuration("2");
      }
    }
  }, [selectedEvent, events]);

  // Nuova funzione per il drag and drop su slot di 30 minuti
useEffect(() => {
  if (typeof window === "undefined") return;

  const isNew = params.get("new");
  if (isNew !== "1") return;

  // evita doppia apertura
  if (createOpen) return;

  const dateStr = params.get("date");
  const view = params.get("view");

  // forza vista giorno
  setViewType(view === "week" ? "week" : view === "month" ? "month" : "day");

  // imposta data
  let d = new Date();
  if (dateStr && /^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
    const [y, m, day] = dateStr.split("-").map(Number);
    d = new Date(y, m - 1, day);
  }
  // scegli uno slot libero “furbo”
const slots = getAvailableSlots(d);
const now = new Date();
const isToday =
  d.getFullYear() === now.getFullYear() &&
  d.getMonth() === now.getMonth() &&
  d.getDate() === now.getDate();

let chosen = slots[0]?.start ?? new Date(d);
if (isToday) {
  const candidate = slots.find(s => s.start.getTime() >= now.getTime() + 10 * 60 * 1000);
  if (candidate) chosen = candidate.start;
}

setCurrentDate(chosen);

// apre modale creazione
openCreateModal(chosen, chosen.getHours(), chosen.getMinutes());


  // pulizia URL
  const url = new URL(window.location.href);
  url.searchParams.delete("new");
  window.history.replaceState({}, "", url.toString());
}, []);
return (
    <div style={{ minHeight: "100vh", background: THEME.appBg, fontFamily: "'Outfit', 'Segoe UI', system-ui, sans-serif" }}>
      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap');
        * { -webkit-font-smoothing: antialiased; box-sizing: border-box; }
        html { overflow-x: hidden; }
        body { font-family: 'Outfit', 'Segoe UI', system-ui, sans-serif; margin: 0; background: ${THEME.appBg}; overflow-x: hidden; }
        select, input, textarea, button { font-family: inherit; }
        input:focus, select:focus, textarea:focus {
          border-color: ${THEME.blue} !important;
          box-shadow: 0 0 0 3px rgba(37,99,235,0.12) !important;
          outline: none !important;
        }
        @keyframes searchPulse {
          0%, 100% { box-shadow: 0 0 8px rgba(245,158,11,0.5); }
          50% { box-shadow: 0 0 20px rgba(245,158,11,0.8), 0 0 40px rgba(245,158,11,0.3); }
        }
        .search-highlight { animation: searchPulse 1.5s ease-in-out infinite; }
        .search-dimmed { opacity: 0.25 !important; filter: grayscale(0.6); transition: opacity 0.3s, filter 0.3s; }
        .sidebar-scroll { overflow-y: auto; scrollbar-width: thin; scrollbar-color: rgba(37,99,235,0.12) transparent; }
        .sidebar-scroll::-webkit-scrollbar { width: 5px; }
        .sidebar-scroll::-webkit-scrollbar-thumb { background: rgba(37,99,235,0.12); border-radius: 99px; }
        .sidebar-scroll.show-scrollbar::-webkit-scrollbar { width: 6px; }
        .sidebar-scroll.show-scrollbar::-webkit-scrollbar-thumb { background: rgba(91,130,168,0.18); border-radius: 99px; }
        @media (max-width: 768px) { .mob-hide { display: none !important; } .mob-col { flex-direction: column !important; } }
        @media (min-width: 768px) and (max-width: 1199px) {
          .tab-compact { font-size: 11px !important; padding: 3px 6px !important; }
          .tab-hide { display: none !important; }
          .cal-period-btns { flex-wrap: wrap !important; gap: 3px !important; }
          .cal-period-btns button { font-size: 10px !important; padding: 5px 8px !important; min-height: 36px !important; }
          .cal-sidebar { width: 280px !important; min-width: 280px !important; }
        }
        @media print { .no-print { display: none !important; } .print-wrap { margin: 0 !important; padding: 4px !important; } }
      `}</style>

      {/* ━━━ TOP NAVIGATION BAR ━━━ */}
      <header className="no-print" style={{
        position: "sticky", top: 0, zIndex: 30,
        background: "linear-gradient(135deg, #0d9488, #2563eb)", borderBottom: "none",
        padding: "0 20px", height: 58,
        display: "flex", alignItems: "center", justifyContent: "space-between",
        boxShadow: "0 2px 12px rgba(13,148,136,0.18)",
        gap: 8,
      }}>
        {/* Left: Logo + Nav */}
        <div style={{ display: "flex", alignItems: "center", gap: 20, flexShrink: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div style={{
              width: 30, height: 30, borderRadius: 8,
              background: "rgba(255,255,255,0.2)",
              display: "flex", alignItems: "center", justifyContent: "center",
              color: "#fff", fontWeight: 800, fontSize: 14, letterSpacing: -0.5,
              border: "1.5px solid rgba(255,255,255,0.3)",
            }}>F</div>
            <span className="mob-hide" style={{ fontWeight: 700, fontSize: 15, color: "#fff", letterSpacing: 0.5, textTransform: "uppercase" }}>Fisio<span style={{ color: "#fff", fontWeight: 800 }}>Hub</span></span>
          </div>
          <nav className="mob-hide" style={{ display: "flex", gap: 2 }}>
            {([{href:"/",label:"Home"},{href:"/calendar",label:"Calendario",active:true},{href:"/reports",label:"Report"},{href:"/noleggio",label:"Noleggio"},{href:"/patients",label:"Pazienti"}] as const).map(item=>(
              <Link key={item.href} href={item.href} style={{ padding:"6px 12px", borderRadius:8, fontSize:12, fontWeight:700, textDecoration:"none", background:(item as any).active?"rgba(255,255,255,0.2)":"transparent", color:(item as any).active?"#fff":"rgba(255,255,255,0.8)", letterSpacing:0.3 }}>{item.label}</Link>
            ))}
          </nav>
        </div>

        {/* Center: Nav frecce + Titolo data + Selettore vista + Stampa */}
        <div style={{ display: "flex", alignItems: "center", gap: 8, flex: 1, justifyContent: "center", minWidth: 0 }}>

          {/* Frecce navigazione */}
          <button onClick={() => { if(viewType==="week") goToPreviousWeek(); else if(viewType==="month") goToPreviousMonth(); else setCurrentDate(d => { const x=new Date(d); x.setDate(x.getDate()-1); return x; }); }}
            style={{ width:30, height:30, borderRadius:7, border:"1.5px solid rgba(255,255,255,0.35)", background:"rgba(255,255,255,0.15)", color:"#fff", cursor:"pointer", fontWeight:800, fontSize:14, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
            ‹
          </button>

          {/* Titolo + selettore settimana (solo in vista settimana) */}
          {viewType === "week" ? (
            <select value={startOfISOWeekMonday(currentDate).toISOString()} onChange={(e) => gotoWeekStart(e.target.value)}
              className="mob-hide"
              style={{ padding:"6px 28px 6px 10px", borderRadius:8, border:"1.5px solid rgba(255,255,255,0.35)", background:"rgba(255,255,255,0.18)", color:"#fff", fontWeight:700, outline:"none", fontSize:12, height:32, maxWidth:240, appearance:"none" as const, WebkitAppearance:"none" as const, backgroundImage:`url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 12 12'%3E%3Cpath d='M3 5l3 3 3-3' stroke='%23ffffff' stroke-width='1.5' fill='none'/%3E%3C/svg%3E")`, backgroundRepeat:"no-repeat", backgroundPosition:"right 8px center", cursor:"pointer", flexShrink:0 }}>
              {weekOptions.map((o) => (<option key={o.value} value={o.value} style={{ color:"#0f172a", background:"#fff" }}>{o.label}</option>))}
            </select>
          ) : (
            <div style={{ fontWeight:800, fontSize:15, color:"#fff", whiteSpace:"nowrap", flexShrink:0, textShadow:"0 1px 3px rgba(0,0,0,0.15)", minWidth:100, textAlign:"center" }}>
              {viewType === "month"
                ? (()=>{ const m=["Gen","Feb","Mar","Apr","Mag","Giu","Lug","Ago","Set","Ott","Nov","Dic"]; return `${m[currentDate.getMonth()]} ${currentDate.getFullYear()}`; })()
                : formatDMY(currentDate)}
            </div>
          )}

          {/* Freccia avanti */}
          <button onClick={() => { if(viewType==="week") goToNextWeek(); else if(viewType==="month") goToNextMonth(); else setCurrentDate(d => { const x=new Date(d); x.setDate(x.getDate()+1); return x; }); }}
            style={{ width:30, height:30, borderRadius:7, border:"1.5px solid rgba(255,255,255,0.35)", background:"rgba(255,255,255,0.15)", color:"#fff", cursor:"pointer", fontWeight:800, fontSize:14, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
            ›
          </button>

          {/* Oggi */}
          <button onClick={goToToday}
            style={{ padding:"5px 12px", borderRadius:7, border:"1.5px solid rgba(255,255,255,0.35)", background:"rgba(255,255,255,0.15)", color:"#fff", cursor:"pointer", fontWeight:700, fontSize:11, flexShrink:0, whiteSpace:"nowrap" }}>
            Oggi
          </button>

          {/* Selettore vista */}
          <div className="cal-period-btns" style={{ display:"flex", gap:2, background:"rgba(255,255,255,0.12)", borderRadius:8, padding:2, flexShrink:0 }}>
            {(["day","week","month"] as const).map(v => (
              <button key={v} onClick={() => setViewType(v)}
                style={{ padding:"4px 10px", borderRadius:6, border:"none", cursor:"pointer", fontSize:11, fontWeight:700, background:viewType===v?"rgba(255,255,255,0.9)":"transparent", color:viewType===v?"#1e40af":"rgba(255,255,255,0.85)", transition:"all 0.15s" }}>
                {v==="day"?"Giorno":v==="week"?"Settimana":"Mese"}
              </button>
            ))}
          </div>

          {/* Print button */}
          <div ref={printMenuRef} style={{ position: "relative", flexShrink: 0, zIndex: 40 }}>
            <button
              onClick={() => setPrintMenuOpen(!printMenuOpen)}
              style={{
                padding: "6px 14px",
                borderRadius: 8,
                border: "1.5px solid rgba(255,255,255,0.35)",
                background: "rgba(255,255,255,0.18)",
                color: "#fff",
                cursor: "pointer",
                fontWeight: 700,
                height: 34,
                display: "flex",
                alignItems: "center",
                gap: 6,
                fontSize: 12,
                whiteSpace: "nowrap",
              }}
            >
              🖨️ Stampa
              <span style={{ fontSize: 9 }}>▼</span>
            </button>

            {printMenuOpen && (
              <div
                style={{
                  position: "absolute",
                  top: "calc(100% + 6px)",
                  right: 0,
                  background: THEME.panelBg,
                  border: `2px solid ${THEME.border}`,
                  borderRadius: 12,
                  boxShadow: "0 12px 40px rgba(30,64,175,0.18)",
                  zIndex: 9999,
                  minWidth: 220,
                  overflow: "hidden",
                }}
              >
                <button
                  onClick={() => {
                    setViewType("day");
                    printCalendar();
                  }}
                  style={{
                    width: "100%",
                    padding: "13px 18px",
                    border: "none",
                    background: "transparent",
                    color: THEME.text,
                    cursor: "pointer",
                    fontWeight: 600,
                    textAlign: "left",
                    borderBottom: `1px solid ${THEME.borderSoft}`,
                    fontSize: 13,
                    letterSpacing: 0.2,
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = THEME.panelSoft)}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                >
                  ◈ Stampa giorno
                </button>
                <button
                  onClick={() => {
                    setViewType("week");
                    printCalendar();
                  }}
                  style={{
                    width: "100%",
                    padding: "13px 18px",
                    border: "none",
                    background: "transparent",
                    color: THEME.text,
                    cursor: "pointer",
                    fontWeight: 600,
                    textAlign: "left",
                    borderBottom: `1px solid ${THEME.borderSoft}`,
                    fontSize: 13,
                    letterSpacing: 0.2,
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = THEME.panelSoft)}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                >
                  ◫ Stampa settimana
                </button>
                <button
                  onClick={exportToPDF}
                  style={{
                    width: "100%",
                    padding: "13px 18px",
                    border: "none",
                    background: "transparent",
                    color: THEME.text,
                    cursor: "pointer",
                    fontWeight: 600,
                    textAlign: "left",
                    borderBottom: `1px solid ${THEME.borderSoft}`,
                    fontSize: 13,
                    letterSpacing: 0.2,
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = THEME.panelSoft)}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                >
                  ▤ Esporta PDF
                </button>
                <button
                  onClick={exportToGoogleCalendar}
                  style={{
                    width: "100%",
                    padding: "13px 18px",
                    border: "none",
                    background: "transparent",
                    color: THEME.text,
                    cursor: "pointer",
                    fontWeight: 600,
                    textAlign: "left",
                    fontSize: 13,
                    letterSpacing: 0.2,
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = THEME.panelSoft)}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                >
                  ▦ Esporta Google Calendar
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Right: Ricerca + Notifiche + User */}
        <div style={{ display: "flex", alignItems: "center", gap: 8, flexShrink: 0 }}>
          {/* Cmd+K */}
          <button
            onClick={() => { const event = new KeyboardEvent("keydown", { key: "k", metaKey: true, bubbles: true }); window.dispatchEvent(event); }}
            className="mob-hide" title="Ricerca globale"
            style={{ padding:"5px 10px", borderRadius:8, border:"1.5px solid rgba(255,255,255,0.25)", background:"rgba(255,255,255,0.1)", color:"rgba(255,255,255,0.75)", cursor:"pointer", fontSize:11, fontWeight:700, display:"flex", alignItems:"center", gap:5 }}>
            🔍 <kbd style={{ fontSize:10, background:"rgba(255,255,255,0.15)", border:"1px solid rgba(255,255,255,0.2)", borderRadius:4, padding:"0 4px" }}>⌘K</kbd>
          </button>
          {/* Notification bell — richieste dal sito */}
          <button onClick={() => setBookingPanel(v => !v)} style={{
            position: "relative", width: 32, height: 32, borderRadius: 8,
            border: "1.5px solid rgba(255,255,255,0.3)",
            background: bookingPanel ? "rgba(255,255,255,0.25)" : "rgba(255,255,255,0.12)",
            color: "#fff", cursor: "pointer", fontSize: 16,
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            🔔
            {bookingRequests.filter(r => r.status === "pending").length > 0 && (
              <span style={{
                position: "absolute", top: -4, right: -4,
                width: 16, height: 16, borderRadius: "50%",
                background: "#f97316", color: "#fff",
                fontSize: 9, fontWeight: 800,
                display: "flex", alignItems: "center", justifyContent: "center",
                border: "2px solid #fff",
              }}>{bookingRequests.filter(r => r.status === "pending").length}</span>
            )}
          </button>
          <div ref={userMenuRef} style={{ position: "relative" }}>
            <button type="button" onClick={() => setUserMenuOpen(v => !v)} style={{
              width: 32, height: 32, borderRadius: 8, border: "2px solid rgba(255,255,255,0.35)", cursor: "pointer",
              background: "rgba(255,255,255,0.2)",
              color: "#fff", fontWeight: 700, fontSize: 12,
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>{userInitials}</button>
            {userMenuOpen && (
              <div style={{
                position: "absolute", right: 0, top: "calc(100% + 8px)", width: 200,
                background: THEME.panelBg, border: `1.5px solid ${THEME.border}`, borderRadius: 12,
                boxShadow: "0 12px 32px rgba(30,64,175,0.15)", overflow: "hidden", zIndex: 60,
              }}>
                <Link href="/settings" onClick={() => setUserMenuOpen(false)} style={{
                  display: "flex", alignItems: "center", gap: 8, padding: "12px 16px",
                  color: THEME.text, textDecoration: "none", fontSize: 13, fontWeight: 600,
                  borderBottom: `1.5px solid ${THEME.border}`,
                }}>⚙️ Impostazioni</Link>
                <button type="button" onClick={handleLogout} style={{
                  width: "100%", display: "flex", alignItems: "center", gap: 8,
                  padding: "12px 16px", background: "transparent", border: "none", cursor: "pointer",
                  color: THEME.red, fontWeight: 600, fontSize: 13,
                }}>⏻ Logout</button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* ━━━ PANNELLO PRENOTAZIONI DAL SITO ━━━ */}
      {bookingPanel && (
        <>
          <div onClick={() => setBookingPanel(false)} style={{ position: "fixed", inset: 0, zIndex: 48, background: "rgba(0,0,0,0.3)" }} />
          <div style={{
            position: "fixed", top: 66, right: 16, zIndex: 49,
            width: 380, maxHeight: "80vh", overflowY: "auto",
            background: "#fff", borderRadius: 14,
            border: "1.5px solid #e2e8f0",
            boxShadow: "0 16px 48px rgba(0,0,0,0.18)",
          }}>
            {/* Header pannello */}
            <div style={{ padding: "14px 18px", borderBottom: "1px solid #e2e8f0", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div>
                <div style={{ fontWeight: 800, fontSize: 14, color: "#0f172a" }}>Prenotazioni dal sito</div>
                <div style={{ fontSize: 11, color: "#64748b", marginTop: 1 }}>
                  {bookingRequests.filter(r => r.status === "pending").length} in attesa · {bookingRequests.length} totali
                </div>
              </div>
              <button onClick={() => setBookingPanel(false)} style={{ border: "none", background: "none", fontSize: 18, cursor: "pointer", color: "#94a3b8" }}>✕</button>
            </div>

            {bookingLoading && <div style={{ padding: 24, textAlign: "center", color: "#94a3b8", fontSize: 13 }}>Caricamento…</div>}

            {!bookingLoading && bookingRequests.length === 0 && (
              <div style={{ padding: 32, textAlign: "center" }}>
                <div style={{ fontSize: 32, marginBottom: 8 }}>🎉</div>
                <div style={{ fontSize: 13, color: "#64748b" }}>Nessuna prenotazione ricevuta</div>
              </div>
            )}

            {bookingRequests.map(req => {
              const isActing = bookingActionId === req.id;
              const isPending   = req.status === "pending";
              const isConfirmed = req.status === "confirmed";
              const isCancelled = req.status === "cancelled";
              const dateStr = new Date(req.requested_date + "T12:00:00").toLocaleDateString("it-IT", { weekday: "short", day: "2-digit", month: "short" });
              const statusBadge = isPending
                ? { bg: "#fff7ed", color: "#c2410c", border: "#fed7aa", label: "In attesa" }
                : isConfirmed
                ? { bg: "#f0fdf4", color: "#15803d", border: "#bbf7d0", label: "Confermata" }
                : { bg: "#fff5f5", color: "#dc2626", border: "#fecaca", label: "Annullata" };
              return (
                <div key={req.id} style={{ padding: "14px 18px", borderBottom: "1px solid #f1f5f9" }}>
                  {/* Nome + data */}
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 6 }}>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 13, color: "#0f172a" }}>{req.patient_name}</div>
                      <div style={{ fontSize: 11, color: "#64748b", marginTop: 1 }}>{req.patient_phone}</div>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <div style={{ fontSize: 12, fontWeight: 700, color: "#0d9488" }}>{dateStr}</div>
                      <div style={{ fontSize: 12, fontWeight: 800, color: "#0f172a" }}>{req.requested_time.slice(0,5)}</div>
                    </div>
                  </div>
                  {/* Servizio + badge stato */}
                  <div style={{ display: "flex", gap: 6, alignItems: "center", marginBottom: 6, flexWrap: "wrap" }}>
                    <div style={{ fontSize: 11, background: "#f0fdfa", borderRadius: 6, padding: "3px 8px", color: "#0d9488", fontWeight: 700 }}>
                      {req.service_name} · {req.service_duration} min
                    </div>
                    <div style={{ fontSize: 10, background: statusBadge.bg, borderRadius: 99, padding: "2px 8px", color: statusBadge.color, fontWeight: 700, border: `1px solid ${statusBadge.border}` }}>
                      {statusBadge.label}
                    </div>
                  </div>
                  {/* Note */}
                  {req.notes && (
                    <div style={{ fontSize: 11, color: "#64748b", fontStyle: "italic", marginBottom: 8 }}>"{req.notes}"</div>
                  )}
                  {/* ── Azioni in attesa ── */}
                  {isPending && (
                    <div style={{ display: "flex", gap: 8 }}>
                      <button onClick={() => confirmBooking(req)} disabled={isActing}
                        style={{ flex: 1, padding: "7px 0", border: "none", borderRadius: 7, background: "#0d9488", color: "#fff", fontWeight: 700, fontSize: 12, cursor: "pointer", opacity: isActing ? 0.6 : 1 }}>
                        {isActing ? "…" : "✓ Conferma"}
                      </button>
                      <button onClick={() => rejectBooking(req.id)} disabled={isActing}
                        style={{ flex: 1, padding: "7px 0", border: "1.5px solid #fecaca", borderRadius: 7, background: "#fff5f5", color: "#dc2626", fontWeight: 700, fontSize: 12, cursor: "pointer", opacity: isActing ? 0.6 : 1 }}>
                        {isActing ? "…" : "✕ Annulla"}
                      </button>
                    </div>
                  )}
                  {/* ── Azioni confermata ── */}
                  {isConfirmed && (
                    <div style={{ display: "flex", gap: 8 }}>
                      <button onClick={() => rejectBooking(req.id)} disabled={isActing}
                        style={{ flex: 1, padding: "7px 0", border: "1.5px solid #fecaca", borderRadius: 7, background: "#fff5f5", color: "#dc2626", fontWeight: 700, fontSize: 12, cursor: "pointer", opacity: isActing ? 0.6 : 1 }}>
                        {isActing ? "…" : "✕ Annulla"}
                      </button>
                      <button onClick={async () => {
                        setBookingActionId(req.id);
                        await supabase.from("booking_requests").update({ status: "pending" }).eq("id", req.id);
                        await loadBookingRequests();
                        setBookingActionId(null);
                      }} disabled={isActing}
                        style={{ flex: 1, padding: "7px 0", border: "1.5px solid #e2e8f0", borderRadius: 7, background: "#f8fafc", color: "#64748b", fontWeight: 700, fontSize: 12, cursor: "pointer", opacity: isActing ? 0.6 : 1 }}>
                        {isActing ? "…" : "↩ Riapri"}
                      </button>
                    </div>
                  )}
                  {/* ── Azioni annullata ── */}
                  {isCancelled && (
                    <div style={{ display: "flex", gap: 8 }}>
                      <button onClick={() => confirmBooking(req)} disabled={isActing}
                        style={{ flex: 1, padding: "7px 0", border: "none", borderRadius: 7, background: "#0d9488", color: "#fff", fontWeight: 700, fontSize: 12, cursor: "pointer", opacity: isActing ? 0.6 : 1 }}>
                        {isActing ? "…" : "✓ Riconferma"}
                      </button>
                      <button onClick={async () => {
                        setBookingActionId(req.id);
                        await supabase.from("booking_requests").update({ status: "pending" }).eq("id", req.id);
                        await loadBookingRequests();
                        setBookingActionId(null);
                      }} disabled={isActing}
                        style={{ flex: 1, padding: "7px 0", border: "1.5px solid #e2e8f0", borderRadius: 7, background: "#f8fafc", color: "#64748b", fontWeight: 700, fontSize: 12, cursor: "pointer", opacity: isActing ? 0.6 : 1 }}>
                        {isActing ? "…" : "↩ Riapri"}
                      </button>
                    </div>
                  )}
                </div>
              );
            })}

            {/* Footer refresh */}
            <div style={{ padding: "10px 18px", borderTop: "1px solid #f1f5f9" }}>
              <button onClick={loadBookingRequests} style={{ width: "100%", padding: "7px", border: "1px solid #e2e8f0", borderRadius: 7, background: "#fff", color: "#64748b", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>
                ↻ Aggiorna
              </button>
            </div>
          </div>
        </>
      )}

      {/* ━━━ RIGHT PANEL: Today's appointments (replaces left sidebar) ━━━ */}
      {sidebarOpen && !isDesktop && (
        <div className="no-print" onClick={() => setSidebarOpen(false)}
          style={{ position: "fixed", inset: 0, background: "rgba(30,64,175,0.4)", zIndex: 40, backdropFilter: "blur(2px)" }} />
      )}

      <aside
        ref={sidebarRef}
        className={`no-print sidebar-scroll cal-sidebar ${showAllUpcoming ? "show-scrollbar" : ""}`}
        style={{
          width: SIDEBAR_W, maxWidth: "85vw",
          background: THEME.panelBg, borderLeft: `2px solid ${THEME.border}`,
          padding: "24px 18px",
          position: "fixed", right: 0, top: 58, height: "calc(100vh - 58px)",
          overflowY: "auto", zIndex: 50,
          transform: sidebarOpen ? "translateX(0)" : "translateX(110%)",
          transition: "transform 280ms cubic-bezier(.4,0,.2,1)",
          pointerEvents: sidebarOpen ? "auto" : "none",
          boxShadow: sidebarOpen ? "-8px 0 32px rgba(30,64,175,0.1)" : "none",
}}
      >
        {/* Panel header */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: THEME.blue, letterSpacing: 0.5, textTransform: "uppercase" }}>Oggi</div>
          <button type="button" onClick={() => setSidebarOpen(false)}
            style={{ border: "none", background: THEME.panelSoft, cursor: "pointer", color: THEME.text, fontSize: 16, padding: "4px 8px", borderRadius: 6, fontWeight: 700 }}>×</button>
        </div>

        {/* ── Mini-calendario navigazione ── */}
        {(() => {
          const mc = currentDate;
          const year = mc.getFullYear();
          const month = mc.getMonth();
          const firstDow = (new Date(year, month, 1).getDay() + 6) % 7; // 0=Lun
          const daysInMonth = new Date(year, month + 1, 0).getDate();
          const todayD = new Date(); todayD.setHours(0,0,0,0);
          const MESI = ["Gen","Feb","Mar","Apr","Mag","Giu","Lug","Ago","Set","Ott","Nov","Dic"];
          const GG = ["L","M","M","G","V","S","D"];
          const cells: (number|null)[] = [...Array(firstDow).fill(null), ...Array.from({length:daysInMonth},(_,i)=>i+1)];
          while(cells.length % 7 !== 0) cells.push(null);
          return (
            <div style={{ marginBottom: 20, background: THEME.panelSoft, borderRadius: 10, border: `1.5px solid ${THEME.border}`, padding: "12px 10px" }}>
              {/* Header mese */}
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
                <button onClick={() => setCurrentDate(d => { const x=new Date(d); x.setMonth(x.getMonth()-1); return x; })}
                  style={{ border: "none", background: "transparent", cursor: "pointer", fontSize: 14, color: THEME.muted, padding: "2px 6px", borderRadius: 4, fontWeight: 700 }}>◀</button>
                <span style={{ fontSize: 12, fontWeight: 700, color: THEME.text }}>{MESI[month]} {year}</span>
                <button onClick={() => setCurrentDate(d => { const x=new Date(d); x.setMonth(x.getMonth()+1); return x; })}
                  style={{ border: "none", background: "transparent", cursor: "pointer", fontSize: 14, color: THEME.muted, padding: "2px 6px", borderRadius: 4, fontWeight: 700 }}>▶</button>
              </div>
              {/* Intestazioni giorni */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(7,1fr)", marginBottom: 4 }}>
                {GG.map((g,i) => <div key={i} style={{ textAlign: "center", fontSize: 9, fontWeight: 700, color: i >= 5 ? THEME.amber : THEME.muted, padding: "2px 0" }}>{g}</div>)}
              </div>
              {/* Celle */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(7,1fr)", gap: 1 }}>
                {cells.map((day, idx) => {
                  if (day === null) return <div key={`mc-e-${idx}`}/>;
                  const cellDate = new Date(year, month, day); cellDate.setHours(0,0,0,0);
                  const isToday = cellDate.getTime() === todayD.getTime();
                  // evidenzia i giorni della settimana corrente in vista week
                  const weekStart = startOfISOWeekMonday(currentDate); weekStart.setHours(0,0,0,0);
                  const weekEnd = new Date(weekStart); weekEnd.setDate(weekStart.getDate()+5); weekEnd.setHours(23,59,59,999);
                  const inWeek = viewType === "week" && cellDate >= weekStart && cellDate <= weekEnd;
                  const isSelected = toDateInputValue(currentDate) === toDateInputValue(cellDate);
                  // check if day has events
                  const hasDomicile = events.some(ev => {
                    const ed = new Date(ev.start); ed.setHours(0,0,0,0);
                    return ed.getTime()===cellDate.getTime() && ev.location==="domicile" && ev.status!=="cancelled";
                  });
                  const hasEvents = events.some(ev => {
                    const ed = new Date(ev.start); ed.setHours(0,0,0,0);
                    return ed.getTime()===cellDate.getTime() && ev.status!=="cancelled";
                  });
                  return (
                    <div key={`mc-${idx}`}
                      onClick={() => setCurrentDate(cellDate)}
                      style={{
                        textAlign: "center", fontSize: 10, fontWeight: isToday||isSelected ? 800 : 500,
                        padding: "3px 1px", borderRadius: 5, cursor: "pointer", position: "relative",
                        background: isToday ? THEME.blue : isSelected && !isToday ? "rgba(37,99,235,0.12)" : inWeek ? "rgba(37,99,235,0.06)" : "transparent",
                        color: isToday ? "#fff" : (idx % 7 === 6) ? THEME.amber : THEME.text,
                        border: isSelected && !isToday ? `1.5px solid ${THEME.blue}` : "1.5px solid transparent",
                      }}
                    >
                      {day}
                      {hasEvents && !isToday && (
                        <div style={{ position: "absolute", bottom: 1, left: "50%", transform: "translateX(-50%)", display: "flex", gap: 1 }}>
                          <div style={{ width: 4, height: 4, borderRadius: "50%", background: hasDomicile ? THEME.amber : THEME.patientsAccent }}/>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
              <button onClick={() => setCurrentDate(new Date())} style={{ marginTop: 8, width: "100%", padding: "5px", borderRadius: 6, border: `1px solid ${THEME.border}`, background: "transparent", color: THEME.blue, fontSize: 11, fontWeight: 700, cursor: "pointer" }}>
                Torna a oggi
              </button>
            </div>
          );
        })()}

        {/* Sezione Appuntamenti Imminenti */}
        <div style={{ marginTop: 0, borderTop: `2px solid ${THEME.blue}`, paddingTop: 20 }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: THEME.textSoft, letterSpacing: 0.5, textTransform: "uppercase" }}>
              Prossimi
            </div>
            <div style={{
              fontSize: 11,
              fontWeight: 700,
              color: "#fff",
              background: "linear-gradient(135deg, #0d9488, #2563eb)",
              padding: "4px 10px",
              borderRadius: 6
            }}>
              {(() => {
                const now = currentTime || new Date();
                const upcoming = todaysAppointments.filter(a => a.end > now);
                return upcoming.length;
              })()}
            </div>
          </div>

          {(() => {
            const now = currentTime || new Date();
            const upcomingAll = todaysAppointments
              .filter(a => a.end > now) // sparisce quando finisce
              .sort((a, b) => a.start.getTime() - b.start.getTime());

            const nextFuture = upcomingAll.find(a => a.start > now) || null;
            const list = showAllUpcoming ? upcomingAll : upcomingAll.slice(0, 5);
            const remaining = Math.max(0, upcomingAll.length - 5);

            const timeStyle = (status: "past" | "current" | "next") => ({
              fontSize: 12,
              fontWeight: 600,
              padding: "3px 6px",
              borderRadius: 6,
              minWidth: 52,
              textAlign: "center" as const,
              border:
                status === "current"
                  ? `2px solid ${THEME.green}`
                  : status === "next"
                  ? `2px solid ${THEME.blue}`
                  : `1px solid ${THEME.border}`,
              color:
                status === "current"
                  ? THEME.green
                  : status === "next"
                  ? THEME.blue
                  : THEME.muted,
              background:
                status === "current"
                  ? "rgba(22,163,74,0.06)"
                  : status === "next"
                  ? "rgba(37,99,235,0.06)"
                  : THEME.panelSoft,
            });

            if (upcomingAll.length === 0) {
              return (
                <div style={{
                  textAlign: "center",
                  padding: "20px 12px",
                  background: THEME.panelSoft,
                  borderRadius: 8,
                  border: `1.5px solid ${THEME.border}`
                }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: THEME.muted, marginBottom: 4 }}>
                    Nessun appuntamento imminente
                  </div>
                  <div style={{ fontSize: 11, color: THEME.muted }}>
                    Oggi non ci sono altri appuntamenti in arrivo
                  </div>
                </div>
              );
            }

            return (
              <>
                <div style={{ display: "flex", flexDirection: "column", gap: 8, maxHeight: showAllUpcoming ? "520px" : "none", overflowY: showAllUpcoming ? "auto" : "hidden" }}>
                  {list.map((appointment) => {
                    const isNow = appointment.start <= now && appointment.end >= now;
                    const isNext = !isNow && nextFuture && nextFuture.id === appointment.id;

                    return (
                      <div
                        key={appointment.id}
                        style={{
                          background: isNow ? "rgba(43, 108, 176, 0.08)" : statusBg(appointment.status),
                          border: `2px solid ${isNow ? THEME.blue : statusColor(appointment.status)}50`,
                          borderRadius: 8,
                          padding: 10,
                          cursor: "pointer",
                          transition: "all 0.2s",
                          position: "relative",
                          overflow: "visible",
                        }}
                        onClick={() => {
                          setQuickActionsMenu(null);
                          setSelectedEvent({
                            id: appointment.id,
                            title: appointment.patient_name,
                            patient_id: appointment.patient_id,
                            location: appointment.location,
                            clinic_site: appointment.clinic_site,
                            domicile_address: appointment.domicile_address,
                            treatment: appointment.treatment,
                            diagnosis: appointment.diagnosis,
                            amount: appointment.amount,
                            treatment_type: appointment.treatment_type,
                            price_type: appointment.price_type,
                            start: appointment.start,
                            end: appointment.end,
                          });
                          setEditStatus(appointment.status);
                          setEditNote(appointment.calendar_note || "");
                          setEditAmount(appointment.amount !== undefined && appointment.amount !== null ? appointment.amount.toString() : "");
                          setEditTreatmentType((appointment.treatment_type as "seduta" | "macchinario") || "seduta");
                          setEditPriceType((appointment.price_type as "invoiced" | "cash") || "invoiced");
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.transform = "translateY(-2px)";
                          e.currentTarget.style.boxShadow = "0 4px 12px rgba(37,99,235,0.12)";
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.transform = "translateY(0)";
                          e.currentTarget.style.boxShadow = "none";
                        }}
                      >
                        <div style={{
                          position: "absolute",
                          top: 0,
                          left: 0,
                          width: 6,
                          height: "100%",
                          borderRadius: "8px 0 0 8px",
                          background: statusColor(appointment.status)
                        }} />

                        <div style={{ display: "flex", alignItems: "flex-start", gap: 8, marginLeft: 4 }}>
                          <div style={{ flex: 1 }}>
                            <div style={{
                              display: "flex",
                              alignItems: "center",
                              gap: 6,
                              marginBottom: 4
                            }}>
                              <div style={timeStyle(isNow ? "current" : isNext ? "next" : "past")}>
                                {fmtTime(appointment.start.toISOString())}
                              </div>

                              {isNow && (
                                <div style={{
                                  fontSize: 10,
                                  fontWeight: 600,
                                  color: "#fff",
                                  background: THEME.green,
                                  padding: "2px 6px",
                                  borderRadius: 4
                                }}>
                                  IN CORSO
                                </div>
                              )}

                              {isNext && (
                                <div style={{
                                  fontSize: 10,
                                  fontWeight: 600,
                                  color: "#fff",
                                  background: THEME.blue,
                                  padding: "2px 6px",
                                  borderRadius: 4
                                }}>
                                  PROSSIMO
                                </div>
                              )}
                            </div>

                            <div style={{
                              fontSize: 13,
                              fontWeight: 600,
                              color: THEME.text,
                              lineHeight: 1.35,
                              marginBottom: 4
                            }}>
                              {appointment.patient_name}
                            </div>

                            <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                              <div style={{
                                fontSize: 10,
                                fontWeight: 700,
                                color: statusColor(appointment.status),
                                display: "flex",
                                alignItems: "center",
                                gap: 2
                              }}>
                                <div style={{
                                  width: 8,
                                  height: 8,
                                  borderRadius: "50%",
                                  background: statusColor(appointment.status)
                                }} />
                                {statusLabel(appointment.status)}
                              </div>

                              {appointment.location === "domicile" && (
                                <div style={{
                                  fontSize: 10,
                                  fontWeight: 600,
                                  color: THEME.amber,
                                  display: "flex",
                                  alignItems: "center",
                                  gap: 2
                                }}>
                                  ⌂ Domicilio
                                </div>
                              )}
                            </div>
                          </div>

                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleDoneQuick(appointment.id, appointment.status);
                            }}
                            style={{
                              width: 20,
                              height: 20,
                              borderRadius: 4,
                              border: `2px solid ${appointment.status === "done" ? THEME.greenDark : THEME.border}`,
                              background: appointment.status === "done" ? THEME.greenDark : "transparent",
                              cursor: "pointer",
                              flex: "0 0 auto",
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "center",
                              fontSize: 10,
                              color: "#fff",
                            }}
                            title={appointment.status === "done" ? "Segna come non eseguito" : "Segna come eseguito"}
                          >
                            {appointment.status === "done" && "✓"}
                          </button>
                        </div>

                        {appointment.calendar_note && (
                          <div style={{
                            marginTop: 8,
                            fontSize: 11,
                            color: THEME.muted,
                            fontStyle: "italic",
                            paddingLeft: 4,
                            borderLeft: `2px solid ${THEME.borderSoft}`
                          }}>
                            {appointment.calendar_note}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {remaining > 0 && !showAllUpcoming && (
                  <button
                    type="button"
                    onClick={() => setShowAllUpcoming(true)}
                    style={{
                      marginTop: 12,
                      width: "100%",
                      border: `1.5px solid ${THEME.border}`,
                      background: THEME.panelBg,
                      borderRadius: 8,
                      padding: "8px 10px",
                      cursor: "pointer",
                      fontSize: 12,
                      fontWeight: 600,
                      color: THEME.blue,
                      textAlign: "center",
                    }}
                    title="Mostra tutti gli appuntamenti imminenti di oggi"
                  >
                    +{remaining} altri oggi
                  </button>
                )}

                {showAllUpcoming && upcomingAll.length > 5 && (
                  <button
                    type="button"
                    onClick={() => setShowAllUpcoming(false)}
                    style={{
                      marginTop: 12,
                      width: "100%",
                      border: `1.5px solid ${THEME.border}`,
                      background: THEME.panelSoft,
                      borderRadius: 8,
                      padding: "8px 10px",
                      cursor: "pointer",
                      fontSize: 12,
                      fontWeight: 600,
                      color: THEME.muted,
                      textAlign: "center",
                    }}
                    title="Mostra solo i primi 5"
                  >
                    Mostra meno
                  </button>
                )}

                <div style={{ marginTop: 16, fontSize: 11, color: THEME.muted, textAlign: "center" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span>Completati: {todaysAppointments.filter(a => a.status === "done").length}</span>
                    <span>Prenotati: € {Math.round(weeklyExpectedRevenue).toLocaleString("it-IT")}</span>
                  </div>
                </div>
              </>
            );
          })()}
        </div>
      </aside>

      <main className="print-wrap" style={{
        flex: 1, display: "flex", flexDirection: "column",
        padding: "12px 28px", minWidth: 0,
        marginRight: isDesktop && sidebarOpen ? SIDEBAR_W : 0,
        width: isDesktop && sidebarOpen ? `calc(100% - ${SIDEBAR_W}px)` : "100%",
        boxSizing: "border-box",
        transition: "margin-right 280ms cubic-bezier(.4,0,.2,1), width 280ms cubic-bezier(.4,0,.2,1)",
        overflowX: "hidden",
        maxWidth: 1440, marginTop: 0, marginBottom: 0, marginLeft: "auto",
}}>
        <div style={{ width: "100%" }}>

          {error && (
            <div
              className={`no-print sidebar-scroll ${showAllUpcoming ? "show-scrollbar" : ""}`}
              style={{
                marginTop: 8,
                marginBottom: 16,
                background: "rgba(220,38,38,0.06)",
                border: "1px solid rgba(220,38,38,0.15)",
                color: THEME.red,
                padding: "12px 16px",
                borderRadius: 10,
                fontWeight: 600,
                fontSize: 13,
              }}
            >
              {error}
            </div>
          )}

          {loading && (
            <div style={{ 
              padding: 40, 
              textAlign: "center", 
              color: THEME.muted, 
              fontWeight: 600, 
              fontSize: 14,
              background: THEME.panelBg,
              borderRadius: 10,
              border: `1.5px solid ${THEME.border}`,
              boxShadow: "0 2px 8px rgba(30,64,175,0.05)",
            }}>
              Caricamento appuntamenti...
            </div>
          )}

          {/* ── FILTRI AVANZATI — popover ── */}
          {filtersPopoverOpen && (
            <div className="no-print" style={{ position: "fixed", inset: 0, zIndex: 29 }} onClick={() => setFiltersPopoverOpen(false)}/>
          )}
          {filtersPopoverOpen && (
            <div className="no-print" style={{
              position: "fixed", top: 70, left: "50%", transform: "translateX(-50%)",
              zIndex: 30, background: THEME.panelBg, border: `2px solid ${THEME.border}`,
              borderRadius: 12, padding: "18px 20px", boxShadow: "0 8px 32px rgba(30,64,175,0.14)",
              width: 540, maxWidth: "96vw",
            }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
                <span style={{ fontSize: 13, fontWeight: 700, color: THEME.blue }}>⚙ Filtri</span>
                <button onClick={() => setFiltersPopoverOpen(false)} style={{ border: "none", background: "transparent", cursor: "pointer", fontSize: 16, color: THEME.muted, padding: "2px 6px" }}>✕</button>
              </div>

              {/* Stato */}
              <div style={{ marginBottom: 16 }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: THEME.muted, textTransform: "uppercase" as const, letterSpacing: 0.5, marginBottom: 8 }}>Stato appuntamento</div>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap" as const }}>
                  {(["all", "booked", "confirmed", "done", "not_paid", "cancelled"] as const).map(status => (
                    <button key={status} onClick={() => setStatusFilter(status as Status | "all")} style={{
                      padding: "6px 12px", borderRadius: 6, cursor: "pointer", fontWeight: 600, fontSize: 11, transition: "all 0.15s",
                      border: `1px solid ${statusFilter === status ? statusColor(status as Status) : THEME.borderSoft}`,
                      background: statusFilter === status ? statusColor(status as Status) : THEME.panelBg,
                      color: statusFilter === status ? "#fff" : THEME.text,
                    }}>
                      {status === "all" ? "Tutti" : statusLabel(status as Status)}
                    </button>
                  ))}
                </div>
              </div>

              {/* Luogo + Trattamento */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 16 }}>
                <div>
                  <div style={{ fontSize: 11, fontWeight: 700, color: THEME.muted, textTransform: "uppercase" as const, letterSpacing: 0.5, marginBottom: 6 }}>Luogo</div>
                  <select value={filters.location} onChange={e => setFilters(p => ({ ...p, location: e.target.value as "all"|"studio"|"domicile" }))}
                    style={{ width: "100%", padding: "8px 10px", borderRadius: 7, border: `1px solid ${THEME.borderSoft}`, background: THEME.panelBg, fontSize: 12, fontWeight: 600, color: THEME.text }}>
                    <option value="all">Tutti i luoghi</option>
                    <option value="studio">Studio</option>
                    <option value="domicile">Domicilio</option>
                  </select>
                </div>
                <div>
                  <div style={{ fontSize: 11, fontWeight: 700, color: THEME.muted, textTransform: "uppercase" as const, letterSpacing: 0.5, marginBottom: 6 }}>Trattamento</div>
                  <select value={filters.treatmentType} onChange={e => setFilters(p => ({ ...p, treatmentType: e.target.value as "all" | TreatmentType }))}
                    style={{ width: "100%", padding: "8px 10px", borderRadius: 7, border: `1px solid ${THEME.borderSoft}`, background: THEME.panelBg, fontSize: 12, fontWeight: 600, color: THEME.text }}>
                    <option value="all">Tutti</option>
                    {ALL_TREATMENTS.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
                  </select>
                </div>
              </div>

              {/* Slot liberi */}
              <div style={{ borderTop: `1px solid ${THEME.border}`, paddingTop: 14 }}>
                <label style={{ display: "flex", alignItems: "center", gap: 10, cursor: "pointer" }}>
                  <div style={{
                    width: 36, height: 20, borderRadius: 999,
                    background: showAvailableOnly ? THEME.green : THEME.borderSoft,
                    position: "relative", transition: "background 0.2s", flexShrink: 0,
                  }}>
                    <div style={{
                      width: 16, height: 16, borderRadius: "50%", background: "#fff",
                      position: "absolute", top: 2,
                      left: showAvailableOnly ? 18 : 2,
                      transition: "left 0.2s",
                      boxShadow: "0 1px 3px rgba(0,0,0,0.2)",
                    }}/>
                    <input type="checkbox" checked={showAvailableOnly} onChange={e => setShowAvailableOnly(e.target.checked)} style={{ position: "absolute", opacity: 0, width: 0, height: 0 }}/>
                  </div>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 700, color: THEME.text }}>Mostra finestre libere</div>
                    <div style={{ fontSize: 11, color: THEME.muted, marginTop: 2 }}>Evidenzia i gap tra appuntamenti in cui puoi inserirne di nuovi</div>
                  </div>
                </label>
              </div>

              <div style={{ display: "flex", justifyContent: "space-between", marginTop: 16, alignItems: "center" }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: THEME.muted }}>{filteredEvents.length} eventi visibili</div>
                <button onClick={() => { setFilters({ location: "all", treatmentType: "all", priceType: "all", minAmount: "", maxAmount: "" }); setStatusFilter("all"); setShowAvailableOnly(false); }}
                  style={{ padding: "6px 14px", borderRadius: 7, border: `1px solid ${THEME.borderSoft}`, background: THEME.panelSoft, color: THEME.text, fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
                  Reset tutto
                </button>
              </div>
            </div>
          )}

          <div className={`no-print sidebar-scroll ${showAllUpcoming ? "show-scrollbar" : ""}`} style={{ 
            display: "flex", 
            justifyContent: "space-between", 
            alignItems: "center", 
            marginBottom: 16,
            padding: "12px 16px",
            background: THEME.panelBg,
            borderRadius: 8,
            border: `1.5px solid ${THEME.border}`,
            top: 0,
            zIndex: 9,
          }}>
            <div style={{ display: "flex", gap: 8 }}>
              {viewType === "week" ? (
                <>
                  <button
                    onClick={goToPreviousWeek}
                    style={{
                      padding: "8px 16px",
                      borderRadius: 8,
                      border: `1px solid ${THEME.borderSoft}`,
                      background: THEME.panelSoft,
                      color: THEME.text,
                      cursor: "pointer",
                      fontWeight: 600,
                      fontSize: 13,
                      minWidth: 44,
                    }}
                  >
                    ◀
                  </button>
                  <button
                    onClick={goToToday}
                    style={{
                      padding: "8px 16px",
                      borderRadius: 8,
                      border: `1px solid ${THEME.blueDark}`,
                      background: THEME.blue,
                      color: "#fff",
                      cursor: "pointer",
                      fontWeight: 600,
                      fontSize: 13,
                    }}
                  >
                    Oggi
                  </button>
                  <button
                    onClick={goToNextWeek}
                    style={{
                      padding: "8px 16px",
                      borderRadius: 8,
                      border: `1px solid ${THEME.borderSoft}`,
                      background: THEME.panelSoft,
                      color: THEME.text,
                      cursor: "pointer",
                      fontWeight: 600,
                      fontSize: 13,
                      minWidth: 44,
                    }}
                  >
                    ▶
                  </button>
                </>
              ) : viewType === "month" ? (
                <>
                  <button
                    onClick={goToPreviousMonth}
                    style={{
                      padding: "8px 16px",
                      borderRadius: 8,
                      border: `1px solid ${THEME.borderSoft}`,
                      background: THEME.panelSoft,
                      color: THEME.text,
                      cursor: "pointer",
                      fontWeight: 600,
                      fontSize: 13,
                      minWidth: 44,
                    }}
                  >
                    ◀
                  </button>
                  <button
                    onClick={goToToday}
                    style={{
                      padding: "8px 16px",
                      borderRadius: 8,
                      border: `1px solid ${THEME.blueDark}`,
                      background: THEME.blue,
                      color: "#fff",
                      cursor: "pointer",
                      fontWeight: 600,
                      fontSize: 13,
                    }}
                  >
                    Oggi
                  </button>
                  <button
                    onClick={goToNextMonth}
                    style={{
                      padding: "8px 16px",
                      borderRadius: 8,
                      border: `1px solid ${THEME.borderSoft}`,
                      background: THEME.panelSoft,
                      color: THEME.text,
                      cursor: "pointer",
                      fontWeight: 600,
                      fontSize: 13,
                      minWidth: 44,
                    }}
                  >
                    ▶
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={() => setCurrentDate(prev => addDays(prev, -1))}
                    style={{
                      padding: "8px 16px",
                      borderRadius: 8,
                      border: `1px solid ${THEME.borderSoft}`,
                      background: THEME.panelSoft,
                      color: THEME.text,
                      cursor: "pointer",
                      fontWeight: 600,
                      fontSize: 13,
                      minWidth: 44,
                    }}
                  >
                    ◀
                  </button>
                  <button
                    onClick={() => setCurrentDate(new Date())}
                    style={{
                      padding: "8px 16px",
                      borderRadius: 8,
                      border: `1px solid ${THEME.blueDark}`,
                      background: THEME.blue,
                      color: "#fff",
                      cursor: "pointer",
                      fontWeight: 600,
                      fontSize: 13,
                    }}
                  >
                    Oggi
                  </button>
                  <button
                    onClick={() => setCurrentDate(prev => addDays(prev, 1))}
                    style={{
                      padding: "8px 16px",
                      borderRadius: 8,
                      border: `1px solid ${THEME.borderSoft}`,
                      background: THEME.panelSoft,
                      color: THEME.text,
                      cursor: "pointer",
                      fontWeight: 600,
                      fontSize: 13,
                      minWidth: 44,
                    }}
                  >
                    ▶
                  </button>
                </>
              )}
            </div>

            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <div style={{ display: "flex", gap: 8, alignItems: "center", marginRight: 12 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: THEME.green, background: "rgba(22, 163, 74, 0.1)", padding: "4px 8px", borderRadius: 6 }}>
                  ✓ {stats.done}/{stats.total}
                </div>
                <div style={{ fontSize: 12, fontWeight: 600, color: THEME.blue, background: "rgba(91,130,168,0.1)", padding: "4px 8px", borderRadius: 6 }}>
                  €{stats.revenue}
                </div>
                <div style={{ fontSize: 12, fontWeight: 600, color: THEME.amber, background: "rgba(245, 158, 11, 0.1)", padding: "4px 8px", borderRadius: 6 }}>
                  € {Math.round(weeklyExpectedRevenue).toLocaleString("it-IT")} prev.
                </div>
              </div>

              {/* Ricerca rapida */}
              <div style={{ position: "relative" }}>
                <input
                  value={calendarSearch}
                  onChange={(e) => setCalendarSearch(e.target.value)}
                  placeholder="Cerca paziente..."
                  style={{
                    padding: "7px 70px 7px 12px",
                    borderRadius: 8,
                    border: isSearchActive ? `2px solid #f59e0b` : `1px solid ${THEME.borderSoft}`,
                    background: isSearchActive ? "rgba(245,158,11,0.06)" : THEME.panelBg,
                    color: THEME.text,
                    fontWeight: 600,
                    fontSize: 12,
                    width: 180,
                    outline: "none",
                    boxShadow: isSearchActive ? "0 0 8px rgba(245,158,11,0.2)" : "none",
                  }}
                />
                {calendarSearch.trim().length >= 2 && (
                  <div style={{ position: "absolute", right: 8, top: "50%", transform: "translateY(-50%)", display: "flex", alignItems: "center", gap: 6 }}>
                    <span style={{ fontSize: 10, fontWeight: 800, color: searchMatchIds.size > 0 ? "#92400e" : THEME.red, background: searchMatchIds.size > 0 ? "rgba(245,158,11,0.25)" : "rgba(220,38,38,0.1)", padding: "2px 6px", borderRadius: 4 }}>{searchMatchIds.size}</span>
                    <button onClick={() => setCalendarSearch("")} style={{ width: 18, height: 18, borderRadius: 4, border: "none", background: "rgba(107,114,128,0.15)", color: THEME.muted, cursor: "pointer", fontWeight: 800, fontSize: 11, display: "flex", alignItems: "center", justifyContent: "center", padding: 0 }}>✕</button>
                  </div>
                )}
              </div>

              {/* Filtri — bottone che apre il popover */}
              <button
                onClick={() => setFiltersPopoverOpen(v => !v)}
                style={{
                  padding: "8px 14px", borderRadius: 8,
                  border: `1.5px solid ${(filters.location !== "all" || filters.treatmentType !== "all" || filters.minAmount || filters.maxAmount) ? THEME.blue : THEME.border}`,
                  background: (filters.location !== "all" || filters.treatmentType !== "all" || filters.minAmount || filters.maxAmount) ? "rgba(37,99,235,0.08)" : THEME.panelSoft,
                  color: (filters.location !== "all" || filters.treatmentType !== "all" || filters.minAmount || filters.maxAmount) ? THEME.blue : THEME.text,
                  cursor: "pointer", fontWeight: 700, fontSize: 12,
                  display: "flex", alignItems: "center", gap: 5, whiteSpace: "nowrap" as const,
                }}
              >
                ⚙ Filtri{(filters.location !== "all" || filters.treatmentType !== "all" || filters.minAmount || filters.maxAmount) ? " ●" : ""}
              </button>

              {/* Menu Azioni — raggruppa CSV, Riepilogo, Bulk */}
              <div style={{ position: "relative" }}>
                <button
                  onClick={() => setActionsMenuOpen(v => !v)}
                  style={{
                    padding: "8px 14px", borderRadius: 8,
                    border: `1px solid ${THEME.border}`,
                    background: THEME.panelSoft, color: THEME.text,
                    cursor: "pointer", fontWeight: 700, fontSize: 12,
                    display: "flex", alignItems: "center", gap: 5, whiteSpace: "nowrap" as const,
                  }}
                >
                  Azioni {actionsMenuOpen ? "▲" : "▼"}
                </button>
                {actionsMenuOpen && (
                  <>
                    <div style={{ position: "fixed", inset: 0, zIndex: 9998 }} onClick={() => setActionsMenuOpen(false)}/>
                    <div style={{
                      position: "fixed",
                      top: 120,
                      right: 28,
                      background: THEME.panelBg, border: `1.5px solid ${THEME.border}`,
                      borderRadius: 10, boxShadow: "0 8px 28px rgba(30,64,175,0.18)",
                      zIndex: 9999, minWidth: 220, overflow: "hidden",
                    }}>
                      <button onClick={() => { exportAppointments(); setActionsMenuOpen(false); }}
                        style={{ width: "100%", padding: "11px 16px", background: "none", border: "none", borderBottom: `1px solid ${THEME.border}`, textAlign: "left", fontSize: 13, fontWeight: 600, cursor: "pointer", color: THEME.text }}>
                        ▤ Esporta CSV
                      </button>
                      <button onClick={() => { setDailySummaryOpen(true); setActionsMenuOpen(false); }}
                        style={{ width: "100%", padding: "11px 16px", background: "none", border: "none", borderBottom: `1px solid ${THEME.border}`, textAlign: "left", fontSize: 13, fontWeight: 600, cursor: "pointer", color: THEME.text }}>
                        📋 Riepilogo giornaliero
                      </button>
                      <button onClick={() => { setBulkMode(m => !m); setBulkSelected(new Set()); setActionsMenuOpen(false); }}
                        style={{ width: "100%", padding: "11px 16px", background: "none", border: "none", textAlign: "left", fontSize: 13, fontWeight: 600, cursor: "pointer", color: bulkMode ? THEME.blue : THEME.text }}>
                        💰 {bulkMode ? `Bulk attivo (${bulkSelected.size})` : "Segna pagati in blocco"}
                      </button>
                    </div>
                  </>
                )}
              </div>

              {/* Bulk confirm — visibile solo se bulk attivo e selezione > 0 */}
              {bulkMode && bulkSelected.size > 0 && (
                <button onClick={bulkMarkPaid} style={{ padding: "8px 14px", borderRadius: 8, border: "none", background: THEME.green, color: "#fff", cursor: "pointer", fontWeight: 700, fontSize: 12, whiteSpace: "nowrap" as const }}>
                  Segna {bulkSelected.size} pagati
                </button>
              )}
            </div>

            <div style={{ display: "flex", gap: 4 }}>
              <button
                onClick={() => {
                  setViewType("day");
                  if (viewType !== "day") {
                    setCurrentDate(new Date());
                  }
                }}
                style={{
                  padding: "8px 18px",
                  borderRadius: "8px 0 0 8px",
                  border: `2px solid ${viewType === "day" ? THEME.blue : THEME.border}`,
                  background: viewType === "day" ? "linear-gradient(135deg, #0d9488, #2563eb)" : THEME.panelBg,
                  color: viewType === "day" ? "#93c5fd" : THEME.text,
                  cursor: "pointer",
                  fontWeight: 700,
                  fontSize: 13,
                  minWidth: 80,
                  letterSpacing: 0.3,
                }}
              >
                Giorno
              </button>
              <button
                onClick={() => {
                  setViewType("week");
                  if (viewType !== "week") {
                    setCurrentDate(new Date());
                  }
                }}
                style={{
                  padding: "8px 18px",
                  borderRadius: 0,
                  border: `2px solid ${viewType === "week" ? THEME.blue : THEME.border}`,
                  background: viewType === "week" ? "linear-gradient(135deg, #0d9488, #2563eb)" : THEME.panelBg,
                  color: viewType === "week" ? "#93c5fd" : THEME.text,
                  cursor: "pointer",
                  fontWeight: 700,
                  fontSize: 13,
                  minWidth: 80,
                  letterSpacing: 0.3,
                }}
              >
                Settimana
              </button>
              <button
                onClick={() => {
                  setViewType("month");
                  if (viewType !== "month") {
                    setCurrentDate(new Date());
                  }
                }}
                style={{
                  padding: "8px 18px",
                  borderRadius: "0 8px 8px 0",
                  border: `2px solid ${viewType === "month" ? THEME.blue : THEME.border}`,
                  background: viewType === "month" ? "linear-gradient(135deg, #0d9488, #2563eb)" : THEME.panelBg,
                  color: viewType === "month" ? "#93c5fd" : THEME.text,
                  cursor: "pointer",
                  fontWeight: 700,
                  fontSize: 13,
                  minWidth: 80,
                  letterSpacing: 0.3,
                }}
              >
                Mese
              </button>
            </div>
          </div>


          {viewType === "week" ? (
            <div
              style={{
                background: THEME.panelBg,
                border: `2px solid ${THEME.border}`,
                borderRadius: 12,
                minHeight: 600,
                overflow: "clip",
                boxShadow: "0 2px 12px rgba(30,64,175,0.06)",
                position: "relative",
              }}
            >
              <div style={{ 
  display: "grid", 
  gridTemplateColumns: `${TIME_COL}px repeat(6, minmax(0, 1fr))`,
  borderBottom: `2px solid ${THEME.border}`,
  background: "linear-gradient(135deg, #0d9488, #2563eb)",
  position: "sticky",
  top: 0,
  zIndex: 8,
  borderRadius: "10px 10px 0 0",
}}>
  <div style={{ 
    padding: "12px 8px", 
    borderRight: "1px solid rgba(255,255,255,0.08)",
    fontSize: 11,
    fontWeight: 700,
    color: "rgba(255,255,255,0.7)",
    textAlign: "center",
    boxSizing: "border-box",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    height: "100%",
    letterSpacing: 1,
    textTransform: "uppercase",
  }}>
    ORA
  </div>
  {weekDays.map((day, index) => {
    const forecast = getAvailabilityForecast(day);
    return (
      <div 
        key={index}
        style={{ 
          padding: "8px 4px", 
          borderRight: index < 5 ? "1px solid rgba(255,255,255,0.12)" : "none",
          textAlign: "center",
          fontSize: 13,
          fontWeight: 800,
          color: "#ffffff",
          boxSizing: "border-box",
          width: "100%",
          overflow: "visible",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          minHeight: "60px",
        }}
      >
        <div style={{ marginBottom: 2, letterSpacing: 1 }}>
          {dayLabels[index].label}
        </div>
        <div style={{ fontSize: 11, marginBottom: 4, color: "rgba(255,255,255,0.7)", fontWeight: 600 }}>
          {formatDMY(day)}
        </div>
        <div style={{
          fontSize: 10,
          fontWeight: 700,
          color: forecast.occupancyRate > 40 ? "#fecaca" : forecast.occupancyRate > 20 ? "#fef3c7" : "#bbf7d0",
          lineHeight: 1.2,
          padding: "3px 8px",
          background: "rgba(255,255,255,0.12)",
          borderRadius: 4,
          margin: "0 4px",
          letterSpacing: 0.3,
        }}>
          {forecast.totalEvents} appt • {forecast.occupancyRate > 40 ? "ALTA" : forecast.occupancyRate > 20 ? "MEDIA" : "BASSA"}
        </div>
        {/* Indicatore domicilio nel giorno */}
        {filteredEvents.some(ev => {
          const evDate = new Date(ev.start); evDate.setHours(0,0,0,0);
          const colDate = new Date(day); colDate.setHours(0,0,0,0);
          return evDate.getTime() === colDate.getTime() && ev.location === "domicile";
        }) && (
          <div style={{ fontSize: 9, fontWeight: 700, color: "#fed7aa", marginTop: 2, letterSpacing: 0.3 }}>⌂ domicilio</div>
        )}
      </div>
    );
  })}
</div>

              <div style={{ position: "relative" }}>
                <div style={{ position: "relative", minHeight: "calc(15 * 60px)" }}>
                  {timeSlots.map((time, timeIndex) => (
                    <div 
                      key={timeIndex}
                      style={{ 
                        height: "60px",
                        borderBottom: `1.5px solid ${THEME.border}`,
                        position: "relative",
                        display: "flex",
                      }}
                    >
                      <div style={{ 
                        width: `${TIME_COL}px`,
                        height: "100%",
                        display: "flex",
                        alignItems: "center",
                        paddingLeft: 8,
                        borderRight: `1px solid ${THEME.border}`,
                        fontSize: 12,
                        fontWeight: 600,
                        color: THEME.muted,
                        background: THEME.panelSoft,
                        zIndex: 1,
                        flexShrink: 0,
                        boxSizing: "border-box",
                        position: "sticky",
                        left: 0,
                      }}>
                        {time}
                      </div>

                      {weekDays.map((day, dayIndex) => {
                        const hour = parseInt(time.split(':')[0]);
                        
                        return (
                          <div
                            key={`${timeIndex}-${dayIndex}`}
                            style={{
                              flex: 1,
                              minWidth: 0,
                              height: "100%",
                              borderRight: dayIndex < 5 ? `1px solid ${THEME.border}` : "none",
                              boxSizing: "border-box",
                              position: "relative",
                            }}
                          >
                            {/* Slot 00-30 minuti */}
                            <div
                              style={{
                                height: "30px",
                                borderBottom: `1.5px solid ${THEME.border}`,
                                cursor: "pointer",
                                boxSizing: "border-box",
                                position: "relative",
                              }}
                              onClick={() => {
                                handleSlotClick(day, hour, 0);
                              }}
                              onContextMenu={(e) => handleContextMenu(e)}
                              onDragOver={(e) => handleDragOver(e, dayIndex, hour, 0)}
                              onDragLeave={handleDragLeave}
                              onDrop={(e) => {
                                handleDrop(e, day, hour, 0);
                              }}
                              title={`Clicca per creare appuntamento alle ${pad2(hour)}:00`}
                            >
                              {draggingOver && draggingOver.dayIndex === dayIndex && 
                               draggingOver.hour === hour && draggingOver.minute === 0 && (
                                <div
                                  style={{
                                    position: "absolute",
                                    top: 0,
                                    left: 0,
                                    right: 0,
                                    bottom: 0,
                                    border: `2px dashed ${THEME.blue}`,
                                    background: "rgba(91,130,168,0.1)",
                                    zIndex: 1,
                                    pointerEvents: "none",
                                  }}
                                />
                              )}
                            </div>
                            
                            {/* Slot 30-60 minuti */}
                            <div
                              style={{
                                height: "30px",
                                cursor: "pointer",
                                boxSizing: "border-box",
                                position: "relative",
                              }}
                              onClick={() => {
                                handleSlotClick(day, hour, 30);
                              }}
                              onContextMenu={(e) => handleContextMenu(e)}
                              onDragOver={(e) => handleDragOver(e, dayIndex, hour, 30)}
                              onDragLeave={handleDragLeave}
                              onDrop={(e) => {
                                handleDrop(e, day, hour, 30);
                              }}
                              title={`Clicca per creare appuntamento alle ${pad2(hour)}:30`}
                            >
                              {draggingOver && draggingOver.dayIndex === dayIndex && 
                               draggingOver.hour === hour && draggingOver.minute === 30 && (
                                <div
                                  style={{
                                    position: "absolute",
                                    top: 0,
                                    left: 0,
                                    right: 0,
                                    bottom: 0,
                                    border: `2px dashed ${THEME.blue}`,
                                    background: "rgba(91,130,168,0.1)",
                                    zIndex: 1,
                                    pointerEvents: "none",
                                  }}
                                />
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ))}

                  {/* Drag ghost preview */}
                  {draggingEvent && draggingOver && (
                    <div
                      style={{
                        position: "absolute",
                        left: `calc(${TIME_COL}px + ${draggingOver.dayIndex} * calc((100% - 80px) / 6) + 2px)`,
                        top: `${(draggingOver.hour - 7) * 60 + draggingOver.minute}px`,
                        width: `calc((100% - ${TIME_COL}px) / 6 - 8px)`,
                        height: `${Math.max((draggingEvent.originalEnd.getTime() - draggingEvent.originalStart.getTime()) / 60000, 28)}px`,
                        background: "rgba(37,99,235,0.12)",
                        border: `2px dashed ${THEME.blue}`,
                        borderRadius: 8,
                        zIndex: 5,
                        pointerEvents: "none",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: 11,
                        fontWeight: 700,
                        color: THEME.blue,
                        transition: "top 0.1s ease, left 0.1s ease",
                      }}
                    >
                      {`${pad2(draggingOver.hour)}:${pad2(draggingOver.minute)}`}
                    </div>
                  )}

                  {filteredEvents.map((event) => {
                    const dayIndex = weekDays.findIndex(day => 
                      event.start.getDate() === day.getDate() &&
                      event.start.getMonth() === day.getMonth() &&
                      event.start.getFullYear() === day.getFullYear()
                    );

                    if (dayIndex === -1) return null;

                    const { top, height } = getEventPosition(event.start, event.end);
                    const col = getEventColor(event);
                    const isDone = event.status === "done";
                    const isDomicile = event.location === "domicile";
                    const isPaid = !!event.is_paid;
                    const waSent = !!event.whatsapp_sent_at;

                    const isMatch = searchMatchIds.has(event.id);
                    const isDimmed = isSearchActive && !isMatch;

                    return (
                      <div
                        key={event.id}
                        draggable
                        onDragStart={(e) => handleDragStart(e, event.id, event.start, event.end)}
                        onDragEnd={handleDragEnd}
                        onContextMenu={(e) => handleContextMenu(e, event)}
                        className={isMatch ? "search-highlight" : isDimmed ? "search-dimmed" : ""}
                        style={{
                          position: "absolute",
                          left: `calc(${TIME_COL}px + ${dayIndex} * calc((100% - 80px) / 6) + 2px)`,
                          top: `${top + 1}px`,
                          width: `calc((100% - ${TIME_COL}px) / 6 - 8px)`,
                          height: `${Math.max(height - 2, 28)}px`,
                          background: isMatch ? "#f59e0b" : statusBg(event.status),
                          color: "#fff",
                          borderRadius: 6,
                          padding: "4px 6px",
                          boxSizing: "border-box",
                          border: "none",
                          borderLeft: event.calendar_note?.startsWith("[WEB|") ? "4px solid #facc15" : "none",
                          cursor: "move",
                          zIndex: isMatch ? 10 : 2,
                          overflow: "hidden",
                          transition: "box-shadow 0.15s, opacity 0.3s",
                          display: "flex",
                          flexDirection: "column",
                          gap: 0,
                          boxShadow: isMatch ? "0 0 10px rgba(245,158,11,0.3)" : "0 1px 3px rgba(15,23,42,0.06)",
                          fontSize: 11,
                          transform: isMatch ? "scale(1.02)" : "scale(1)",
                        }}
                        onMouseEnter={(e) => { 
                          if (!isDimmed) {
                            e.currentTarget.style.boxShadow = "0 4px 16px rgba(37,99,235,0.15)"; 
                            e.currentTarget.style.transform = isMatch ? "scale(1.06)" : "scale(1.01)";
                          }
                          handleEventHover(e, event);
                        }}
                        onMouseLeave={(e) => { 
                          if (!isDimmed) {
                            e.currentTarget.style.boxShadow = isMatch ? "0 0 20px rgba(245,158,11,0.6)" : "0 2px 6px rgba(30,64,175,0.08)"; 
                            e.currentTarget.style.transform = isMatch ? "scale(1.04)" : "scale(1)";
                          }
                          handleEventHoverEnd();
                        }}
                        onClick={() => {
                          setSelectedEvent({
                            id: event.id,
                            title: event.patient_name,
                            patient_id: event.patient_id,
                            location: event.location,
                            clinic_site: event.clinic_site,
                            domicile_address: event.domicile_address,
                            treatment: event.treatment,
                            diagnosis: event.diagnosis,
                            amount: event.amount,
                            treatment_type: event.treatment_type,
                            price_type: event.price_type,
                            start: event.start,
                            end: event.end,
                          });
                          setEditStatus(event.status);
                          setEditNote(event.calendar_note || "");
                          setEditAmount(event.amount !== undefined && event.amount !== null ? event.amount.toString() : "");
                          setEditTreatmentType((event.treatment_type as "seduta" | "macchinario") || "seduta");
                          setEditPriceType((event.price_type as "invoiced" | "cash") || "invoiced");
                          
                          if (event.patient_id) {
                            loadPatientFromEvent(event.patient_id);
                          }
                        }}
                      >
                        {(() => {
                          const cardH = Math.max(height - 2, 28);
                          const isShort = cardH < 38;

                          if (isShort) return (
                            <div style={{ display: "flex", alignItems: "center", gap: 4, overflow: "hidden", height: "100%" }}>
                              <span style={{ fontSize: 10, fontWeight: 700, color: THEME.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", flex: 1 }}>
                                {event.patient_name}
                              </span>
                              {isPaid && <span style={{ fontSize: 10, flexShrink: 0 }}>🪙</span>}
                              {isDomicile && <span style={{ fontSize: 10, flexShrink: 0 }}>🏠</span>}
                            </div>
                          );

                          return (
                            <>
                              {/* Riga 1: orario + icone azione */}
                              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 2, flexShrink: 0, marginBottom: 2 }}>
                                <span style={{ fontSize: 9, fontWeight: 700, color: "rgba(255,255,255,0.85)", whiteSpace: "nowrap", lineHeight: 1 }}>
                                  {fmtTime(event.start.toISOString())}
                                  {isDomicile && " 🏠"}
                                </span>
                                <div style={{ display: "flex", gap: 3, alignItems: "center", flexShrink: 0 }}>
                                  {/* Pagato */}
                                  <button
                                    onClick={e => { e.preventDefault(); e.stopPropagation(); togglePaidQuick(event.id, isPaid); }}
                                    title={isPaid ? "Pagato — clicca per annullare" : "Segna pagato"}
                                    style={{ background: isPaid ? "rgba(255,255,255,0.25)" : "rgba(255,255,255,0.15)", border: `1px solid ${isPaid ? "rgba(255,255,255,0.7)" : "rgba(255,255,255,0.3)"}`, borderRadius: 4, cursor: "pointer", padding: "0 5px", fontSize: 13, lineHeight: "18px", display: "flex", alignItems: "center", gap: 2, height: 18 }}
                                  >🪙{isPaid && <span style={{ fontSize: 10, fontWeight: 800, color: "#fff" }}>✓</span>}</button>
                                  {/* Promemoria */}
                                  {event.status !== "cancelled" && event.patient_phone && (
                                    <button
                                      onClick={e => { e.preventDefault(); e.stopPropagation(); sendReminder(event.id, event.patient_phone ?? undefined, event.patient_first_name ?? undefined); }}
                                      title={waSent ? "Reinvia promemoria" : "Invia promemoria"}
                                      style={{ background: "none", border: "none", cursor: "pointer", padding: 0, fontSize: 13, lineHeight: 1, opacity: waSent ? 1 : 0.5 }}
                                    >{waSent ? "🔕" : "🔔"}</button>
                                  )}
                                  {/* Eseguito */}
                                  <button
                                    onClick={e => { e.preventDefault(); e.stopPropagation(); if (bulkMode) toggleBulkSelect(event.id); else toggleDoneQuick(event.id, event.status); }}
                                    title={isDone ? "Annulla eseguita" : "Segna eseguita"}
                                    style={{ width: 16, height: 16, borderRadius: 99, flexShrink: 0, border: `1.5px solid ${isDone ? "rgba(255,255,255,0.9)" : "rgba(255,255,255,0.5)"}`, background: isDone ? "rgba(255,255,255,0.9)" : "transparent", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", color: statusBg(event.status), fontSize: 9, fontWeight: 800 }}
                                  >{isDone || bulkSelected.has(event.id) ? "✓" : ""}</button>
                                </div>
                              </div>

                              {/* Riga 2: nome — subito sotto l'orario */}
                              <div style={{ fontWeight: 700, fontSize: autoNameFontSize(event.patient_name), color: "#fff", lineHeight: 1.2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                                {event.calendar_note?.startsWith("[WEB|") && <span style={{ fontSize: 8, background: "rgba(255,255,255,0.25)", borderRadius: 3, padding: "1px 3px", marginRight: 3, fontWeight: 700, verticalAlign: "middle" }}>WEB</span>}
                                {event.patient_name}
                              </div>

                              {/* Riga 3: tipo/importo + badge — in fondo */}
                              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 3, marginTop: "auto" }}>
                                <span style={{ fontSize: 9, color: "rgba(255,255,255,0.8)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                                  {event.treatment_type === "macchinario" ? "Macch." : "Seduta"}
                                  {event.amount ? ` · €${event.amount}` : ""}
                                </span>
                                <span style={{ fontSize: 9, fontWeight: 700, color: "#fff", background: "rgba(255,255,255,0.25)", padding: "1px 5px", borderRadius: 99, whiteSpace: "nowrap", flexShrink: 0 }}>
                                  {statusLabel(event.status)}
                                </span>
                              </div>
                            </>
                          );
                        })()}
                      </div>
                    );
                  })}
                  
                  {showAvailableOnly && weekDays.map((day, dayIndex) => {
                    const windows = getFreeWindows(day);
                    return windows.map((win, wi) => {
                      const { top, height } = getEventPosition(win.start, win.end);
                      const hrs = Math.floor(win.minutes / 60);
                      const mins = win.minutes % 60;
                      const label = hrs > 0 ? `${hrs}h${mins > 0 ? `${mins}′` : ""}` : `${mins}′`;
                      return (
                        <div key={`win-${dayIndex}-${wi}`}
                          style={{
                            position: "absolute",
                            left: `calc(${TIME_COL}px + ${dayIndex} * calc((100% - 80px) / 6) + 2px)`,
                            top: `${top}px`,
                            width: `calc((100% - ${TIME_COL}px) / 6 - 6px)`,
                            height: `${height}px`,
                            background: "rgba(22,163,74,0.07)",
                            borderLeft: "3px solid rgba(22,163,74,0.5)",
                            borderRadius: "0 6px 6px 0",
                            cursor: "pointer",
                            zIndex: 1,
                            display: "flex",
                            flexDirection: "column",
                            alignItems: "flex-start",
                            justifyContent: "flex-start",
                            padding: "4px 6px",
                            transition: "all 0.15s",
                            overflow: "hidden",
                          }}
                          onClick={() => handleSlotClick(day, win.start.getHours(), win.start.getMinutes())}
                          onMouseEnter={e => { e.currentTarget.style.background = "rgba(22,163,74,0.15)"; e.currentTarget.style.borderLeftColor = THEME.green; }}
                          onMouseLeave={e => { e.currentTarget.style.background = "rgba(22,163,74,0.07)"; e.currentTarget.style.borderLeftColor = "rgba(22,163,74,0.5)"; }}
                          title={`Libero ${pad2(win.start.getHours())}:${pad2(win.start.getMinutes())} – ${pad2(win.end.getHours())}:${pad2(win.end.getMinutes())} (${label})`}
                        >
                          <div style={{ fontSize: 9, fontWeight: 700, color: THEME.green, lineHeight: 1.3 }}>
                            {pad2(win.start.getHours())}:{pad2(win.start.getMinutes())}
                          </div>
                          {height >= 40 && (
                            <div style={{ fontSize: 9, fontWeight: 600, color: "rgba(22,163,74,0.7)", lineHeight: 1.3 }}>{label} libero</div>
                          )}
                        </div>
                      );
                    });
                  })}

                  <div
                    style={{
                      position: "absolute",
                      left: 0,
                      top: 0,
                      right: 0,
                      bottom: 0,
                      pointerEvents: "none",
                      zIndex: 3,
                    }}
                  >
                    {(() => {
                      const now = currentTime;
                      const currentDayIndex = weekDays.findIndex(day => 
                        now.getDate() === day.getDate() &&
                        now.getMonth() === day.getMonth() &&
                        now.getFullYear() === day.getFullYear()
                      );
                      
                      if (currentDayIndex === -1) return null;
                      
                      const currentHour = now.getHours();
                      const currentMinute = now.getMinutes();
                      const topPosition = ((currentHour - 7) * 60 + currentMinute);
                      
                      const dayWidth = `calc((100% - 80px) / 6)`;
                      const leftPosition = `calc(80px + ${currentDayIndex} * (${dayWidth}))`;
                      
                      return (
                        <div
                          style={{
                            position: "absolute",
                            left: leftPosition,
                            top: `${topPosition}px`,
                            width: `calc(${dayWidth} - 2px)`,
                            height: "2px",
                            background: THEME.red,
                            zIndex: 4,
                          }}
                        >
                          <div
                            style={{
                              position: "absolute",
                              left: "50%",
                              top: "-4px",
                              transform: "translateX(-50%)",
                              width: "8px",
                              height: "8px",
                              borderRadius: "50%",
                              background: THEME.red,
                            }}
                          />
                        </div>
                      );
                    })()}
                  </div>
                </div>
              </div>
            </div>
          ) : viewType === "month" ? (
            /* ━━━ MONTH VIEW — COMPACT ━━━ */
            <div
              style={{
                background: THEME.panelBg,
                border: `2px solid ${THEME.border}`,
                borderRadius: 12,
                overflow: "hidden",
                boxShadow: "0 2px 12px rgba(30,64,175,0.06)",
              }}
            >
              {/* Month header */}
              <div style={{
                display: "grid",
                gridTemplateColumns: "repeat(7, 1fr)",
                background: "linear-gradient(135deg, #0d9488, #2563eb)",
                borderRadius: "10px 10px 0 0",
              }}>
                {["LUN", "MAR", "MER", "GIO", "VEN", "SAB", "DOM"].map(d => (
                  <div key={d} style={{
                    padding: "8px 4px",
                    textAlign: "center",
                    fontSize: 10,
                    fontWeight: 700,
                    color: "rgba(255,255,255,0.8)",
                    letterSpacing: 1,
                  }}>{d}</div>
                ))}
              </div>

              {/* Month grid */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)" }}>
                {monthDays.map((day, idx) => {
                  const isCurrentMonth = day.getMonth() === currentDate.getMonth();
                  const isToday = day.getDate() === new Date().getDate() && day.getMonth() === new Date().getMonth() && day.getFullYear() === new Date().getFullYear();
                  const dayKey = `${day.getFullYear()}-${day.getMonth()}-${day.getDate()}`;
                  const dayEvents = monthEvents.get(dayKey) || [];
                  const isSunday = day.getDay() === 0;

                  return (
                    <div
                      key={idx}
                      onClick={() => {
                        // Single click = crea appuntamento (con delay per distinguere dal doppio click)
                        if (monthClickTimer.current) clearTimeout(monthClickTimer.current);
                        monthClickTimer.current = setTimeout(() => {
                          monthClickTimer.current = null;
                          openCreateModal(day);
                        }, 280);
                      }}
                      onDoubleClick={() => {
                        // Doppio click = vai a vista giorno
                        if (monthClickTimer.current) {
                          clearTimeout(monthClickTimer.current);
                          monthClickTimer.current = null;
                        }
                        setCurrentDate(day);
                        setViewType("day");
                      }}
                      data-month-cell="true"
                      style={{
                        minHeight: 130,
                        padding: "3px 4px",
                        borderRight: `1px solid ${THEME.borderSoft}`,
                        borderBottom: `1px solid ${THEME.borderSoft}`,
                        background: isToday ? "rgba(37,99,235,0.06)" : isSunday ? "rgba(107,114,128,0.04)" : "transparent",
                        cursor: "pointer",
                        opacity: isCurrentMonth ? 1 : 0.35,
                        transition: "background 0.15s",
                      }}
                      onMouseEnter={(e) => { if (!isToday) e.currentTarget.style.background = "rgba(37,99,235,0.04)"; }}
                      onMouseLeave={(e) => { if (!isToday) e.currentTarget.style.background = isSunday ? "rgba(107,114,128,0.04)" : "transparent"; }}
                    >
                      {/* Day number row — compact */}
                      <div style={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        marginBottom: 2,
                        lineHeight: 1,
                      }}>
                        <span style={{
                          fontSize: 11,
                          fontWeight: isToday ? 800 : 600,
                          color: isToday ? "#fff" : isSunday ? THEME.muted : THEME.text,
                          ...(isToday ? {
                            background: THEME.blue,
                            borderRadius: "50%",
                            width: 20,
                            height: 20,
                            display: "inline-flex",
                            alignItems: "center",
                            justifyContent: "center",
                          } : {}),
                        }}>
                          {day.getDate()}
                        </span>
                        {dayEvents.length > 0 && (
                          <span style={{ fontSize: 9, fontWeight: 700, color: THEME.muted }}>
                            {dayEvents.length}
                          </span>
                        )}
                      </div>

                      {/* Events list — ultra compact */}
                      <div style={{ display: "flex", flexDirection: "column", gap: 1 }}>
                        {dayEvents.slice(0, 10).map((ev, i) => {
                          const isMatch = searchMatchIds.has(ev.id);
                          const isDimmed = isSearchActive && !isMatch;
                          return (
                          <div key={i}
                            className={isMatch ? "search-highlight" : isDimmed ? "search-dimmed" : ""}
                            title={`${ev.patient_name} · ${fmtTime(ev.start.toISOString())} – ${fmtTime(ev.end.toISOString())} · ${statusLabel(ev.status)}`}
                            onClick={(e) => {
                              e.stopPropagation();
                              const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
                              setMonthPopover({
                                day,
                                events: dayEvents,
                                x: rect.right + 8,
                                y: rect.top,
                              });
                            }}
                            style={{
                              fontSize: isMatch ? 9.5 : 8.5,
                              fontWeight: isMatch ? 800 : 700,
                              color: isMatch ? "#92400e" : "#fff",
                              overflow: "hidden",
                              whiteSpace: "nowrap",
                              textOverflow: "ellipsis",
                              padding: isMatch ? "2px 4px" : "2px 4px",
                              borderRadius: 3,
                              background: isMatch ? "rgba(245,158,11,0.35)" : statusColor(ev.status),
                              lineHeight: 1.3,
                              position: "relative",
                              zIndex: isMatch ? 5 : 0,
                              cursor: "pointer",
                            }}>
                              {ev.location === "domicile" && "🏠 "}{fmtTime(ev.start.toISOString())} {ev.patient_name}
                          </div>
                          );
                        })}
                        {dayEvents.length > 10 && (
                          <span style={{ fontSize: 8, fontWeight: 700, color: THEME.muted, paddingLeft: 3 }}>+{dayEvents.length - 10}</span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
              {/* Hint */}
              <div style={{
                padding: "8px 12px",
                fontSize: 11,
                fontWeight: 600,
                color: THEME.muted,
                borderTop: `1px solid ${THEME.borderSoft}`,
                display: "flex",
                justifyContent: "center",
                gap: 16,
              }}>
                <span>Click = nuovo appuntamento</span>
                <span>•</span>
                <span>Doppio click = vista giorno</span>
              </div>
            </div>
          ) : (
            /* ━━━ DAY VIEW — timeline + sidebar ━━━ */
            <div style={{ display: "flex", gap: 0, background: THEME.panelBg, border: `2px solid ${THEME.border}`, borderRadius: 12, minHeight: 600, overflow: "clip", boxShadow: "0 2px 12px rgba(30,64,175,0.06)" }}>

              {/* ── Colonna sinistra: timeline ── */}
              <div style={{ flex: 1, minWidth: 0, position: "relative", borderRight: `2px solid ${THEME.border}` }}>
              <div style={{ 
                display: "grid", 
                gridTemplateColumns: `${TIME_COL}px 1fr`,
                borderBottom: `2px solid ${THEME.border}`,
                background: "linear-gradient(135deg, #0d9488, #2563eb)",
                borderRadius: "10px 10px 0 0",
              }}>
                <div style={{ 
                  padding: "16px 8px", 
                  borderRight: "1px solid rgba(255,255,255,0.08)",
                  fontSize: 11,
                  fontWeight: 700,
                  color: "rgba(255,255,255,0.5)",
                  textAlign: "center",
                  boxSizing: "border-box",
                  letterSpacing: 1,
                  textTransform: "uppercase",
                }}>
                  ORA
                </div>
                <div style={{ 
                  padding: "16px 8px", 
                  textAlign: "center",
                  fontSize: 13,
                  fontWeight: 700,
                  color: "#93c5fd",
                  boxSizing: "border-box",
                  letterSpacing: 0.5,
                }}>
                  {dayLabels[currentDate.getDay() === 0 ? 0 : currentDate.getDay() - 1].label} • {formatDMY(currentDate)}
                </div>
              </div>

              <div style={{ position: "relative" }}>
                {timeSlots.map((time, timeIndex) => {
                  const hour = parseInt(time.split(':')[0]);
                  
                  return (
                    <div 
                      key={timeIndex}
                      style={{ 
                        height: "60px",
                        borderBottom: `1.5px solid ${THEME.border}`,
                        position: "relative",
                        display: "flex",
                      }}
                    >
                      <div style={{ 
                        width: `${TIME_COL}px`,
                        height: "100%",
                        display: "flex",
                        alignItems: "center",
                        paddingLeft: 8,
                        borderRight: `1px solid ${THEME.border}`,
                        fontSize: 12,
                        fontWeight: 600,
                        color: THEME.muted,
                        background: THEME.panelSoft,
                        zIndex: 1,
                        flexShrink: 0,
                        boxSizing: "border-box",
                      }}>
                        {time}
                      </div>

                      <div style={{
                        flex: 1,
                        minWidth: 0,
                        height: "100%",
                        boxSizing: "border-box",
                        position: "relative",
                      }}>
                        {/* Slot 00-30 minuti */}
                        <div
                          style={{
                            height: "60px",
                            borderBottom: `1.5px solid ${THEME.border}`,
                            cursor: "pointer",
                            boxSizing: "border-box",
                            position: "relative",
                          }}
                          onClick={() => {
                            handleSlotClick(currentDate, hour, 0);
                          }}
                          onContextMenu={(e) => handleContextMenu(e)}
                          onDragOver={(e) => handleDragOver(e, 0, hour, 0)}
                          onDragLeave={handleDragLeave}
                          onDrop={(e) => {
                            handleDrop(e, currentDate, hour, 0);
                          }}
                          title={`Clicca per creare appuntamento alle ${pad2(hour)}:00`}
                        >
                          {draggingOver && draggingOver.dayIndex === 0 && 
                           draggingOver.hour === hour && draggingOver.minute === 0 && (
                            <div
                              style={{
                                position: "absolute",
                                top: 0,
                                left: 0,
                                right: 0,
                                bottom: 0,
                                border: `2px dashed ${THEME.blue}`,
                                background: "rgba(91,130,168,0.1)",
                                zIndex: 1,
                                pointerEvents: "none",
                              }}
                            />
                          )}
                        </div>
                        
                        {/* Slot 30-60 minuti */}
                        <div
                          style={{
                            height: "60px",
                            cursor: "pointer",
                            boxSizing: "border-box",
                            position: "relative",
                          }}
                          onClick={() => {
                            handleSlotClick(currentDate, hour, 30);
                          }}
                          onContextMenu={(e) => handleContextMenu(e)}
                          onDragOver={(e) => handleDragOver(e, 0, hour, 30)}
                          onDragLeave={handleDragLeave}
                          onDrop={(e) => {
                            handleDrop(e, currentDate, hour, 30);
                          }}
                          title={`Clicca per creare appuntamento alle ${pad2(hour)}:30`}
                        >
                          {draggingOver && draggingOver.dayIndex === 0 && 
                           draggingOver.hour === hour && draggingOver.minute === 30 && (
                            <div
                              style={{
                                position: "absolute",
                                top: 0,
                                left: 0,
                                right: 0,
                                bottom: 0,
                                border: `2px dashed ${THEME.blue}`,
                                background: "rgba(91,130,168,0.1)",
                                zIndex: 1,
                                pointerEvents: "none",
                              }}
                            />
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}

                {showAvailableOnly && (() => {
                  const windows = getFreeWindows(currentDate);
                  return windows.map((win, wi) => {
                    const { top, height } = getDayEventPosition(win.start, win.end);
                    const hrs = Math.floor(win.minutes / 60);
                    const mins = win.minutes % 60;
                    const label = hrs > 0 ? `${hrs}h${mins > 0 ? `${mins}′` : ""}` : `${mins}′`;
                    return (
                      <div key={`dwin-${wi}`}
                        style={{
                          position: "absolute",
                          left: `${TIME_COL + 2}px`,
                          top: `${top}px`,
                          width: `calc(100% - ${TIME_COL + 8}px)`,
                          height: `${height}px`,
                          background: "rgba(22,163,74,0.07)",
                          borderLeft: "3px solid rgba(22,163,74,0.5)",
                          borderRadius: "0 6px 6px 0",
                          cursor: "pointer",
                          zIndex: 1,
                          display: "flex",
                          alignItems: "center",
                          gap: 8,
                          padding: "0 10px",
                          transition: "all 0.15s",
                        }}
                        onClick={() => handleSlotClick(currentDate, win.start.getHours(), win.start.getMinutes())}
                        onMouseEnter={e => { e.currentTarget.style.background = "rgba(22,163,74,0.15)"; e.currentTarget.style.borderLeftColor = THEME.green; }}
                        onMouseLeave={e => { e.currentTarget.style.background = "rgba(22,163,74,0.07)"; e.currentTarget.style.borderLeftColor = "rgba(22,163,74,0.5)"; }}
                        title={`Libero ${pad2(win.start.getHours())}:${pad2(win.start.getMinutes())} – ${pad2(win.end.getHours())}:${pad2(win.end.getMinutes())}`}
                      >
                        <span style={{ fontSize: 11, fontWeight: 700, color: THEME.green }}>
                          {pad2(win.start.getHours())}:{pad2(win.start.getMinutes())} – {pad2(win.end.getHours())}:{pad2(win.end.getMinutes())}
                        </span>
                        <span style={{ fontSize: 11, fontWeight: 600, color: "rgba(22,163,74,0.7)" }}>{label} libero · clicca per prenotare</span>
                      </div>
                    );
                  });
                })()}

                {filteredEvents
                  .filter(event => 
                    event.start.getDate() === currentDate.getDate() &&
                    event.start.getMonth() === currentDate.getMonth() &&
                    event.start.getFullYear() === currentDate.getFullYear()
                  )
                  .map((event) => {
                    const { top, height } = getDayEventPosition(event.start, event.end);
                    const col = getEventColor(event);
                    const isDone    = event.status === "done";
                    const isDomicile= event.location === "domicile";
                    const isPaid    = !!event.is_paid;
                    const waSent    = !!event.whatsapp_sent_at;
                    const isMatch   = searchMatchIds.has(event.id);
                    const bgCol = isMatch ? "#f59e0b" : col;

                    return (
                      <div
                        key={event.id}
                        draggable
                        onDragStart={(e) => handleDragStart(e, event.id, event.start, event.end)}
                        onDragEnd={handleDragEnd}
                        onContextMenu={(e) => handleContextMenu(e, event)}
                        style={{
                          position: "absolute",
                          left: "82px",
                          top: `${top + 1}px`,
                          width: "calc(100% - 88px)",
                          height: `${Math.max(height - 2, 28)}px`,
                          background: statusBg(event.status),
                          color: "#fff",
                          borderRadius: 6,
                          padding: "6px 10px",
                          boxSizing: "border-box",
                          border: "none",
                          borderLeft: event.calendar_note?.startsWith("[WEB|") ? "4px solid #facc15" : "none",
                          cursor: "move",
                          zIndex: 2,
                          overflow: "hidden",
                          transition: "box-shadow 0.15s",
                          display: "flex",
                          flexDirection: "column",
                          gap: 0,
                          boxShadow: "0 1px 3px rgba(15,23,42,0.06)",
                        }}
                        onMouseEnter={(e) => { e.currentTarget.style.boxShadow = "0 3px 12px rgba(15,23,42,0.12)"; }}
                        onMouseLeave={(e) => { e.currentTarget.style.boxShadow = "0 1px 3px rgba(15,23,42,0.06)"; }}
                        onClick={() => {
                          setSelectedEvent({
                            id: event.id,
                            title: event.patient_name,
                            patient_id: event.patient_id,
                            location: event.location,
                            clinic_site: event.clinic_site,
                            domicile_address: event.domicile_address,
                            treatment: event.treatment,
                            diagnosis: event.diagnosis,
                            amount: event.amount,
                            treatment_type: event.treatment_type,
                            price_type: event.price_type,
                            start: event.start,
                            end: event.end,
                          });
                          setEditStatus(event.status);
                          setEditNote(event.calendar_note || "");
                          setEditAmount(event.amount !== undefined && event.amount !== null ? event.amount.toString() : "");
                          setEditTreatmentType((event.treatment_type as "seduta" | "macchinario") || "seduta");
                          setEditPriceType((event.price_type as "invoiced" | "cash") || "invoiced");
                          if (event.patient_id) { loadPatientFromEvent(event.patient_id); }
                        }}
                      >
                        {/* Layout due colonne: sx=bottoni, dx=testo — i bottoni non coprono mai il nome */}
                        {(() => {
                          const h = Math.max(height - 2, 20);

                          // Sotto 22px: tutto inline, niente bottoni
                          if (h < 22) {
                            return (
                              <div style={{ display:"flex", alignItems:"center", gap:4, overflow:"hidden", whiteSpace:"nowrap", width:"100%" }}>
                                <span style={{ fontSize:9, fontWeight:700, color:"rgba(255,255,255,0.9)", flexShrink:0 }}>{fmtTime(event.start.toISOString())}</span>
                                <span style={{ fontSize:10, fontWeight:800, color:"#fff", overflow:"hidden", textOverflow:"ellipsis" }}>{event.patient_name}</span>
                                {isDomicile && <span style={{ fontSize:9, flexShrink:0 }}>🏠</span>}
                              </div>
                            );
                          }

                          // 22px+: layout due colonne
                          // Bottoni fissi 12px — entrano sempre anche in 36px
                          const BS = 12;

                          return (
                            <div style={{ display:"flex", gap:4, width:"100%", height:"100%", minWidth:0 }}>

                              {/* COLONNA SINISTRA: 3 bottoni 12×12 sempre visibili */}
                              <div style={{ display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"space-evenly", width:14, flexShrink:0, borderRight:"1px solid rgba(255,255,255,0.18)" }}>
                                <button title={isPaid?"Pagato":"Segna pagato"} onClick={e=>{e.preventDefault();e.stopPropagation();togglePaidQuick(event.id,isPaid);}}
                                  style={{ width:BS, height:BS, borderRadius:3, border:`1px solid ${isPaid?"rgba(255,255,255,0.8)":"rgba(255,255,255,0.35)"}`, background:isPaid?"rgba(255,255,255,0.3)":"rgba(255,255,255,0.1)", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", fontSize:8, padding:0, flexShrink:0 }}>
                                  🪙
                                </button>
                                <button title={waSent?"Reinvia WA":"Invia WA"} onClick={e=>{e.preventDefault();e.stopPropagation();sendReminder(event.id,event.patient_phone??undefined,event.patient_first_name??undefined);}}
                                  style={{ width:BS, height:BS, background:"none", border:"none", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", fontSize:9, opacity:event.patient_phone?(waSent?1:0.55):0.2, padding:0, flexShrink:0 }}>
                                  {waSent?"🔕":"🔔"}
                                </button>
                                <button title={isDone?"Annulla":"Eseguita"} onClick={e=>{e.preventDefault();e.stopPropagation();if(bulkMode)toggleBulkSelect(event.id);else toggleDoneQuick(event.id,event.status);}}
                                  style={{ width:BS, height:BS, borderRadius:99, border:`1.5px solid ${isDone?"rgba(255,255,255,0.95)":"rgba(255,255,255,0.45)"}`, background:isDone?"rgba(255,255,255,0.9)":"transparent", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", color:statusBg(event.status), fontSize:7, fontWeight:900, padding:0, flexShrink:0 }}>
                                  {isDone||bulkSelected.has(event.id)?"✓":""}
                                </button>
                              </div>

                              {/* COLONNA DESTRA: testo */}
                              <div style={{ flex:1, minWidth:0, display:"flex", flexDirection:"column", justifyContent:"space-between", overflow:"hidden" }}>
                                {/* Orario + badge */}
                                <div style={{ display:"flex", alignItems:"center", gap:3, overflow:"hidden", flexShrink:0 }}>
                                  <span style={{ fontSize:9, fontWeight:700, color:"rgba(255,255,255,0.85)", whiteSpace:"nowrap", flexShrink:0 }}>{fmtTime(event.start.toISOString())}–{fmtTime(event.end.toISOString())}</span>
                                  {isDomicile&&<span style={{ fontSize:9, flexShrink:0 }}>🏠</span>}
                                  {event.calendar_note?.startsWith("[WEB|")&&<span style={{ fontSize:7, background:"rgba(255,255,255,0.25)", borderRadius:2, padding:"1px 3px", fontWeight:800, flexShrink:0 }}>WEB</span>}
                                  <span style={{ marginLeft:"auto", fontSize:7, fontWeight:700, color:"#fff", background:"rgba(255,255,255,0.2)", padding:"1px 4px", borderRadius:99, whiteSpace:"nowrap", flexShrink:0 }}>{statusLabel(event.status)}</span>
                                </div>
                                {/* Nome — sempre visibile e non coperto */}
                                <div style={{ fontSize:h>=55?13:h>=36?11:10, fontWeight:800, color:"#fff", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap", flex:1, lineHeight:1.25, paddingTop:1 }} title={event.patient_name}>
                                  {event.patient_name}
                                </div>
                                {/* Tipo + importo (solo se c'è spazio) */}
                                {h >= 50 && (
                                  <div style={{ fontSize:9, color:"rgba(255,255,255,0.82)", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap", flexShrink:0 }}>
                                    {getTreatmentLabel(event.treatment_type)}{event.amount?` · €${event.amount}`:""}
                                  </div>
                                )}
                              </div>
                            </div>
                          );
                        })()}
                      </div>
                    );
                  })}
                  <div
                    style={{
                      position: "absolute",
                      left: 0,
                      top: 0,
                      right: 0,
                      bottom: 0,
                      pointerEvents: "none",
                      zIndex: 3,
                    }}
                  >
                    {(() => {
                      const now = currentTime;
                      const isToday = 
                        now.getDate() === currentDate.getDate() &&
                        now.getMonth() === currentDate.getMonth() &&
                        now.getFullYear() === currentDate.getFullYear();
                      
                      if (!isToday) return null;
                      
                      const currentHour = now.getHours();
                      const currentMinute = now.getMinutes();
                      const topPosition = ((currentHour - 7) * 60 + currentMinute) * 1; // DAY_PX_PER_MIN=1
                      
                      return (
                        <div
                          style={{
                            position: "absolute",
                            left: `${TIME_COL}px`,
                            top: `${topPosition}px`,
                            width: `calc(100% - ${TIME_COL + 4}px)`,
                            height: "2px",
                            background: THEME.red,
                            zIndex: 4,
                          }}
                        >
                          <div
                            style={{
                              position: "absolute",
                              left: "50%",
                              top: "-4px",
                              transform: "translateX(-50%)",
                              width: "8px",
                              height: "8px",
                              borderRadius: "50%",
                              background: THEME.red,
                            }}
                          />
                        </div>
                      );
                    })()}
                  </div>
              </div>
              </div>

              {/* ── Colonna destra: sidebar giornaliera ── */}
              {(() => {
                const dayEvts = filteredEvents
                  .filter(ev =>
                    ev.start.getDate() === currentDate.getDate() &&
                    ev.start.getMonth() === currentDate.getMonth() &&
                    ev.start.getFullYear() === currentDate.getFullYear()
                  )
                  .filter(ev => ev.status !== "cancelled")
                  .sort((a, b) => a.start.getTime() - b.start.getTime());

                const totRev = dayEvts.reduce((s, ev) => s + (ev.amount ?? 0), 0);
                const totDone = dayEvts.filter(ev => ev.status === "done").length;
                const totPaid = dayEvts.filter(ev => ev.is_paid).length;
                const totUnpaid = dayEvts.filter(ev => !ev.is_paid && ev.status !== "cancelled").length;

                const isToday =
                  currentDate.getDate() === new Date().getDate() &&
                  currentDate.getMonth() === new Date().getMonth() &&
                  currentDate.getFullYear() === new Date().getFullYear();

                const dayLabel = (() => {
                  const g = ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"][currentDate.getDay()];
                  const mesi = ["Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"];
                  return `${g} ${currentDate.getDate()} ${mesi[currentDate.getMonth()]} ${currentDate.getFullYear()}`;
                })();

                return (
                  <div style={{ width: 280, flexShrink: 0, display: "flex", flexDirection: "column", overflow: "hidden" }}>

                    {/* Header sidebar */}
                    <div style={{ background: "linear-gradient(135deg, #0d9488, #2563eb)", padding: "14px 16px" }}>
                      <div style={{ fontSize: 13, fontWeight: 700, color: "#fff", marginBottom: 2 }}>
                        {isToday ? "Oggi" : dayLabel}
                      </div>
                      <div style={{ fontSize: 11, color: "rgba(255,255,255,0.7)", fontWeight: 600 }}>
                        {isToday ? dayLabel : ""}
                      </div>
                    </div>

                    {/* KPI strip */}
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 0, borderBottom: `1px solid ${THEME.border}` }}>
                      {[
                        { label: "Appuntamenti", val: dayEvts.length, color: THEME.blue },
                        { label: "Eseguiti", val: totDone, color: THEME.green },
                        { label: "Fatturato", val: `€${Math.round(totRev)}`, color: THEME.teal },
                        { label: "Non pagati", val: totUnpaid, color: totUnpaid > 0 ? THEME.amber : THEME.muted },
                      ].map((k, i) => (
                        <div key={i} style={{ padding: "10px 14px", borderBottom: i < 2 ? `1px solid ${THEME.border}` : "none", borderRight: i % 2 === 0 ? `1px solid ${THEME.border}` : "none" }}>
                          <div style={{ fontSize: 10, color: THEME.muted, fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.4, marginBottom: 3 }}>{k.label}</div>
                          <div style={{ fontSize: 20, fontWeight: 800, color: k.color, lineHeight: 1 }}>{k.val}</div>
                        </div>
                      ))}
                    </div>

                    {/* Bottone nuovo appuntamento */}
                    <div style={{ padding: "10px 12px", borderBottom: `1px solid ${THEME.border}` }}>
                      <button
                        onClick={() => { openCreateModal(currentDate, 9, 0); }}
                        style={{
                          width: "100%", padding: "8px 0", borderRadius: 8,
                          border: `1.5px dashed ${THEME.teal}`,
                          background: "rgba(13,148,136,0.04)", color: THEME.teal,
                          cursor: "pointer", fontWeight: 700, fontSize: 12,
                          letterSpacing: 0.3,
                        }}
                      >
                        + Nuovo appuntamento
                      </button>
                    </div>

                    {/* Lista appuntamenti */}
                    <div style={{ flex: 1, overflowY: "auto", padding: "8px 0" }}>
                      {dayEvts.length === 0 ? (
                        <div style={{ padding: "24px 16px", textAlign: "center", color: THEME.muted, fontSize: 13 }}>
                          Nessun appuntamento<br/>
                          <span style={{ fontSize: 11 }}>Clicca sulla griglia per aggiungerne uno</span>
                        </div>
                      ) : dayEvts.map((ev, idx) => {
                        const isDone = ev.status === "done";
                        const isPaid = !!ev.is_paid;
                        const waSent = !!ev.whatsapp_sent_at;
                        const isWeb = ev.calendar_note?.startsWith("[WEB|");
                        const col = getEventColor(ev);

                        return (
                          <div
                            key={ev.id}
                            onClick={() => {
                              setSelectedEvent({
                                id: ev.id,
                                title: ev.patient_name,
                                patient_id: ev.patient_id,
                                location: ev.location,
                                clinic_site: ev.clinic_site,
                                domicile_address: ev.domicile_address,
                                treatment: ev.treatment,
                                diagnosis: ev.diagnosis,
                                amount: ev.amount,
                                treatment_type: ev.treatment_type,
                                price_type: ev.price_type,
                                start: ev.start,
                                end: ev.end,
                              });
                              setEditStatus(ev.status);
                              setEditNote(ev.calendar_note || "");
                              setEditAmount(ev.amount !== undefined && ev.amount !== null ? ev.amount.toString() : "");
                              setEditTreatmentType((ev.treatment_type as "seduta" | "macchinario") || "seduta");
                              setEditPriceType((ev.price_type as "invoiced" | "cash") || "invoiced");
                              if (ev.patient_id) loadPatientFromEvent(ev.patient_id);
                            }}
                            style={{
                              margin: "4px 10px",
                              borderRadius: 8,
                              border: `1.5px solid ${statusColor(ev.status)}22`,
                              background: statusBg(ev.status) + "18",
                              borderLeft: `4px solid ${statusColor(ev.status)}`,
                              padding: "9px 10px",
                              cursor: "pointer",
                              transition: "all 0.12s",
                            }}
                            onMouseEnter={e => { e.currentTarget.style.background = statusBg(ev.status) + "30"; }}
                            onMouseLeave={e => { e.currentTarget.style.background = statusBg(ev.status) + "18"; }}
                          >
                            {/* Orario + badge */}
                            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
                              <span style={{ fontSize: 12, fontWeight: 800, color: statusColor(ev.status) }}>
                                {fmtTime(ev.start.toISOString())}
                                <span style={{ fontWeight: 500, color: THEME.muted }}> – {fmtTime(ev.end.toISOString())}</span>
                              </span>
                              <div style={{ display: "flex", gap: 4, alignItems: "center" }}>
                                {isWeb && <span style={{ fontSize: 9, fontWeight: 800, background: "#facc15", color: "#78350f", padding: "1px 5px", borderRadius: 3 }}>WEB</span>}
                                {isPaid && <span style={{ fontSize: 9, fontWeight: 800, background: "rgba(22,163,74,0.15)", color: THEME.green, padding: "1px 5px", borderRadius: 3 }}>€✓</span>}
                              </div>
                            </div>

                            {/* Nome paziente */}
                            <div style={{ fontSize: 13, fontWeight: 700, color: THEME.text, marginBottom: 3, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                              {ev.patient_name}
                            </div>

                            {/* Tipo + importo */}
                            <div style={{ fontSize: 11, color: THEME.muted, marginBottom: 6 }}>
                              {ev.treatment_type === "macchinario" ? "Macchinario" : "Seduta"}
                              {ev.location === "domicile" ? " · 🏠 Domicilio" : ""}
                              {ev.amount ? ` · €${ev.amount}` : ""}
                            </div>

                            {/* Azioni rapide */}
                            <div style={{ display: "flex", gap: 5 }}>
                              <button
                                title={isDone ? "Annulla eseguita" : "Segna eseguita"}
                                onClick={e => { e.stopPropagation(); toggleDoneQuick(ev.id, ev.status); }}
                                style={{
                                  flex: 1, padding: "4px 0", borderRadius: 5, border: "none",
                                  background: isDone ? THEME.green : "rgba(22,163,74,0.12)",
                                  color: isDone ? "#fff" : THEME.green,
                                  cursor: "pointer", fontWeight: 700, fontSize: 11,
                                }}
                              >
                                {isDone ? "✓ Eseguita" : "Esegui"}
                              </button>
                              <button
                                title={isPaid ? "Pagato" : "Segna pagato"}
                                onClick={e => { e.stopPropagation(); togglePaidQuick(ev.id, isPaid); }}
                                style={{
                                  flex: 1, padding: "4px 0", borderRadius: 5, border: "none",
                                  background: isPaid ? THEME.teal : "rgba(13,148,136,0.1)",
                                  color: isPaid ? "#fff" : THEME.teal,
                                  cursor: "pointer", fontWeight: 700, fontSize: 11,
                                }}
                              >
                                {isPaid ? "€ Pagato" : "Paga"}
                              </button>
                              {ev.patient_phone && (
                                <button
                                  title={waSent ? "Reinvia WA" : "Invia promemoria WA"}
                                  onClick={e => { e.stopPropagation(); sendReminder(ev.id, ev.patient_phone ?? undefined, ev.patient_first_name ?? undefined); }}
                                  style={{
                                    width: 30, padding: "4px 0", borderRadius: 5, border: "none",
                                    background: waSent ? "rgba(37,211,102,0.2)" : "rgba(37,211,102,0.1)",
                                    color: "#128C7E", cursor: "pointer", fontWeight: 700, fontSize: 13,
                                    flexShrink: 0,
                                  }}
                                >
                                  📲
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Footer: totali */}
                    {dayEvts.length > 0 && (
                      <div style={{ borderTop: `1px solid ${THEME.border}`, padding: "10px 14px", background: THEME.panelSoft }}>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                          <span style={{ fontSize: 11, color: THEME.muted, fontWeight: 600 }}>{totPaid}/{dayEvts.length} pagati</span>
                          <span style={{ fontSize: 14, fontWeight: 800, color: THEME.teal }}>€{Math.round(totRev).toLocaleString("it-IT")}</span>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>
          )}
        </div>
      </main>

      {createOpen && (
        <div
          className={`no-print sidebar-scroll ${showAllUpcoming ? "show-scrollbar" : ""}`}
          onClick={() => setCreateOpen(false)}
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(30,64,175,0.35)",
            zIndex: 9999,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: 16,
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              width: 780,
              maxWidth: "100%",
              maxHeight: "90vh",
              overflowY: "auto",
              background: THEME.panelBg,
              color: THEME.text,
              borderRadius: 16,
              border: `2px solid ${THEME.border}`,
              boxShadow: "0 24px 64px rgba(30,64,175,0.2)",
              padding: "32px 28px",
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "start", gap: 12, marginBottom: 24 }}>
              <div>
                <div style={{ fontSize: 22, fontWeight: 800, color: THEME.blue, letterSpacing: -0.3 }}>
                  {duplicateMode ? "Duplica appuntamento" : "Nuovo appuntamento"}
                </div>
                <div style={{ marginTop: 6, fontSize: 13, color: THEME.muted, fontWeight: 600, letterSpacing: 0.3 }}>
                  {createStartISO ? `${fmtTime(createStartISO)} → ${fmtTime(createEndISO)} • ${selectedDuration} ora${selectedDuration === "1" ? "" : "e"}` : "Seleziona orario"}
                </div>
                {overlapWarning && (
                  <div style={{
                    marginTop: 8,
                    padding: "8px 12px",
                    borderRadius: 8,
                    background: "rgba(220,38,38,0.08)",
                    border: `1px solid rgba(220,38,38,0.25)`,
                    color: THEME.red,
                    fontSize: 12,
                    fontWeight: 600,
                  }}>
                    {overlapWarning}
                  </div>
                )}
              </div>

              <button
                onClick={() => setCreateOpen(false)}
                style={{
                  width: 42,
                  height: 42,
                  borderRadius: 10,
                  border: `2px solid ${THEME.border}`,
                  background: THEME.panelSoft,
                  color: THEME.blue,
                  cursor: "pointer",
                  fontWeight: 800,
                  fontSize: 14,
                }}
              >
                ✕
              </button>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16, marginBottom: 20 }}>
              <div>
                <label style={{ fontSize: 13, fontWeight: 600, color: THEME.textSoft }}>
                  Luogo
                  <select
                    value={createLocation}
                    onChange={(e) => setCreateLocation(e.target.value as LocationType)}
                    style={{
                      width: "100%",
                      marginTop: 8,
                      padding: 10,
                      borderRadius: 8,
                      border: `1px solid ${THEME.borderSoft}`,
                      background: THEME.panelBg,
                      color: THEME.text,
                      outline: "none",
                      fontWeight: 600,
                      fontSize: 13,
                    }}
                  >
                    <option value="studio">Studio</option>
                    <option value="domicile">Domicilio</option>
                  </select>
                </label>
              </div>

              <div>
                {createLocation === "studio" ? (
                  <label style={{ fontSize: 13, fontWeight: 600, color: THEME.textSoft }}>
                    Sede
                    <input
                      value={createClinicSite}
                      onChange={(e) => setCreateClinicSite(e.target.value)}
                      placeholder="Es. Studio Pontecorvo"
                      style={{
                        width: "100%",
                        marginTop: 8,
                        padding: 10,
                        borderRadius: 8,
                        border: `1px solid ${THEME.borderSoft}`,
                        background: THEME.panelBg,
                        color: THEME.text,
                        outline: "none",
                        fontWeight: 600,
                        fontSize: 13,
                      }}
                    />
                  </label>
                ) : (
                  <label style={{ fontSize: 13, fontWeight: 600, color: THEME.textSoft }}>
                    Indirizzo domicilio
                    <input
                      value={createDomicileAddress}
                      onChange={(e) => setCreateDomicileAddress(e.target.value)}
                      placeholder="Via..., n..., città..."
                      style={{
                        width: "100%",
                        marginTop: 8,
                        padding: 10,
                        borderRadius: 8,
                        border: `1px solid ${THEME.borderSoft}`,
                        background: THEME.panelBg,
                        color: THEME.text,
                        outline: "none",
                        fontWeight: 600,
                        fontSize: 13,
                      }}
                    />
                  </label>
                )}
              </div>

              <div>
                <label style={{ fontSize: 13, fontWeight: 600, color: THEME.textSoft }}>
                  {duplicateMode ? "Nuovo giorno" : "Giorno"}
                  <input
                    type="date"
                    value={duplicateMode ? duplicateDate : toDateInputValue(new Date(createStartISO))}
                    onChange={(e) => {
                      if (duplicateMode) {
                        setDuplicateDate(e.target.value);
                        updateDuplicateDateTime(e.target.value, duplicateTime);
                      } else {
                        const date = parseDateInput(e.target.value);
                        const [hours, minutes] = selectedStartTime.split(':').map(Number);
                        date.setHours(hours, minutes, 0, 0);
                        const durationHours = parseFloat(selectedDuration);
                        const endDate = new Date(date.getTime() + durationHours * 60 * 60000);
                        setCreateStartISO(date.toISOString());
                        setCreateEndISO(endDate.toISOString());
                      }
                    }}
                    style={{
                      width: "100%",
                      marginTop: 8,
                      padding: 10,
                      borderRadius: 8,
                      border: `1px solid ${THEME.borderSoft}`,
                      background: THEME.panelBg,
                      color: THEME.text,
                      outline: "none",
                      fontWeight: 600,
                      fontSize: 13,
                    }}
                  />
                </label>
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16, marginBottom: 20 }}>
              <div>
                <label style={{ fontSize: 13, fontWeight: 600, color: THEME.textSoft }}>
                  {duplicateMode ? "Nuovo orario" : "Orario"}
                  <select
                    value={duplicateMode ? duplicateTime : selectedStartTime}
                    onChange={(e) => {
                      if (duplicateMode) {
                        setDuplicateTime(e.target.value);
                        updateDuplicateDateTime(duplicateDate, e.target.value);
                      } else {
                        setSelectedStartTime(e.target.value);
                      }
                    }}
                    style={{
                      width: "100%",
                      marginTop: 8,
                      padding: 10,
                      borderRadius: 8,
                      border: `1px solid ${THEME.borderSoft}`,
                      background: THEME.panelBg,
                      color: THEME.text,
                      outline: "none",
                      fontWeight: 600,
                      fontSize: 13,
                    }}
                  >
                    {timeSelectSlots.map((time) => (
                      <option key={time} value={time}>
                        {time}
                      </option>
                    ))}
                  </select>
                </label>
              </div>

              <div>
                <label style={{ fontSize: 13, fontWeight: 600, color: THEME.textSoft }}>
                  Durata
                  <select
                    value={selectedDuration}
                    onChange={(e) => {
                      const newDuration = e.target.value as "1" | "1.5" | "2";
                      setSelectedDuration(newDuration);
                      if (duplicateMode && duplicateDate && duplicateTime) {
                        updateDuplicateDateTime(duplicateDate, duplicateTime);
                      }
                    }}
                    style={{
                      width: "100%",
                      marginTop: 8,
                      padding: 10,
                      borderRadius: 8,
                      border: `1px solid ${THEME.borderSoft}`,
                      background: THEME.panelBg,
                      color: THEME.text,
                      outline: "none",
                      fontWeight: 600,
                      fontSize: 13,
                    }}
                  >
                    <option value="1">1 ora</option>
                    <option value="1.5">1.5 ore</option>
                    <option value="2">2 ore</option>
                  </select>
                </label>
              </div>

              <div></div>
            </div>

            <div style={{ marginBottom: 20, border: `1.5px solid ${THEME.border}`, padding: 16, borderRadius: 8, background: THEME.panelSoft }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: THEME.textSoft, marginBottom: 12 }}>
                Tipologia e Prezzo
              </div>
              
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
                <div>
                  <div style={{ fontSize: 12, fontWeight: 600, color: THEME.muted, marginBottom: 8 }}>
                    Trattamento
                  </div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                    {ALL_TREATMENTS.map(t => (
                      <button key={t.value} onClick={() => setTreatmentType(t.value as TreatmentType)}
                        style={{
                          padding: "7px 12px", borderRadius: 7, cursor: "pointer", fontWeight: 700,
                          fontSize: 13, border: `2px solid ${treatmentType === t.value ? t.color : THEME.borderSoft}`,
                          background: treatmentType === t.value ? t.color : "#fff",
                          color: treatmentType === t.value ? "#fff" : THEME.text,
                          transition: "all 0.15s",
                        }}>
                        {t.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <div style={{ fontSize: 12, fontWeight: 600, color: THEME.muted, marginBottom: 8 }}>
                    Prezzo
                  </div>
                  <div style={{ display: "flex", gap: 8 }}>
                    <button
                      onClick={() => setPriceType("invoiced")}
                      style={{
                        flex: 1,
                        padding: "12px",
                        borderRadius: 8,
                        border: `1px solid ${priceType === "invoiced" ? THEME.greenDark : THEME.borderSoft}`,
                        background: priceType === "invoiced" ? THEME.green : "#fff",
                        color: priceType === "invoiced" ? "#fff" : THEME.text,
                        cursor: "pointer",
                        fontWeight: 600,
                        fontSize: 13,
                      }}
                    >
                      {`€ ${Number(getDefaultAmount(treatmentType, "invoiced") ?? 0).toFixed(2)} fatturato`}
                    </button>
                    <button
                      onClick={() => setPriceType("cash")}
                      style={{
                        flex: 1,
                        padding: "12px",
                        borderRadius: 8,
                        border: `1px solid ${priceType === "cash" ? THEME.amber : THEME.borderSoft}`,
                        background: priceType === "cash" ? "rgba(245,158,11,0.1)" : "#fff",
                        color: priceType === "cash" ? THEME.amber : THEME.text,
                        cursor: "pointer",
                        fontWeight: 600,
                        fontSize: 13,
                      }}
                    >
                      {`€ ${Number(getDefaultAmount(treatmentType, "cash") ?? 0).toFixed(2)} contanti`}
                    </button>
                  </div>
                </div>
              </div>

              <div style={{ borderTop: `1px solid ${THEME.border}`, paddingTop: 16 }}>
                <label style={{ display: "flex", alignItems: "center", gap: 12, fontWeight: 600, color: THEME.text, fontSize: 14, marginBottom: 12 }}>
                  <input
                    type="checkbox"
                    checked={useCustomPrice}
                    onChange={(e) => {
                      setUseCustomPrice(e.target.checked);
                      if (!e.target.checked) {
                        setCustomAmount("");
                      }
                    }}
                    style={{ width: 18, height: 18 }}
                  />
                  Imposta prezzo personalizzato
                

                </label>

                {useCustomPrice && (
                  <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                    <div style={{ fontSize: 13, fontWeight: 600, color: THEME.text }}>€</div>
                    <input
  value={customAmount}
  onChange={(e) => {
    const value = e.target.value;
    setCustomAmount(value);
  }}
  placeholder="Importo personalizzato (0 per gratis)"
  style={{
    flex: 1,
    padding: "8px 10px",
    borderRadius: 8,
    border: `1px solid ${THEME.blue}`,
    background: THEME.panelBg,
    color: THEME.text,
    outline: "none",
    fontWeight: 600,
    fontSize: 13,
  }}
/>
                    <div style={{ fontSize: 12, color: THEME.muted, fontWeight: 600 }}>
                      Inserisci l'importo in euro (0 per terapia gratuita)
                    </div>
                  </div>
                )}
              </div>

              <div style={{ marginTop: 12, fontSize: 13, color: THEME.muted, fontWeight: 600, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span>Totale:</span>
                <strong style={{ color: THEME.text, fontSize: 16 }}>
                  {useCustomPrice && customAmount !== "" ? 
                    `€ ${parseFloat(customAmount.replace(',', '.')).toFixed(2)}` :
                    `€ ${Number(computedDefaultAmount ?? 0).toFixed(2)}`
                  }
                </strong>
              </div>
            </div>

            <div style={{ marginBottom: 20, border: `1.5px solid ${THEME.border}`, background: THEME.panelSoft, padding: 16, borderRadius: 8 }}>
              <label style={{ display: "flex", alignItems: "center", gap: 12, fontWeight: 600, color: THEME.text, fontSize: 14 }}>
                <input
                  type="checkbox"
                  checked={isRecurring}
                  onChange={(e) => setIsRecurring(e.target.checked)}
                  style={{ width: 18, height: 18 }}
                />
                Appuntamento ricorrente
              </label>

              {isRecurring && (
                <div style={{ marginTop: 16, display: "grid", gridTemplateColumns: "1.2fr 1fr", gap: 16 }}>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 600, color: THEME.muted }}>Giorni</div>
                    <div style={{ marginTop: 12, display: "flex", gap: 8, flexWrap: "wrap" }}>
                      {dayLabels.map((d) => {
                        const active = recurringDays.includes(d.dow);
                        return (
                          <button
                            key={d.dow}
                            onClick={() => toggleRecurringDay(d.dow)}
                            style={{
                              padding: "8px 10px",
                              borderRadius: 8,
                              border: `1px solid ${active ? THEME.blueDark : THEME.borderSoft}`,
                              background: active ? THEME.blue : "#fff",
                              color: active ? "#fff" : THEME.text,
                              cursor: "pointer",
                              fontWeight: 600,
                              fontSize: 12,
                            }}
                            title="Seleziona/deseleziona"
                          >
                            {d.label}
                          </button>
                        );
                      })}
                    </div>

                    {/* Frequency selector */}
                    <div style={{ marginTop: 12 }}>
                      <div style={{ fontSize: 12, fontWeight: 600, color: THEME.muted, marginBottom: 6 }}>Frequenza</div>
                      <div style={{ display: "flex", gap: 6 }}>
                        {([1, 2, 3, 4] as const).map(freq => (
                          <button
                            key={freq}
                            onClick={() => setRecurringFrequency(freq)}
                            style={{
                              padding: "6px 12px",
                              borderRadius: 6,
                              border: `1px solid ${recurringFrequency === freq ? THEME.blueDark : THEME.borderSoft}`,
                              background: recurringFrequency === freq ? THEME.blue : "#fff",
                              color: recurringFrequency === freq ? "#fff" : THEME.text,
                              cursor: "pointer",
                              fontWeight: 600,
                              fontSize: 11,
                            }}
                          >
                            {freq === 1 ? "Ogni sett." : `Ogni ${freq} sett.`}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Preview count */}
                    {(() => {
                      try {
                        const previewStarts = generateRecurringStarts({
                          firstStart: new Date(createStartISO),
                          untilDate: parseDateInput(recurringUntil),
                          weekDays: recurringDays,
                          frequency: recurringFrequency,
                        });
                        return (
                          <div style={{ marginTop: 10, fontSize: 12, color: THEME.blue, fontWeight: 700, background: "rgba(37,99,235,0.06)", padding: "6px 10px", borderRadius: 6 }}>
                            📅 Verranno creati {previewStarts.length} appuntamenti
                          </div>
                        );
                      } catch {
                        return null;
                      }
                    })()}
                  </div>

                  <div>
                    <label style={{ fontSize: 13, fontWeight: 600, color: THEME.muted }}>
                      Ripeti fino a
                      <input
                        type="date"
                        value={recurringUntil}
                        onChange={(e) => setRecurringUntil(e.target.value)}
                        style={{
                          width: "100%",
                          marginTop: 8,
                          padding: 10,
                          borderRadius: 8,
                          border: `1px solid ${THEME.borderSoft}`,
                          background: THEME.panelBg,
                          color: THEME.text,
                          outline: "none",
                          fontWeight: 600,
                          fontSize: 13,
                        }}
                      />
                    </label>

                    <div style={{ marginTop: 12, fontSize: 12, color: THEME.muted, fontWeight: 600 }}>
                      Limite sicurezza: max 200 appuntamenti per inserimento.
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div style={{ marginBottom: 20 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: THEME.textSoft }}>
                  {duplicateMode ? "Paziente" : "Seleziona paziente"}
                </div>
                {!duplicateMode && (
                <button
                  onClick={() => setQuickPatientOpen(true)}
                  style={{
                    padding: "8px 16px",
                    borderRadius: 8,
                    border: `1px solid ${THEME.greenDark}`,
                    background: THEME.green,
                    color: "#fff",
                    cursor: "pointer",
                    fontWeight: 600,
                    fontSize: 12,
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                  }}
                >
                  <span style={{ fontSize: 14 }}>➕</span>
                  Nuovo Paziente Rapido
                </button>
                )}
              </div>

              {duplicateMode && selectedPatient ? (
                /* In modalità duplica: mostra solo la pill del paziente, nessuna ricerca */
                <div style={{
                  display: "flex", alignItems: "center", gap: 10,
                  padding: "10px 14px", borderRadius: 8,
                  background: "rgba(37,99,235,0.07)",
                  border: `1.5px solid ${THEME.blue}`,
                }}>
                  <div style={{ width: 32, height: 32, borderRadius: "50%", background: THEME.blue,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    color: "#fff", fontWeight: 800, fontSize: 13, flexShrink: 0 }}>
                    {((selectedPatient.last_name?.[0] ?? "") + (selectedPatient.first_name?.[0] ?? "")).toUpperCase() || "?"}
                  </div>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 14, color: THEME.text }}>
                      {selectedPatient.last_name} {selectedPatient.first_name}
                    </div>
                    <div style={{ fontSize: 11, color: THEME.muted, marginTop: 1 }}>Paziente copiato dall'appuntamento originale</div>
                  </div>
                </div>
              ) : (
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Cerca per nome o cognome (min 2 lettere)..."
                style={{
                  width: "100%",
                  padding: 10,
                  borderRadius: 8,
                  border: `1px solid ${THEME.borderSoft}`,
                  background: THEME.panelBg,
                  color: THEME.text,
                  outline: "none",
                  fontWeight: 600,
                  fontSize: 13,
                }}
              />
              )}
            </div>

            {quickPatientOpen && (
              <div style={{ 
                border: `1px solid ${THEME.blue}`, 
                background: "rgba(91,130,168,0.03)", 
                padding: 16, 
                borderRadius: 8,
                marginBottom: 16 
              }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: THEME.blueDark, marginBottom: 12 }}>
                  Inserisci dati paziente rapido
                </div>
                
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 12 }}>
                  <input
                    value={quickPatientFirstName}
                    onChange={(e) => setQuickPatientFirstName(e.target.value)}
                    placeholder="Nome *"
                    style={{
                      padding: "8px 10px",
                      borderRadius: 8,
                      border: `1px solid ${THEME.borderSoft}`,
                      background: THEME.panelBg,
                      color: THEME.text,
                      outline: "none",
                      fontWeight: 600,
                      fontSize: 13,
                    }}
                  />
                  <input
                    value={quickPatientLastName}
                    onChange={(e) => setQuickPatientLastName(e.target.value)}
                    placeholder="Cognome *"
                    style={{
                      padding: "8px 10px",
                      borderRadius: 8,
                      border: `1px solid ${THEME.borderSoft}`,
                      background: THEME.panelBg,
                      color: THEME.text,
                      outline: "none",
                      fontWeight: 600,
                      fontSize: 13,
                    }}
                  />
                  <input
                    value={quickPatientPhone}
                    onChange={(e) => setQuickPatientPhone(e.target.value)}
                    placeholder="Telefono (opzionale)"
                    style={{
                      padding: "8px 10px",
                      borderRadius: 8,
                      border: `1px solid ${THEME.borderSoft}`,
                      background: THEME.panelBg,
                      color: THEME.text,
                      outline: "none",
                      fontWeight: 600,
                      fontSize: 13,
                    }}
                  />
                </div>
                
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div style={{ fontSize: 12, color: THEME.muted, fontWeight: 600 }}>
                    Stato: <strong style={{ color: THEME.amber }}>DA COMPLETARE</strong>
                  </div>
                  
                  <div style={{ display: "flex", gap: 8 }}>
                    <button
                      onClick={() => setQuickPatientOpen(false)}
                      style={{
                        padding: "8px 16px",
                        borderRadius: 8,
                        border: `1px solid ${THEME.borderSoft}`,
                        background: THEME.panelSoft,
                        color: THEME.text,
                        cursor: "pointer",
                        fontWeight: 600,
                        fontSize: 12,
                      }}
                    >
                      Annulla
                    </button>
                    <button
                      onClick={createQuickPatient}
                      disabled={creatingQuickPatient || !quickPatientFirstName.trim() || !quickPatientLastName.trim()}
                      style={{
                        padding: "8px 16px",
                        borderRadius: 8,
                        border: `1px solid ${THEME.greenDark}`,
                        background: THEME.green,
                        color: "#fff",
                        cursor: creatingQuickPatient ? "not-allowed" : "pointer",
                        fontWeight: 600,
                        fontSize: 12,
                        opacity: creatingQuickPatient || !quickPatientFirstName.trim() || !quickPatientLastName.trim() ? 0.6 : 1,
                      }}
                    >
                      {creatingQuickPatient ? "Creazione..." : "Crea Paziente"}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {!duplicateMode && (
            <div style={{ border: `1.5px solid ${THEME.border}`, background: THEME.panelBg, borderRadius: 8, overflow: "hidden" }}>
              <div style={{ padding: 10, fontSize: 13, color: THEME.muted, fontWeight: 600, background: THEME.panelSoft }}>
                {searching ? "Ricerca in corso..." : `Risultati: ${patientResults.length}`}
              </div>

              <div style={{ maxHeight: 240, overflowY: "auto" }}>
                {patientResults.length === 0 && !quickPatientOpen && (
                  <div style={{ padding: 20, fontSize: 13, color: THEME.muted, fontWeight: 600, textAlign: "center" }}>
                    {q.trim().length < 2 ? "Scrivi almeno 2 lettere per iniziare la ricerca" : "Nessun risultato trovato"}
                  </div>
                )}

                {patientResults.map((p) => {
                  const active = selectedPatient?.id === p.id;
                  return (
                    <button
                      key={p.id}
                      onClick={() => {
                        setSelectedPatient(p);
                        if (!duplicateMode) {
                          loadLastPatientSettings(p.id);
                        }
                      }}
                      style={{
                        width: "100%",
                        textAlign: "left",
                        padding: 16,
                        border: "none",
                        borderTop: `1px solid ${THEME.border}`,
                        background: active ? "rgba(37,99,235,0.08)" : "#fff",
                        cursor: "pointer",
                        display: "flex",
                        justifyContent: "space-between",
                        gap: 12,
                        fontWeight: 600,
                        color: THEME.text,
                        fontSize: 13,
                      }}
                    >
                      <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-start" }}>
                        <span style={{ fontSize: 14 }}>
                          {p.last_name} {p.first_name}
                        </span>
                        {p.treatment && (
                          <span style={{ fontSize: 12, color: THEME.muted, marginTop: 4, fontWeight: 600 }}>
                            Trattamento: {p.treatment}
                          </span>
                        )}
                      </div>
                      <span style={{ fontSize: 12, color: THEME.muted, fontWeight: 600 }}>{p.phone ?? ""}</span>
                    </button>
                  );
                })}
              </div>
            </div>
            )}

            <div style={{ marginTop: 16, fontSize: 13, color: THEME.muted, fontWeight: 600 }}>
              Selezionato:{" "}
              <strong style={{ color: THEME.text }}>
                {selectedPatient ? `${selectedPatient.last_name} ${selectedPatient.first_name}` : "-"}
              </strong>
              {selectedPatient && selectedPatient.treatment && (
                <span style={{ marginLeft: 16 }}>
                  • Trattamento: <strong style={{ color: THEME.text }}>{selectedPatient.treatment}</strong>
                </span>
              )}
              {selectedPatient && !duplicateMode && (
                <span style={{ marginLeft: 8, fontSize: 11, color: THEME.green }}>
                  ✓ Impostazioni ultimo appuntamento applicate
                </span>
              )}
            </div>

            <div style={{ display: "flex", justifyContent: "flex-end", gap: 12, marginTop: 28 }}>
              <button
                onClick={() => setCreateOpen(false)}
                style={{
                  padding: "12px 22px",
                  borderRadius: 10,
                  border: `2px solid ${THEME.border}`,
                  background: THEME.panelSoft,
                  color: THEME.text,
                  cursor: "pointer",
                  fontWeight: 700,
                  minWidth: 120,
                  fontSize: 13,
                  letterSpacing: 0.3,
                }}
              >
                Annulla
              </button>

              <button
                onClick={() => setShowWhatsAppConfirm(true)}
                disabled={creating || !selectedPatient}
                style={{
                  padding: "12px 22px",
                  borderRadius: 10,
                  border: "none",
                  background: creating || !selectedPatient ? THEME.gray : "linear-gradient(135deg, #0d9488, #2563eb)",
                  color: "#fff",
                  cursor: creating || !selectedPatient ? "not-allowed" : "pointer",
                  fontWeight: 700,
                  minWidth: 200,
                  opacity: creating || !selectedPatient ? 0.6 : 1,
                  fontSize: 13,
                  letterSpacing: 0.3,
                  boxShadow: creating || !selectedPatient ? "none" : "0 4px 16px rgba(37,99,235,0.3)",
                }}
              >
                {creating ? "Creazione..." : isRecurring ? "Crea ricorrenza" : "Crea appuntamento"}
              </button>
            </div>
          </div>
        </div>
      )}


        {showWhatsAppConfirm && (
        <>
          <div
            className={`no-print sidebar-scroll ${showAllUpcoming ? "show-scrollbar" : ""}`}
            onClick={() => setShowWhatsAppConfirm(false)}
            style={{
              position: "fixed",
              inset: 0,
              background: "rgba(30,64,175,0.35)",
              zIndex: 10000,
            }}
          />
          
          <div
            style={{
              position: "fixed",
              top: "50%",
              left: "50%",
              transform: "translate(-50%, -50%)",
              width: 480,
              maxWidth: "90%",
              background: THEME.panelBg,
              color: THEME.text,
              borderRadius: 16,
              border: `2px solid ${THEME.border}`,
              boxShadow: "0 24px 64px rgba(30,64,175,0.2)",
              padding: "32px 28px",
              zIndex: 10001,
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 24 }}>
              <div style={{ width: 44, height: 44, borderRadius: 12, background: "linear-gradient(135deg, #0d9488, #2563eb)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, color: "#fff" }}>◈</div>
              <div>
                <div style={{ fontSize: 18, fontWeight: 800, color: THEME.blue }}>
                  {selectedPatient?.phone ? "Invia conferma WhatsApp?" : "Nessun numero di telefono"}
                </div>
                <div style={{ marginTop: 4, fontSize: 13, color: THEME.muted, fontWeight: 600 }}>
                  {selectedPatient?.phone 
                    ? "Vuoi inviare il messaggio di conferma al paziente?"
                    : "Il paziente non ha un numero di telefono registrato. Vuoi comunque creare l'appuntamento?"}
                </div>
              </div>
            </div>

            {selectedPatient?.phone && (
              <div style={{ marginBottom: 24 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: THEME.text, marginBottom: 8 }}>
                  Messaggio che verrà inviato:
                </div>
                <div style={{
                  background: THEME.panelSoft,
                  padding: 16,
                  borderRadius: 8,
                  border: `1.5px solid ${THEME.border}`,
                  fontSize: 12,
                  lineHeight: 1.5,
                  whiteSpace: "pre-wrap",
                  maxHeight: 150,
                  overflowY: "auto",
                }}>
                  Grazie per averci scelto.
                  Ricordiamo il prossimo appuntamento fissato per {formatDateRelative(new Date(createStartISO))} alle {fmtTime(createStartISO)}.

                  A presto,
                  Dr. Marco Turchetta
                  Fisioterapia e Osteopatia
                </div>
                <div style={{ marginTop: 8, fontSize: 12, color: THEME.muted, fontWeight: 600 }}>
                  Destinatario: {selectedPatient?.phone}
                </div>
              </div>
            )}

            {!selectedPatient?.phone && (
              <div style={{ marginBottom: 24 }}>
                <div style={{
                  background: "rgba(245, 158, 11, 0.1)",
                  border: `1px solid ${THEME.amber}`,
                  padding: 16,
                  borderRadius: 8,
                  fontSize: 12,
                  lineHeight: 1.5,
                  color: THEME.amber,
                  fontWeight: 600,
                }}>
                  ⚠️ Attenzione: Il paziente {selectedPatient?.last_name} {selectedPatient?.first_name} non ha un numero di telefono registrato.
                  <br /><br />
                  Puoi comunque creare l'appuntamento e successivamente aggiungere il numero di telefono nella scheda paziente.
                </div>
              </div>
            )}

            <div style={{ display: "flex", justifyContent: "flex-end", gap: 12 }}>
              <button
                onClick={async () => {
                  setShowWhatsAppConfirm(false);
                  await createAppointment(false);
                }}
                style={{
                  padding: "12px 20px",
                  borderRadius: 8,
                  border: `1px solid ${THEME.borderSoft}`,
                  background: THEME.panelSoft,
                  color: THEME.text,
                  cursor: "pointer",
                  fontWeight: 600,
                  minWidth: 120,
                  fontSize: 13,
                }}
              >
                {selectedPatient?.phone ? "Salta" : "Crea senza WhatsApp"}
              </button>
              
              {selectedPatient?.phone && (
                <button
                  onClick={async () => {
                    setShowWhatsAppConfirm(false);
                    await createAppointment(true);
                  }}
                  style={{
                    padding: "12px 20px",
                    borderRadius: 8,
                    border: `1px solid ${THEME.greenDark}`,
                    background: "#25d366",
                    color: "#fff",
                    cursor: "pointer",
                    fontWeight: 600,
                    minWidth: 200,
                    fontSize: 13,
                    display: "flex",
                    alignItems: "center",
                    gap: 8,
                  }}
                >
                  <span>📱</span>
                  Crea e invia WhatsApp
                </button>
              )}
            </div>
          </div>
        </>
      )}

      {selectedEvent && (
        <div
          className={`no-print sidebar-scroll ${showAllUpcoming ? "show-scrollbar" : ""}`}
          onClick={() => setSelectedEvent(null)}
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(30,64,175,0.35)",
            zIndex: 9999,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: 16,
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              width: 680,
              maxWidth: "100%",
              maxHeight: "90vh",
              overflowY: "auto",
              background: THEME.panelBg,
              color: THEME.text,
              borderRadius: 16,
              border: `2px solid ${THEME.border}`,
              boxShadow: "0 24px 64px rgba(30,64,175,0.2)",
              padding: "32px 28px",
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "start", gap: 12, marginBottom: 24 }}>
              <div>
                <div style={{ fontSize: 22, fontWeight: 800, color: THEME.blue, letterSpacing: -0.3 }}>{selectedEvent.title}</div>
                <div style={{ marginTop: 6, fontSize: 13, color: THEME.muted, fontWeight: 600, letterSpacing: 0.3 }}>
                  Stato: <strong style={{ color: statusColor(editStatus) }}>{statusLabel(editStatus)}</strong>
                  {selectedEvent.location === "domicile" && (
                    <span style={{ marginLeft: 12, color: THEME.amber, fontWeight: 700 }}>⌂ DOMICILIO</span>
                  )}
                </div>
              </div>

              <button
                onClick={() => setSelectedEvent(null)}
                style={{
                  width: 42,
                  height: 42,
                  borderRadius: 10,
                  border: `2px solid ${THEME.border}`,
                  background: THEME.panelSoft,
                  color: THEME.blue,
                  cursor: "pointer",
                  fontWeight: 800,
                  fontSize: 14,
                }}
              >
                ✕
              </button>
            </div>

            <div style={{ display: "flex", gap: 12, marginBottom: 20 }}>
              <button
                onClick={() => {
                  const event = events.find(e => e.id === selectedEvent.id);
                  if (event) {
                    openCreateModal(event.start, event.start.getHours(), event.start.getMinutes(), event);
                    setSelectedEvent(null);
                  }
                }}
                style={{
                  padding: "10px 18px",
                  borderRadius: 8,
                  border: "none",
                  background: "linear-gradient(135deg, #0d9488, #2563eb)",
                  color: "#fff",
                  cursor: "pointer",
                  fontWeight: 700,
                  fontSize: 13,
                  display: "flex",
                  alignItems: "center",
                  gap: 6,
                  boxShadow: "0 2px 8px rgba(91,130,168,0.25)",
                  letterSpacing: 0.3,
                }}
              >
                <span>◫</span>
                Duplica
              </button>
            </div>

            <div style={{ marginBottom: 20, border: `1.5px solid ${THEME.border}`, padding: 16, borderRadius: 8, background: THEME.panelSoft }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: THEME.textSoft, marginBottom: 12 }}>
                Modifica Data e Orario
              </div>
              
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16, marginBottom: 16 }}>
                <div>
                  <label style={{ fontSize: 12, fontWeight: 600, color: THEME.muted, marginBottom: 8 }}>
                    Data
                  </label>
                  <input
                    type="date"
                    value={editDate}
                    onChange={(e) => setEditDate(e.target.value)}
                    style={{
                      width: "100%",
                      padding: "8px 10px",
                      borderRadius: 8,
                      border: `1px solid ${THEME.borderSoft}`,
                      background: THEME.panelBg,
                      color: THEME.text,
                      outline: "none",
                      fontWeight: 600,
                      fontSize: 13,
                    }}
                  />
                </div>
                
                <div>
                  <label style={{ fontSize: 12, fontWeight: 600, color: THEME.muted, marginBottom: 8 }}>
                    Orario Inizio
                  </label>
                  <select
                    value={editStartTime}
                    onChange={(e) => setEditStartTime(e.target.value)}
                    style={{
                      width: "100%",
                      padding: "8px 10px",
                      borderRadius: 8,
                      border: `1px solid ${THEME.borderSoft}`,
                      background: THEME.panelBg,
                      color: THEME.text,
                      outline: "none",
                      fontWeight: 600,
                      fontSize: 13,
                    }}
                  >
                    {timeSelectSlots.map((time) => (
                      <option key={time} value={time}>
                        {time}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label style={{ fontSize: 12, fontWeight: 600, color: THEME.muted, marginBottom: 8 }}>
                    Durata
                  </label>
                  <select
                    value={editDuration}
                    onChange={(e) => setEditDuration(e.target.value as "1" | "1.5" | "2")}
                    style={{
                      width: "100%",
                      padding: "8px 10px",
                      borderRadius: 8,
                      border: `1px solid ${THEME.borderSoft}`,
                      background: THEME.panelBg,
                      color: THEME.text,
                      outline: "none",
                      fontWeight: 600,
                      fontSize: 13,
                    }}
                  >
                    <option value="1">1 ora</option>
                    <option value="1.5">1.5 ore</option>
                    <option value="2">2 ore</option>
                  </select>
                </div>
              </div>
              
              <div style={{ fontSize: 12, color: THEME.muted, fontWeight: 600, marginTop: 8 }}>
                Nuovo orario: {editDate && editStartTime ? 
                  `${editDate.split('-').reverse().join('/')} alle ${editStartTime}` : 
                  "Seleziona data e orario"}
              </div>
            </div>

            <div style={{ marginBottom: 20, border: `1.5px solid ${THEME.border}`, padding: 16, borderRadius: 8, background: THEME.panelSoft }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: THEME.textSoft, marginBottom: 12 }}>
                Trattamento e Prezzo
              </div>
              
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
                <div>
                  <div style={{ fontSize: 12, fontWeight: 600, color: THEME.muted, marginBottom: 8 }}>
                    Trattamento
                  </div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                    {ALL_TREATMENTS.map(t => (
                      <button key={t.value} onClick={() => setEditTreatmentType(t.value as TreatmentType)}
                        style={{
                          padding: "7px 12px", borderRadius: 7, cursor: "pointer", fontWeight: 700,
                          fontSize: 12, border: `2px solid ${editTreatmentType === t.value ? t.color : THEME.borderSoft}`,
                          background: editTreatmentType === t.value ? t.color : "#fff",
                          color: editTreatmentType === t.value ? "#fff" : THEME.text,
                          transition: "all 0.15s",
                        }}>
                        {t.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <div style={{ fontSize: 12, fontWeight: 600, color: THEME.muted, marginBottom: 8 }}>
                    Fatturazione
                  </div>
                  <div style={{ display: "flex", gap: 8 }}>
                    <button
                      onClick={() => setEditPriceType("invoiced")}
                      style={{
                        flex: 1,
                        padding: "8px 10px",
                        borderRadius: 8,
                        border: `1px solid ${editPriceType === "invoiced" ? THEME.greenDark : THEME.borderSoft}`,
                        background: editPriceType === "invoiced" ? THEME.green : "#fff",
                        color: editPriceType === "invoiced" ? "#fff" : THEME.text,
                        cursor: "pointer",
                        fontWeight: 600,
                        fontSize: 12,
                      }}
                    >
                      Fatturato
                    </button>
                    <button
                      onClick={() => setEditPriceType("cash")}
                      style={{
                        flex: 1,
                        padding: "8px 10px",
                        borderRadius: 8,
                        border: `1px solid ${editPriceType === "cash" ? THEME.amber : THEME.borderSoft}`,
                        background: editPriceType === "cash" ? "rgba(245,158,11,0.1)" : "#fff",
                        color: editPriceType === "cash" ? THEME.amber : THEME.text,
                        cursor: "pointer",
                        fontWeight: 600,
                        fontSize: 12,
                      }}
                    >
                      Contanti
                    </button>
                  </div>
                </div>
              </div>

              <div>
                <div style={{ fontSize: 12, fontWeight: 600, color: THEME.muted, marginBottom: 8 }}>
                  Importo (€)
                </div>
                <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                  <input
                    value={editAmount}
                    onChange={(e) => {
                      const value = e.target.value.replace(/[^0-9.,]/g, '');
                      setEditAmount(value);
                    }}
                    placeholder="Importo personalizzato(lasciare vuoto per prezzo standard)"
                    style={{
                      flex: 1,
                      padding: "8px 10px",
                      borderRadius: 8,
                      border: `1px solid ${THEME.blue}`,
                      background: THEME.panelBg,
                      color: THEME.text,
                      outline: "none",
                      fontWeight: 600,
                      fontSize: 13,
                    }}
                  />
                  <button
                    onClick={() => {
                      const tType = editTreatmentType as "seduta" | "macchinario";
                      const pType = editPriceType as "invoiced" | "cash";
                      setEditAmount(getDefaultAmount(tType, pType).toString());
                    }}
                    style={{
                      padding: "10px 16px",
                      borderRadius: 8,
                      border: `1px solid ${THEME.borderSoft}`,
                      background: THEME.panelSoft,
                      color: THEME.text,
                      cursor: "pointer",
                      fontWeight: 600,
                      fontSize: 12,
                      whiteSpace: "nowrap",
                    }}
                  >
                    Usa standard
                  </button>
                </div>
                <div style={{ marginTop: 8, fontSize: 11, color: THEME.muted, fontWeight: 600 }}>
                  {editAmount ? `Totale: € ${parseFloat(editAmount.replace(',', '.')).toFixed(2)}` : 
                   `Prezzo standard: € ${getDefaultAmount(editTreatmentType as "seduta" | "macchinario", editPriceType as "invoiced" | "cash").toFixed(2)}`}
                </div>
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 12 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: THEME.muted }}>Colore personalizzato:</div>
                <input
                  type="color"
                  value={eventColors[selectedEvent?.patient_id || ""] || getEventColor(events.find(e => e.id === selectedEvent?.id) || { status: "booked" })}
                  onChange={(e) => {
                    if (selectedEvent?.patient_id) {
                      setEventColors(prev => ({
                        ...prev,
                        [selectedEvent.patient_id!]: e.target.value
                      }));
                    }
                  }}
                  style={{
                    width: 30,
                    height: 30,
                    borderRadius: 6,
                    border: `1.5px solid ${THEME.border}`,
                    cursor: "pointer",
                  }}
                />
                <button
                  onClick={() => {
                    if (selectedEvent?.patient_id) {
                      setEventColors(prev => {
                        const newColors = { ...prev };
                        delete newColors[selectedEvent.patient_id!];
                        return newColors;
                      });
                    }
                  }}
                  style={{
                    padding: "4px 8px",
                    borderRadius: 6,
                    border: `1px solid ${THEME.borderSoft}`,
                    background: THEME.panelSoft,
                    color: THEME.text,
                    fontSize: 11,
                    fontWeight: 600,
                    cursor: "pointer",
                  }}
                >
                  Reset
                </button>
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 20 }}>
              <div>
                <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: THEME.textSoft, marginBottom: 8 }}>
                  Stato
                  <select
                    value={editStatus}
                    onChange={(e) => setEditStatus(e.target.value as Status)}
                    style={{
                      width: "100%",
                      marginTop: 8,
                      padding: 10,
                      borderRadius: 8,
                      border: `1px solid ${THEME.borderSoft}`,
                      background: THEME.panelBg,
                      color: THEME.text,
                      outline: "none",
                      fontWeight: 600,
                      fontSize: 13,
                    }}
                  >
                    <option value="booked">Prenotato</option>
                    <option value="confirmed">Confermato</option>
                    <option value="done">Eseguito</option>
                    <option value="not_paid">Non pagata</option>
                    <option value="cancelled">Annullato</option>
                  </select>
                </label>
              </div>

              <div>
                <div style={{ fontSize: 13, fontWeight: 600, color: THEME.textSoft, marginBottom: 8 }}>
                  Promemoria
                </div>
                <button
                  onClick={() => {
                    const event = events.find(e => e.id === selectedEvent.id);
                    if (event) {
                      sendReminder(event.id, event.patient_phone ?? undefined, event.patient_first_name ?? undefined);
                    }
                  }}
                  disabled={!events.find(e => e.id === selectedEvent.id)?.patient_phone}
                  style={{
                    width: "100%",
                    padding: "12px",
                    borderRadius: 8,
                    border: `1px solid ${THEME.greenDark}`,
                    background: "#25d366",
                    color: "#fff",
                    cursor: events.find(e => e.id === selectedEvent.id)?.patient_phone ? "pointer" : "not-allowed",
                    fontWeight: 600,
                    fontSize: 13,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: 8,
                    opacity: events.find(e => e.id === selectedEvent.id)?.patient_phone ? 1 : 0.6,
                  }}
                >
                  <span>📱</span>
                  Invia promemoria WhatsApp
                </button>
              </div>
            </div>

            {/* Chiedi Recensione Google – visibile solo se stato = Eseguito */}
            {editStatus === "done" && (() => {
              const ev = events.find(e => e.id === selectedEvent.id);
              const hasPhone = !!ev?.patient_phone;
              return (
                <div style={{ marginBottom: 20 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: THEME.textSoft, marginBottom: 8 }}>
                    Recensione Google
                  </div>
                  <button
                    onClick={() => {
                      if (ev) sendGoogleReview(ev.patient_phone ?? undefined, ev.patient_first_name ?? undefined);
                    }}
                    disabled={!hasPhone}
                    style={{
                      width: "100%",
                      padding: "12px",
                      borderRadius: 8,
                      border: `1px solid ${THEME.patientsAccent}`,
                      background: THEME.patientsAccent,
                      color: "#fff",
                      cursor: hasPhone ? "pointer" : "not-allowed",
                      fontWeight: 600,
                      fontSize: 13,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      gap: 8,
                      opacity: hasPhone ? 1 : 0.6,
                    }}
                  >
                    <span>⭐</span>
                    Chiedi recensione Google
                  </button>
                  {!hasPhone && (
                    <div style={{ fontSize: 11, color: THEME.muted, marginTop: 4, fontWeight: 600 }}>
                      Nessun numero di telefono disponibile
                    </div>
                  )}
                </div>
              );
            })()}

            <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: THEME.textSoft, marginBottom: 20 }}>
              Nota
              <textarea
                value={editNote}
                onChange={(e) => setEditNote(e.target.value)}
                rows={4}
                style={{
                  width: "100%",
                  marginTop: 8,
                  padding: 10,
                  borderRadius: 8,
                  border: `1px solid ${THEME.borderSoft}`,
                  background: THEME.panelBg,
                  color: THEME.text,
                  outline: "none",
                  resize: "vertical",
                  fontWeight: 600,
                  fontSize: 13,
                }}
              />
            </label>

            {/* SOAP Notes — note di seduta strutturate */}
            {selectedEvent.patient_id && (
              <div style={{ marginTop: -8, marginBottom: 20 }}>
                <SOAPNotesEditor appointmentId={selectedEvent.id} patientId={selectedEvent.patient_id} />
              </div>
            )}

            <div style={{ display: "flex", justifyContent: "space-between", gap: 12, marginTop: 24, flexWrap: "wrap" }}>
              <button
                onClick={deleteAppointment}
                style={{
                  padding: "12px 20px",
                  borderRadius: 8,
                  border: `1px solid rgba(220,38,38,0.25)`,
                  background: "rgba(220,38,38,0.06)",
                  color: THEME.red,
                  cursor: "pointer",
                  fontWeight: 600,
                  minWidth: 120,
                  fontSize: 13,
                }}
              >
                Elimina
              </button>

              <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
                <Link
                  href={selectedEvent.patient_id ? `/patients/${selectedEvent.patient_id}` : "#"}
                  style={{
                    padding: "12px 20px",
                    borderRadius: 8,
                    border: `1px solid ${THEME.borderSoft}`,
                    background: THEME.panelSoft,
                    color: THEME.text,
                    fontWeight: 600,
                    textDecoration: "none",
                    display: "inline-flex",
                    alignItems: "center",
                    minWidth: 170,
                    justifyContent: "center",
                    opacity: selectedEvent.patient_id ? 1 : 0.5,
                    pointerEvents: selectedEvent.patient_id ? "auto" : "none",
                    fontSize: 13,
                  }}
                >
                  Scheda paziente
                </Link>

                <button
                  onClick={saveAppointment}
                  style={{
                    padding: "12px 20px",
                    borderRadius: 8,
                    border: `1px solid ${THEME.greenDark}`,
                    background: THEME.green,
                    color: "#fff",
                    cursor: "pointer",
                    fontWeight: 600,
                    minWidth: 140,
                    fontSize: 13,
                  }}
                >
                  Salva modifiche
                </button>
              </div>
            </div>

            <div style={{ marginTop: 16, fontSize: 12, color: THEME.muted, fontWeight: 600 }}>
              Nota: "Annullato" mantiene lo storico · "Elimina" rimuove dal DB.
            </div>
          </div>
        </div>
      )}

      {quickActionsMenu && (
        <div
          style={{
            position: "fixed",
            top: quickActionsMenu.y,
            left: quickActionsMenu.x,
            background: THEME.panelBg,
            border: `2px solid ${THEME.border}`,
            borderRadius: 12,
            boxShadow: "0 8px 28px rgba(30,64,175,0.14)",
            zIndex: 10000,
            minWidth: 200,
            overflow: "hidden",
          }}
        >
          {quickActionsMenu.eventId ? (
            <>
              <button
                onClick={() => {
                  const event = events.find(e => e.id === quickActionsMenu?.eventId);
                  if (event) {
                    toggleDoneQuick(event.id, event.status);
                    setQuickActionsMenu(null);
                  }
                }}
                style={{
                  width: "100%",
                  padding: "12px 16px",
                  border: "none",
                  background: "transparent",
                  color: THEME.text,
                  cursor: "pointer",
                  fontWeight: 600,
                  textAlign: "left",
                  borderBottom: `1.5px solid ${THEME.border}`,
                  fontSize: 13,
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                }}
              >
                ✅ Segna come eseguito
              </button>
              <button
                onClick={() => {
                  const event = events.find(e => e.id === quickActionsMenu?.eventId);
                  if (event) {
                    sendReminder(event.id, event.patient_phone ?? undefined, event.patient_first_name ?? undefined);
                    setQuickActionsMenu(null);
                  }
                }}
                style={{
                  width: "100%",
                  padding: "12px 16px",
                  border: "none",
                  background: "transparent",
                  color: THEME.text,
                  cursor: "pointer",
                  fontWeight: 600,
                  textAlign: "left",
                  borderBottom: `1.5px solid ${THEME.border}`,
                  fontSize: 13,
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                }}
              >
                ◈ Invia WhatsApp
              </button>
              <button
                onClick={() => {
                  const event = events.find(e => e.id === quickActionsMenu?.eventId);
                  if (event) {
                    openCreateModal(event.start, event.start.getHours(), event.start.getMinutes(), event);
                    setQuickActionsMenu(null);
                  }
                }}
                style={{
                  width: "100%",
                  padding: "12px 16px",
                  border: "none",
                  background: "transparent",
                  color: THEME.text,
                  cursor: "pointer",
                  fontWeight: 600,
                  textAlign: "left",
                  fontSize: 13,
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                }}
              >
                ◫ Duplica
              </button>
            </>
          ) : (
            <button
              onClick={() => {
                openCreateModal(new Date());
                setQuickActionsMenu(null);
              }}
              style={{
                width: "100%",
                padding: "12px 16px",
                border: "none",
                background: "transparent",
                color: THEME.text,
                cursor: "pointer",
                fontWeight: 600,
                textAlign: "left",
                fontSize: 13,
                display: "flex",
                alignItems: "center",
                gap: 8,
              }}
            >
              ◈ Nuovo appuntamento
            </button>
          )}
        </div>
      )}

      {/* Feature: Mini-scheda paziente al hover */}
      {hoverTooltip && (
        <div
          onMouseEnter={() => { /* keep visible */ }}
          onMouseLeave={handleEventHoverEnd}
          style={{
            position: "fixed",
            left: Math.min(hoverTooltip.x, window.innerWidth - 290),
            top: Math.min(hoverTooltip.y, window.innerHeight - 220),
            width: 270,
            background: THEME.panelBg,
            border: `2px solid ${THEME.border}`,
            borderRadius: 12,
            boxShadow: "0 12px 40px rgba(30,64,175,0.18)",
            padding: "14px 16px",
            zIndex: 10000,
            fontSize: 12,
            fontWeight: 600,
            color: THEME.text,
          }}
        >
          <div style={{ fontSize: 14, fontWeight: 800, color: THEME.blue, marginBottom: 8 }}>
            {hoverTooltip.event.patient_name}
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <span style={{ color: THEME.muted }}>Orario</span>
              <span>{fmtTime(hoverTooltip.event.start.toISOString())} – {fmtTime(hoverTooltip.event.end.toISOString())}</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <span style={{ color: THEME.muted }}>Stato</span>
              <span style={{ color: statusColor(hoverTooltip.event.status), fontWeight: 700 }}>{statusLabel(hoverTooltip.event.status)}</span>
            </div>
            {hoverTooltip.event.patient_phone && (
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span style={{ color: THEME.muted }}>Telefono</span>
                <span>{hoverTooltip.event.patient_phone}</span>
              </div>
            )}
            {hoverTooltip.event.diagnosis && (
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span style={{ color: THEME.muted }}>Diagnosi</span>
                <span style={{ maxWidth: 150, textAlign: "right", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{hoverTooltip.event.diagnosis}</span>
              </div>
            )}
            {hoverTooltip.event.treatment && (
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span style={{ color: THEME.muted }}>Trattamento</span>
                <span>{hoverTooltip.event.treatment}</span>
              </div>
            )}
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <span style={{ color: THEME.muted }}>Tipo</span>
              <span>{hoverTooltip.event.treatment_type === "macchinario" ? "Macchinario" : "Seduta"} · {hoverTooltip.event.price_type === "cash" ? "Contanti" : "Fattura"}</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <span style={{ color: THEME.muted }}>Importo</span>
              <span style={{ fontWeight: 800 }}>€ {hoverTooltip.event.amount ?? getDefaultAmount(
                (hoverTooltip.event.treatment_type as "seduta" | "macchinario") || "seduta",
                (hoverTooltip.event.price_type as "invoiced" | "cash") || "invoiced"
              )}</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <span style={{ color: THEME.muted }}>Pagato</span>
              <span style={{ color: hoverTooltip.event.is_paid ? THEME.green : THEME.red, fontWeight: 700 }}>
                {hoverTooltip.event.is_paid ? "✓ Sì" : "✗ No"}
              </span>
            </div>
            {hoverTooltip.event.calendar_note && (
              <div style={{ marginTop: 4, padding: "6px 8px", background: THEME.panelSoft, borderRadius: 6, fontSize: 11, color: THEME.muted, lineHeight: 1.4 }}>
                📝 {hoverTooltip.event.calendar_note}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Feature: Popover vista mese */}
      {monthPopover && (
        <div
          onClick={() => setMonthPopover(null)}
          style={{ position: "fixed", inset: 0, zIndex: 9998 }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              position: "fixed",
              left: Math.min(monthPopover.x, (typeof window !== "undefined" ? window.innerWidth : 800) - 320),
              top: Math.min(monthPopover.y, (typeof window !== "undefined" ? window.innerHeight : 600) - 300),
              width: 300,
              maxHeight: 340,
              overflowY: "auto",
              background: THEME.panelBg,
              border: `2px solid ${THEME.border}`,
              borderRadius: 12,
              boxShadow: "0 12px 40px rgba(30,64,175,0.18)",
              padding: "14px 16px",
              zIndex: 9999,
            }}
          >
            <div style={{ fontSize: 13, fontWeight: 800, color: THEME.blue, marginBottom: 10 }}>
              {formatDMY(monthPopover.day)} — {monthPopover.events.length} appuntamenti
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              {monthPopover.events.map(ev => (
                <div
                  key={ev.id}
                  onClick={() => {
                    setMonthPopover(null);
                    setCurrentDate(ev.start);
                    setViewType("day");
                  }}
                  style={{
                    display: "flex", alignItems: "center", gap: 8,
                    padding: "8px 10px", borderRadius: 8,
                    background: `${statusColor(ev.status)}22`,
                    borderLeft: `4px solid ${statusColor(ev.status)}`,
                    fontSize: 12, fontWeight: 600,
                    cursor: "pointer",
                  }}
                >
                  <span style={{ color: THEME.muted, minWidth: 40 }}>{fmtTime(ev.start.toISOString())}</span>
                  <span style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                    {ev.calendar_note?.startsWith("[WEB|") && <span style={{ fontSize: 8, background: statusColor(ev.status), color: "#fff", borderRadius: 3, padding: "1px 3px", marginRight: 3, fontWeight: 700, verticalAlign: "middle" }}>WEB</span>}
                    {ev.patient_name}
                  </span>
                  <span style={{ fontSize: 10, fontWeight: 700, color: statusColor(ev.status) }}>{statusLabel(ev.status)}</span>
                  <span>{ev.is_paid ? "💰" : ""}</span>
                </div>
              ))}
            </div>
            <div style={{ marginTop: 8, fontSize: 10, color: THEME.muted, textAlign: "center" }}>
              Click su un appuntamento → vista giorno
            </div>
          </div>
        </div>
      )}

      {/* Feature: Riepilogo giornaliero */}
      {dailySummaryOpen && (
        <div
          onClick={() => setDailySummaryOpen(false)}
          style={{
            position: "fixed", inset: 0,
            background: "rgba(30,64,175,0.35)",
            zIndex: 9999,
            display: "flex", alignItems: "center", justifyContent: "center",
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              width: 480,
              maxWidth: "90vw",
              maxHeight: "85vh",
              overflowY: "auto",
              background: THEME.panelBg,
              borderRadius: 16,
              border: `2px solid ${THEME.border}`,
              boxShadow: "0 24px 64px rgba(30,64,175,0.2)",
              padding: "28px 24px",
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
              <div>
                <div style={{ fontSize: 20, fontWeight: 800, color: THEME.blue }}>📋 Riepilogo di oggi</div>
                <div style={{ fontSize: 12, fontWeight: 600, color: THEME.muted, marginTop: 4 }}>{formatDMY(new Date())}</div>
              </div>
              <button onClick={() => setDailySummaryOpen(false)} style={{
                width: 38, height: 38, borderRadius: 10, border: `2px solid ${THEME.border}`,
                background: THEME.panelSoft, color: THEME.blue, cursor: "pointer", fontWeight: 800, fontSize: 14,
              }}>✕</button>
            </div>

            {/* Stats cards */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12, marginBottom: 20 }}>
              <div style={{ padding: "14px 12px", borderRadius: 10, background: "rgba(22,163,74,0.08)", border: `1px solid rgba(22,163,74,0.2)`, textAlign: "center" }}>
                <div style={{ fontSize: 22, fontWeight: 800, color: THEME.green }}>{dailySummary.done}</div>
                <div style={{ fontSize: 11, fontWeight: 600, color: THEME.muted }}>Eseguiti</div>
              </div>
              <div style={{ padding: "14px 12px", borderRadius: 10, background: "rgba(234,88,12,0.08)", border: `1px solid rgba(234,88,12,0.2)`, textAlign: "center" }}>
                <div style={{ fontSize: 22, fontWeight: 800, color: THEME.amber }}>{dailySummary.notDone}</div>
                <div style={{ fontSize: 11, fontWeight: 600, color: THEME.muted }}>Da fare</div>
              </div>
              <div style={{ padding: "14px 12px", borderRadius: 10, background: "rgba(220,38,38,0.08)", border: `1px solid rgba(220,38,38,0.2)`, textAlign: "center" }}>
                <div style={{ fontSize: 22, fontWeight: 800, color: THEME.red }}>{dailySummary.unpaid}</div>
                <div style={{ fontSize: 11, fontWeight: 600, color: THEME.muted }}>Non pagati</div>
              </div>
            </div>

            {/* Revenue breakdown */}
            <div style={{ padding: "16px", borderRadius: 10, background: THEME.panelSoft, border: `1px solid ${THEME.borderSoft}`, marginBottom: 20 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: THEME.textSoft, marginBottom: 12 }}>Incassi del giorno</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, fontWeight: 600 }}>
                  <span style={{ color: THEME.muted }}>Fatturato</span>
                  <span style={{ color: THEME.blue }}>€ {dailySummary.invoicedTotal.toFixed(2)}</span>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, fontWeight: 600 }}>
                  <span style={{ color: THEME.muted }}>Contanti</span>
                  <span style={{ color: THEME.amber }}>€ {dailySummary.cashTotal.toFixed(2)}</span>
                </div>
                <div style={{ borderTop: `1.5px solid ${THEME.border}`, paddingTop: 8, display: "flex", justifyContent: "space-between", fontSize: 15, fontWeight: 800 }}>
                  <span>Totale</span>
                  <span style={{ color: THEME.green }}>€ {dailySummary.grandTotal.toFixed(2)}</span>
                </div>
              </div>
            </div>

            {/* Event list */}
            <div style={{ fontSize: 13, fontWeight: 700, color: THEME.textSoft, marginBottom: 8 }}>Dettaglio appuntamenti ({dailySummary.total})</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
              {dailySummary.events.map(ev => (
                <div key={ev.id} style={{
                  display: "flex", alignItems: "center", gap: 10,
                  padding: "8px 10px", borderRadius: 8,
                  background: `${statusColor(ev.status)}22`,
                  borderLeft: `4px solid ${statusColor(ev.status)}`,
                  fontSize: 12, fontWeight: 600,
                }}>
                  <span style={{ color: THEME.muted, minWidth: 42 }}>{fmtTime(ev.start.toISOString())}</span>
                  <span style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{ev.patient_name}</span>
                  <span style={{ color: ev.is_paid ? THEME.green : THEME.red, fontSize: 11, fontWeight: 700 }}>
                    {ev.is_paid ? "💰" : "—"}
                  </span>
                  <span style={{ color: statusColor(ev.status), fontSize: 10, fontWeight: 700, minWidth: 60, textAlign: "right" }}>
                    {statusLabel(ev.status)}
                  </span>
                </div>
              ))}
              {dailySummary.events.length === 0 && (
                <div style={{ padding: 20, textAlign: "center", color: THEME.muted, fontWeight: 600 }}>
                  Nessun appuntamento oggi
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}